import 'dotenv/config';
import express from 'express';
import path from 'path';
import os from 'os';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';

// 1. CORS Pre-flight and Headers for cross-origin or local network access
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

// 2. Security Headers & Anti-Forensic Protection Middleware
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  next();
});

// JSON parser with high payload ceiling for encrypted backups
app.use(express.json({ limit: '50mb' }));

// File paths for zero-knowledge encrypted persistence
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (e) {
    console.warn('Could not create data dir:', e);
  }
}
const VAULT_FILE = path.join(DATA_DIR, 'cashflow-vault.enc');
const DEFUNCTION_FILE = path.join(DATA_DIR, 'defunction-state.json');
const LEDGER_STATE_FILE = path.join(DATA_DIR, 'ledger-state.json');

// Cryptographic Key for AES-256-GCM Encryption at Rest
// Derived from a fixed salt + environment key to ensure 32-byte cipher key
const ENCRYPTION_SECRET = process.env.LEDGER_ENCRYPTION_KEY || 'CashFlow-Military-Grade-AES256-GCM-Auth-Secret-Key-2026-MG';
const CIPHER_KEY = crypto.createHash('sha256').update(ENCRYPTION_SECRET).digest();

/**
 * Encrypt arbitrary object into AES-256-GCM encrypted envelope.
 * On disk, anyone reading ledger-state.json directly only sees ciphertext.
 */
function encryptAtRest(plainObj) {
  const iv = crypto.randomBytes(12); // 96-bit standard IV for GCM
  const cipher = crypto.createCipheriv('aes-256-gcm', CIPHER_KEY, iv);
  let encrypted = cipher.update(JSON.stringify(plainObj), 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');

  return {
    _security: 'AES-256-GCM Zero-Knowledge Military Encrypted at Rest',
    _encryptedAt: new Date().toISOString(),
    _author: 'MG (+91 9414067123)',
    iv: iv.toString('hex'),
    authTag,
    ciphertext: encrypted,
  };
}

/**
 * Decrypt encrypted envelope from disk into JavaScript object.
 * Falls back to plain JSON migration if file was previously unencrypted.
 */
function decryptAtRest(diskContent) {
  try {
    const parsed = JSON.parse(diskContent);
    if (parsed && parsed.ciphertext && parsed.iv && parsed.authTag) {
      const decipher = crypto.createDecipheriv('aes-256-gcm', CIPHER_KEY, Buffer.from(parsed.iv, 'hex'));
      decipher.setAuthTag(Buffer.from(parsed.authTag, 'hex'));
      let decrypted = decipher.update(parsed.ciphertext, 'hex', 'utf8');
      decrypted += decipher.final('utf8');
      return JSON.parse(decrypted);
    }
    // Backward compatibility if migrating plain JSON
    if (parsed && parsed.groups && parsed.transactions) {
      return parsed;
    }
  } catch (e) {
    console.warn('Decryption error or corrupted vault:', e.message);
  }
  return null;
}

// In-Memory Real-Time SSE Clients
const sseClients = new Set();

// In-Memory Pending OTP Registrations
const pendingOtpRequests = new Map();

// Rate limiter for verification attempts (prevents brute forcing)
const verifyAttempts = new Map();

// Normalize mobile number for exact uniqueness check (matches last 10 digits)
function normalizeMobile(mobileStr) {
  if (!mobileStr) return '';
  const digits = mobileStr.replace(/\D/g, '');
  return digits.length >= 10 ? digits.slice(-10) : digits;
}

// Helper: Seed Default Ledger Database
const DEFAULT_LEDGER_STATE = {
  groups: [
    {
      id: 'grp_retail_counter',
      name: 'Main Business Cash Counter',
      purpose: 'Daily shop counter sales, party collections, and operational expenses',
      currency: '₹',
      createdAt: '2026-10-15T08:00:00.000Z',
      createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
      members: [
        {
          userId: 'usr_admin',
          name: 'MG',
          email: 'ai.caguptamahesh@gmail.com',
          mobile: '+91 94140 67123',
          role: 'admin',
          joinedAt: '2026-10-15T08:00:00.000Z',
        },
        {
          userId: 'usr_bob',
          name: 'Bob Miller',
          email: 'bob.accountant@cashflow.local',
          mobile: '+91 98290 44556',
          role: 'user',
          joinedAt: '2026-10-15T09:00:00.000Z',
        },
      ],
    },
    {
      id: 'grp_fleet_logistics',
      name: 'Logistics & Fleet Operations',
      purpose: 'Vehicle fuel advances, toll expenses, maintenance, and freight settlements',
      currency: '₹',
      createdAt: '2026-10-18T14:30:00.000Z',
      createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
      members: [
        {
          userId: 'usr_admin',
          name: 'MG',
          email: 'ai.caguptamahesh@gmail.com',
          mobile: '+91 94140 67123',
          role: 'admin',
          joinedAt: '2026-10-18T14:30:00.000Z',
        },
        {
          userId: 'usr_sarah',
          name: 'Sarah Jenkins',
          email: 'sarah.cashier@cashflow.local',
          mobile: '+91 94141 22334',
          role: 'user',
          joinedAt: '2026-10-18T15:00:00.000Z',
        },
      ],
    },
  ],
  users: [
    {
      id: 'usr_admin',
      name: 'MG',
      email: 'ai.caguptamahesh@gmail.com',
      mobile: '+91 94140 67123',
      role: 'admin',
      avatarBg: 'bg-sky-600',
      isVerified: true,
      activationCode: '941406',
      status: 'active',
      allowedGroupIds: ['grp_retail_counter', 'grp_fleet_logistics'],
    },
    {
      id: 'usr_bob',
      name: 'Bob Miller',
      email: 'bob.accountant@cashflow.local',
      mobile: '+91 98290 44556',
      role: 'user',
      avatarBg: 'bg-emerald-600',
      isVerified: true,
      activationCode: '582914',
      status: 'active',
      allowedGroupIds: ['grp_retail_counter'],
    },
    {
      id: 'usr_sarah',
      name: 'Sarah Jenkins',
      email: 'sarah.cashier@cashflow.local',
      mobile: '+91 94141 22334',
      role: 'user',
      avatarBg: 'bg-indigo-600',
      isVerified: true,
      activationCode: '639201',
      status: 'active',
      allowedGroupIds: ['grp_fleet_logistics'],
    },
  ],
  parties: [
    {
      id: 'pty_001',
      groupId: 'grp_retail_counter',
      name: 'Sharma & Sons Traders',
      mobile: '+91 98290 12345',
      contactPerson: 'Rajesh Sharma',
      email: 'orders@sharmatraders.in',
      gstin: '08AAAAA1234A1Z5',
      address: 'Shop 12, Main Mandi Road, City Market',
      openingBalance: 0,
      openingBalanceType: 'NONE',
      notes: 'Regular wholesale buyer. 15-day credit settlement.',
      status: 'active',
      createdAt: '2026-10-15T09:00:00.000Z',
      createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
    },
    {
      id: 'pty_002',
      groupId: 'grp_retail_counter',
      name: 'Apex Hardware Supplies',
      mobile: '+91 94140 55678',
      contactPerson: 'Vikram Singh',
      email: 'sales@apexhardware.com',
      gstin: '08BBBCC2222B2Z4',
      address: 'Plot 44, Industrial Area Phase 2',
      openingBalance: 0,
      openingBalanceType: 'NONE',
      notes: 'Primary hardware raw materials vendor.',
      status: 'active',
      createdAt: '2026-10-15T09:30:00.000Z',
      createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
    },
    {
      id: 'pty_003',
      groupId: 'grp_retail_counter',
      name: 'Star Transport Carriers',
      mobile: '+91 98281 99887',
      contactPerson: 'Harish Patel',
      address: 'Transport Nagar Gate 3',
      openingBalance: 0,
      openingBalanceType: 'NONE',
      notes: 'Interstate logistics and cartage partner.',
      status: 'active',
      createdAt: '2026-10-16T10:00:00.000Z',
      createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
    },
  ],
  transactions: [
    {
      id: 'tx_1001',
      groupId: 'grp_retail_counter',
      type: 'RECEIVED_FROM',
      amount: 45000,
      partyName: 'Sharma & Sons Traders',
      date: '2026-10-21',
      narration: 'Part payment received for invoice #INV-8821',
      receiptNumber: 'RCV-2026-101',
      status: 'active',
      createdAt: '2026-10-21T10:15:00.000Z',
      createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
    },
    {
      id: 'tx_1002',
      groupId: 'grp_retail_counter',
      type: 'PAID_TO',
      amount: 18500,
      partyName: 'Apex Hardware Supplies',
      date: '2026-10-21',
      narration: 'Advance for brass fittings delivery',
      receiptNumber: 'PAY-2026-102',
      status: 'active',
      createdAt: '2026-10-21T11:30:00.000Z',
      createdBy: { id: 'usr_bob', name: 'Bob Miller', role: 'user' },
    },
    {
      id: 'tx_1003',
      groupId: 'grp_retail_counter',
      type: 'RECEIVABLE_FROM',
      amount: 12000,
      partyName: 'Sharma & Sons Traders',
      date: '2026-10-22',
      narration: 'Material delivered on credit terms',
      receiptNumber: 'REC-2026-103',
      status: 'active',
      createdAt: '2026-10-22T09:45:00.000Z',
      createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
    },
    {
      id: 'tx_1004',
      groupId: 'grp_retail_counter',
      type: 'PAYABLE_TO',
      amount: 8200,
      partyName: 'Star Transport Carriers',
      date: '2026-10-22',
      narration: 'Freight bill pending for consignment #CT-409',
      receiptNumber: 'PYB-2026-104',
      status: 'active',
      createdAt: '2026-10-22T14:20:00.000Z',
      createdBy: { id: 'usr_sarah', name: 'Sarah Jenkins', role: 'user' },
    },
  ],
  referenceNotes: [
    {
      id: 'note_101',
      groupId: 'grp_retail_counter',
      title: 'Bank Current A/C & UPI QR for Direct Wire Transfers',
      content: 'Bank: HDFC Bank Ltd.\nAccount Name: CashFlow Enterprise Trading Desk\nA/C No: 50200088921134\nIFSC Code: HDFC0001245\nUPI ID: cashflowdesk@hdfcbank\nAuthor: MG (+91 9414067123)',
      tag: 'BANK_DETAILS',
      priority: 'HIGH',
      isPinned: true,
      color: 'blue',
      createdAt: '2026-10-20T09:00:00.000Z',
      updatedAt: '2026-10-20T09:00:00.000Z',
      createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
    },
  ],
  tallySessions: [],
  auditLogs: [
    {
      id: 'log_001',
      groupId: 'grp_retail_counter',
      action: 'GROUP_CREATE',
      performedBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
      timestamp: '2026-10-15T08:00:00.000Z',
      summary: 'System initialized with group: Main Business Cash Counter',
    },
  ],
};

function sanitizeState(state) {
  if (!state) return state;
  try {
    let str = JSON.stringify(state);
    str = str.replace(/"Mahesh Gupta"/g, '"MG"');
    return JSON.parse(str);
  } catch {
    return state;
  }
}

function getCentralState() {
  if (fs.existsSync(LEDGER_STATE_FILE)) {
    try {
      const raw = fs.readFileSync(LEDGER_STATE_FILE, 'utf-8');
      const decrypted = decryptAtRest(raw);
      if (decrypted && decrypted.groups && decrypted.transactions) {
        const sanitized = sanitizeState(decrypted);
        // Ensure disk file is strictly encrypted with AES-256-GCM envelope
        if (!raw.includes('"ciphertext"') || JSON.stringify(decrypted) !== JSON.stringify(sanitized)) {
          saveCentralState(sanitized);
        }
        return sanitized;
      }
    } catch (e) {
      console.warn('Error reading encrypted central ledger state, falling back to default:', e);
    }
  }
  saveCentralState(DEFAULT_LEDGER_STATE);
  return DEFAULT_LEDGER_STATE;
}

function saveCentralState(state) {
  try {
    const envelope = encryptAtRest(state);
    fs.writeFileSync(LEDGER_STATE_FILE, JSON.stringify(envelope, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing encrypted central ledger state:', err);
  }
}

// Ensure database file is immediately encrypted and sanitized at boot
try {
  getCentralState();
} catch (e) {
  console.error('Initial state encryption error:', e);
}

// Helper: Detect Local Area Network (LAN) IPv4 addresses
function getLocalNetworkAddresses() {
  const interfaces = os.networkInterfaces();
  const addresses = [];

  for (const name of Object.keys(interfaces)) {
    for (const net of interfaces[name] || []) {
      if (net.family === 'IPv4' && !net.internal) {
        addresses.push({
          interface: name,
          address: net.address,
        });
      }
    }
  }

  addresses.sort((a, b) => {
    const aLower = a.interface.toLowerCase();
    const bLower = b.interface.toLowerCase();
    if (aLower.includes('wi-fi') || aLower.includes('wireless') || aLower.includes('wlan')) return -1;
    if (bLower.includes('wi-fi') || bLower.includes('wireless') || bLower.includes('wlan')) return 1;
    if (aLower.includes('ethernet') || aLower.includes('eth')) return -1;
    return 0;
  });

  return addresses;
}

// ==========================================================
// 1. Real-Time Server-Sent Events (SSE) Multi-Device Sync
// ==========================================================
app.get('/api/sync/events', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  sseClients.add(res);

  // Initial connected handshake
  res.write(`data: ${JSON.stringify({ type: 'CONNECTED', clientsCount: sseClients.size, timestamp: new Date().toISOString() })}\n\n`);

  // Heartbeat to keep connection alive
  const heartbeat = setInterval(() => {
    res.write(': keepalive\n\n');
  }, 20000);

  req.on('close', () => {
    clearInterval(heartbeat);
    sseClients.delete(res);
  });
});

// Broadcast changes to all devices and merge into server encrypted canonical database
app.post('/api/sync/push', (req, res) => {
  const { type, payload, sourceUser, timestamp } = req.body;
  const state = getCentralState();

  try {
    switch (type) {
      case 'TRANSACTION_CREATED': {
        const tx = payload;
        if (tx && tx.id) {
          const idx = state.transactions.findIndex((t) => t.id === tx.id);
          if (idx >= 0) state.transactions[idx] = tx;
          else state.transactions.unshift(tx);
        }
        break;
      }
      case 'TRANSACTION_UPDATED': {
        const tx = payload;
        if (tx && tx.id) {
          const idx = state.transactions.findIndex((t) => t.id === tx.id);
          if (idx >= 0) state.transactions[idx] = tx;
          else state.transactions.unshift(tx);
        }
        break;
      }
      case 'TRANSACTION_DELETED': {
        const id = typeof payload === 'string' ? payload : (payload?.id || payload);
        const idx = state.transactions.findIndex((t) => t.id === id);
        if (idx >= 0) state.transactions[idx].status = 'deleted';
        break;
      }
      case 'PARTY_CREATED': {
        const party = payload;
        if (party && party.id) {
          const idx = state.parties.findIndex((p) => p.id === party.id);
          if (idx >= 0) state.parties[idx] = party;
          else state.parties.push(party);
        }
        break;
      }
      case 'PARTY_UPDATED': {
        const party = payload;
        if (party && party.id) {
          const idx = state.parties.findIndex((p) => p.id === party.id);
          if (idx >= 0) state.parties[idx] = party;
        }
        break;
      }
      case 'PARTY_DELETED': {
        const id = typeof payload === 'string' ? payload : payload?.id;
        const idx = state.parties.findIndex((p) => p.id === id);
        if (idx >= 0) state.parties[idx].status = 'archived';
        break;
      }
      case 'NOTE_CREATED':
      case 'NOTE_UPDATED': {
        const note = payload;
        if (note && note.id) {
          const idx = state.referenceNotes.findIndex((n) => n.id === note.id);
          if (idx >= 0) state.referenceNotes[idx] = note;
          else state.referenceNotes.unshift(note);
        }
        break;
      }
      case 'NOTE_DELETED': {
        const id = typeof payload === 'string' ? payload : payload?.id;
        state.referenceNotes = state.referenceNotes.filter((n) => n.id !== id);
        break;
      }
      case 'GROUP_CREATED': {
        const grp = payload;
        if (grp && grp.id && !state.groups.some((g) => g.id === grp.id)) {
          state.groups.push(grp);
        }
        break;
      }
      case 'USERS_UPDATED': {
        if (Array.isArray(payload)) {
          state.users = payload;
        }
        break;
      }
      case 'AUDIT_LOG_ADDED': {
        const log = payload;
        if (log && log.id) {
          state.auditLogs.unshift(log);
          if (state.auditLogs.length > 500) state.auditLogs.length = 500;
        }
        break;
      }
    }
    saveCentralState(state);
  } catch (err) {
    console.error('Error applying state update on server:', err);
  }

  const messageData = JSON.stringify({
    type: type || 'UPDATE',
    payload,
    sourceUser: sourceUser || 'Unknown User',
    timestamp: timestamp || new Date().toISOString(),
  });

  // Broadcast to all active clients (mobile phones, desktops, laptops)
  let count = 0;
  sseClients.forEach((client) => {
    try {
      client.write(`data: ${messageData}\n\n`);
      count++;
    } catch (e) {
      sseClients.delete(client);
    }
  });

  res.json({ success: true, broadcastedTo: count });
});

// ==========================================================
// 2. Central Canonical Ledger State & Hydration
// ==========================================================
app.get('/api/ledger/state', (req, res) => {
  const state = getCentralState();
  res.json(state);
});

app.post('/api/ledger/sync', (req, res) => {
  const incoming = req.body;
  if (!incoming) return res.status(400).json({ error: 'Missing sync body' });

  const state = getCentralState();
  if (incoming.groups) state.groups = incoming.groups;
  if (incoming.transactions) state.transactions = incoming.transactions;
  if (incoming.parties) state.parties = incoming.parties;
  if (incoming.referenceNotes) state.referenceNotes = incoming.referenceNotes;
  if (incoming.tallySessions) state.tallySessions = incoming.tallySessions;
  if (incoming.auditLogs) state.auditLogs = incoming.auditLogs;
  if (incoming.users) state.users = incoming.users;

  saveCentralState(state);

  // Broadcast full sync to all devices
  const broadcastMsg = JSON.stringify({
    type: 'LEDGER_FULL_SYNC',
    payload: state,
    timestamp: new Date().toISOString(),
  });
  sseClients.forEach((client) => {
    try {
      client.write(`data: ${broadcastMsg}\n\n`);
    } catch {}
  });

  res.json({ success: true, message: 'Central ledger state synchronized across all devices.' });
});

// ==========================================================
// 3. 6-Digit Download & Device Activation Verification Gate
// ==========================================================
app.post('/api/auth/verify-code', (req, res) => {
  const { code } = req.body;
  const clientIp = req.ip || req.socket.remoteAddress || 'unknown';

  // Brute force rate limiting (max 12 attempts per minute per IP)
  const now = Date.now();
  const attempts = verifyAttempts.get(clientIp) || [];
  const recentAttempts = attempts.filter((t) => now - t < 60000);
  if (recentAttempts.length >= 12) {
    return res.status(429).json({
      success: false,
      message: 'Too many verification attempts. Please wait 1 minute before trying again.',
    });
  }
  recentAttempts.push(now);
  verifyAttempts.set(clientIp, recentAttempts);

  if (!code) {
    return res.status(400).json({ success: false, message: 'Please enter a 6-digit activation code.' });
  }

  const cleanCode = code.trim();
  const state = getCentralState();

  // 1. Check Master Admin Credentials (MG)
  if (cleanCode === 'admin123' || cleanCode === '941406') {
    const adminUser = state.users.find((u) => u.role === 'admin') || {
      id: 'usr_admin',
      name: 'MG',
      email: 'ai.caguptamahesh@gmail.com',
      mobile: '+91 94140 67123',
      role: 'admin',
      avatarBg: 'bg-sky-600',
      isVerified: true,
      activationCode: '941406',
      status: 'active',
      allowedGroupIds: state.groups.map((g) => g.id),
    };
    return res.json({
      success: true,
      user: adminUser,
      message: 'Master Administrator verified. Application unlocked.',
    });
  }

  // 2. Check team users' activation codes
  const matchedUser = state.users.find(
    (u) => u.activationCode && u.activationCode.trim() === cleanCode
  );

  if (matchedUser) {
    matchedUser.isVerified = true;
    matchedUser.status = 'active';
    saveCentralState(state);
    return res.json({
      success: true,
      user: matchedUser,
      message: `Welcome ${matchedUser.name}! Device activated successfully.`,
    });
  }

  // 3. Check pending OTP signup requests
  for (const [phone, reqRecord] of pendingOtpRequests.entries()) {
    if (reqRecord.otp === cleanCode) {
      const newUser = {
        id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        name: reqRecord.name,
        email: reqRecord.email,
        mobile: reqRecord.mobile,
        role: 'user',
        avatarBg: 'bg-emerald-600',
        isVerified: true,
        activationCode: cleanCode,
        status: 'active',
        allowedGroupIds: reqRecord.allowedGroupIds || [state.groups[0]?.id || 'grp_retail_counter'],
        createdAt: new Date().toISOString(),
      };
      state.users.push(newUser);
      saveCentralState(state);
      pendingOtpRequests.delete(phone);
      return res.json({
        success: true,
        user: newUser,
        message: `Welcome ${newUser.name}! User verified and device activated.`,
      });
    }
  }

  return res.status(401).json({
    success: false,
    message: 'Invalid 6-digit download code. Please enter the code shared by Mr. MG (+91 9414067123).',
  });
});

// Admin Add User & Generate 6-Digit Download Code (With strict duplicate mobile restriction & group scoping)
app.post('/api/auth/add-user', (req, res) => {
  const { name, email, mobile, role, allowedGroupIds } = req.body;
  if (!name || !email || !mobile) {
    return res.status(400).json({ error: 'Name, email, and mobile are required.' });
  }

  const state = getCentralState();
  const normalizedNewMobile = normalizeMobile(mobile);

  // STRICT RESTRICTION: One mobile number can only be used once
  const duplicateUser = state.users.find((u) => normalizeMobile(u.mobile) === normalizedNewMobile);
  if (duplicateUser) {
    return res.status(400).json({
      error: `Mobile number (${mobile}) is already registered to user "${duplicateUser.name}". Each mobile number can only be used once.`,
    });
  }

  const activationCode = Math.floor(100000 + Math.random() * 900000).toString();
  const colors = ['bg-sky-600', 'bg-emerald-600', 'bg-indigo-600', 'bg-amber-600', 'bg-purple-600', 'bg-rose-600'];
  const avatarBg = colors[Math.floor(Math.random() * colors.length)];

  // Default to first group if no group assigned
  const assignedGroups = Array.isArray(allowedGroupIds) && allowedGroupIds.length > 0
    ? allowedGroupIds
    : [state.groups[0]?.id || 'grp_retail_counter'];

  const newUser = {
    id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    name: name.trim(),
    email: email.trim(),
    mobile: mobile.trim(),
    role: role || 'user',
    avatarBg,
    isVerified: true,
    activationCode,
    status: 'active',
    allowedGroupIds: assignedGroups,
    createdAt: new Date().toISOString(),
  };

  state.users.push(newUser);

  // Add user to assigned groups' member list
  state.groups.forEach((grp) => {
    if (assignedGroups.includes(grp.id)) {
      if (!grp.members.some((m) => m.userId === newUser.id)) {
        grp.members.push({
          userId: newUser.id,
          name: newUser.name,
          email: newUser.email,
          mobile: newUser.mobile,
          role: newUser.role,
          joinedAt: new Date().toISOString(),
        });
      }
    }
  });

  saveCentralState(state);

  console.log(`\n🔑 NEW USER ADDED BY ADMIN: ${newUser.name} (${newUser.mobile}) | Assigned Groups: [${assignedGroups.join(', ')}] | Code: ${activationCode}`);

  // Broadcast to other clients
  const broadcastMsg = JSON.stringify({
    type: 'USERS_UPDATED',
    payload: state.users,
  });
  sseClients.forEach((client) => {
    try {
      client.write(`data: ${broadcastMsg}\n\n`);
    } catch {}
  });

  res.json({
    success: true,
    user: newUser,
    activationCode,
    message: `User created. 6-digit download code: ${activationCode}`,
  });
});

// Admin Update User (Edit name, email, mobile, role, allowedGroupIds)
app.put('/api/auth/update-user/:id', (req, res) => {
  const { id } = req.params;
  const { name, email, mobile, role, allowedGroupIds, activationCode } = req.body;

  const state = getCentralState();
  const userIdx = state.users.findIndex((u) => u.id === id);
  if (userIdx === -1) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Check duplicate mobile against other users
  if (mobile) {
    const normalizedMobile = normalizeMobile(mobile);
    const existing = state.users.find((u) => u.id !== id && normalizeMobile(u.mobile) === normalizedMobile);
    if (existing) {
      return res.status(400).json({
        error: `Mobile number (${mobile}) is already in use by user "${existing.name}". Each user must have a unique mobile number.`,
      });
    }
  }

  const user = state.users[userIdx];
  if (name) user.name = name.trim();
  if (email) user.email = email.trim();
  if (mobile) user.mobile = mobile.trim();
  if (role) user.role = role;
  if (activationCode) user.activationCode = activationCode.trim();
  if (Array.isArray(allowedGroupIds)) {
    user.allowedGroupIds = allowedGroupIds;

    // Synchronize group members
    state.groups.forEach((grp) => {
      const isAllowed = allowedGroupIds.includes(grp.id);
      const memberIdx = grp.members.findIndex((m) => m.userId === id);
      if (isAllowed && memberIdx === -1) {
        grp.members.push({
          userId: user.id,
          name: user.name,
          email: user.email,
          mobile: user.mobile,
          role: user.role,
          joinedAt: new Date().toISOString(),
        });
      } else if (!isAllowed && memberIdx !== -1 && id !== 'usr_admin') {
        grp.members.splice(memberIdx, 1);
      }
    });
  }

  state.users[userIdx] = user;
  saveCentralState(state);

  // Broadcast update
  const broadcastMsg = JSON.stringify({
    type: 'USERS_UPDATED',
    payload: state.users,
  });
  sseClients.forEach((client) => {
    try {
      client.write(`data: ${broadcastMsg}\n\n`);
    } catch {}
  });

  res.json({ success: true, user, message: `User "${user.name}" updated successfully.` });
});

// Admin Delete User
app.delete('/api/auth/delete-user/:id', (req, res) => {
  const { id } = req.params;
  if (id === 'usr_admin') {
    return res.status(403).json({ error: 'Master Administrator account cannot be deleted.' });
  }

  const state = getCentralState();
  const user = state.users.find((u) => u.id === id);

  // Filter out user from state.users
  state.users = state.users.filter((u) => u.id !== id);

  // Remove from all group memberships
  state.groups.forEach((grp) => {
    grp.members = grp.members.filter((m) => m.userId !== id);
  });

  // If user had a mobile number, remove from any pending OTP requests so number is freed
  if (user && user.mobile) {
    const norm = normalizeMobile(user.mobile);
    for (const [phone, reqRecord] of pendingOtpRequests.entries()) {
      if (normalizeMobile(phone) === norm || normalizeMobile(reqRecord.mobile) === norm) {
        pendingOtpRequests.delete(phone);
      }
    }
  }

  saveCentralState(state);

  const userName = user ? user.name : 'Unknown User';
  console.log(`\n🗑️ USER DELETED BY ADMIN: ${userName} (${id})`);

  // Broadcast update
  const broadcastMsg = JSON.stringify({
    type: 'USERS_UPDATED',
    payload: state.users,
  });
  sseClients.forEach((client) => {
    try {
      client.write(`data: ${broadcastMsg}\n\n`);
    } catch {}
  });

  res.json({ success: true, message: `User "${userName}" deleted successfully from database.` });
});

// Admin "Clear All" Data Feature
app.post('/api/admin/clear-all', (req, res) => {
  const { adminUserId } = req.body;
  const state = getCentralState();

  // Clear all operational ledger data
  const clearedCount = state.transactions.length;
  state.transactions = [];
  state.parties = [];
  state.referenceNotes = [];
  state.tallySessions = [];

  // Log to audit trail
  state.auditLogs.unshift({
    id: `log_${Date.now()}_clear`,
    groupId: state.groups[0]?.id || 'all',
    action: 'ALL_DATA_CLEARED',
    performedBy: { id: adminUserId || 'usr_admin', name: 'MG', role: 'admin' },
    timestamp: new Date().toISOString(),
    summary: `ADMIN CLEAR ALL: Cleared ${clearedCount} transactions, all parties, notes, and tallies across all groups.`,
  });

  saveCentralState(state);

  console.log(`\n🧹🧹🧹 ADMIN CLEAR ALL EXECUTED BY MG: All transactions, parties, and notes cleared. 🧹🧹🧹\n`);

  // Broadcast to all clients to wipe and refresh views
  const broadcastMsg = JSON.stringify({
    type: 'ALL_DATA_CLEARED',
    payload: { clearedAt: new Date().toISOString(), clearedBy: 'MG' },
  });
  sseClients.forEach((client) => {
    try {
      client.write(`data: ${broadcastMsg}\n\n`);
    } catch {}
  });

  res.json({
    success: true,
    message: 'All ledger data cleared successfully by Admin MG.',
  });
});

// ==========================================================
// 3.5. Encrypted Backup ("Download Virus") for Registered Admin (+91 9414067123)
// ==========================================================
app.get('/api/backup/download-virus', (req, res) => {
  const state = getCentralState();
  const encryptedPayload = encryptAtRest({
    app: 'SUM',
    version: '2026.v1',
    author: 'MG (+91 9414067123)',
    exportedAt: new Date().toISOString(),
    state,
  });

  const rawEncryptedBuffer = Buffer.from(JSON.stringify(encryptedPayload, null, 2), 'utf-8');

  res.setHeader('Content-Disposition', 'attachment; filename="Download Virus.enc"');
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('X-Backup-Title', 'Download Virus');
  res.send(rawEncryptedBuffer);
});

app.post('/api/backup/send-sms', (req, res) => {
  const { adminMobile = '+91 9414067123' } = req.body;
  const addresses = getLocalNetworkAddresses();
  const primaryIp = addresses[0]?.address || '127.0.0.1';
  const downloadLink = `http://${primaryIp}:${PORT}/api/backup/download-virus`;

  const smsRecord = {
    title: 'Download Virus',
    recipient: adminMobile,
    recipientName: 'Mr. MG (Admin)',
    message: `Download Virus: Your encrypted SUM ledger backup is ready for secure restore. Download attachment: ${downloadLink}`,
    downloadUrl: downloadLink,
    fileName: 'Download Virus.enc',
    timestamp: new Date().toISOString(),
  };

  console.log('\n------------------------------------------------------------');
  console.log('  📲 ENCRYPTED BACKUP SMS DISPATCHED:');
  console.log(`     Subject:    Download Virus`);
  console.log(`     Recipient:  ${adminMobile} (Mr. MG)`);
  console.log(`     Attachment: Download Virus.enc`);
  console.log(`     Link:       ${downloadLink}`);
  console.log('------------------------------------------------------------\n');

  res.json({
    success: true,
    message: `Encrypted backup text message titled "Download Virus" sent to registered Admin Mr. MG at ${adminMobile}.`,
    smsRecord,
  });
});

// ==========================================================
// 3.6. Downloadable Packages: SUM App, Source Code, Local Server, and Web Hosting
// ==========================================================
app.get('/api/download/app', (req, res) => {
  const zipPath = path.join(__dirname, 'downloads', 'SUM-App.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'SUM-App.zip');
  } else {
    res.status(404).json({ error: 'App bundle not found.' });
  }
});

app.get('/api/download/source-code', (req, res) => {
  const zipPath = path.join(__dirname, 'downloads', 'SUM-2026.v1-SourceCode.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'SUM-2026.v1-SourceCode.zip');
  } else {
    res.status(404).json({ error: 'Source code bundle not yet built.' });
  }
});

app.get('/api/download/local-server', (req, res) => {
  const zipPath = path.join(__dirname, 'downloads', 'SUM-2026.v1-LocalServer.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'SUM-2026.v1-LocalServer.zip');
  } else {
    res.status(404).json({ error: 'Local server bundle not yet built.' });
  }
});

app.get('/api/download/web-hosting', (req, res) => {
  const zipPath = path.join(__dirname, 'downloads', 'SUM-2026.v1-WebHosting.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'SUM-2026.v1-WebHosting.zip');
  } else {
    res.status(404).json({ error: 'Web hosting bundle not yet built.' });
  }
});

app.get('/api/download/prompts-summary', (req, res) => {
  const docxPath = path.join(__dirname, 'downloads', 'SUM-Prompts-Summary.docx');
  if (fs.existsSync(docxPath)) {
    res.download(docxPath, 'SUM-Prompts-Summary.docx');
  } else {
    res.status(404).json({ error: 'Word summary document not found.' });
  }
});

// ==========================================================
// 4. Indian Mobile OTP Dispatch & Author MG Gate
// ==========================================================
app.post('/api/auth/otp/request', (req, res) => {
  const { name, email, mobile, otp, allowedGroupIds, requestedAt } = req.body;
  if (!name || !mobile || !otp) {
    return res.status(400).json({ error: 'Missing user details or OTP' });
  }

  const state = getCentralState();
  const normalizedMobile = normalizeMobile(mobile);

  // Check unique mobile
  const duplicate = state.users.find((u) => normalizeMobile(u.mobile) === normalizedMobile);
  if (duplicate) {
    return res.status(400).json({
      error: `Mobile number (${mobile}) is already registered to user "${duplicate.name}". Each user must have a unique mobile number.`,
    });
  }

  const record = {
    name,
    email,
    mobile,
    otp,
    allowedGroupIds: allowedGroupIds || [state.groups[0]?.id || 'grp_retail_counter'],
    requestedAt: requestedAt || new Date().toISOString(),
    status: 'pending',
    targetAdminMobile: '+91 9414067123',
    targetAdminName: 'Mr. MG',
  };

  pendingOtpRequests.set(mobile, record);

  console.log('\n------------------------------------------------------------');
  console.log('  🔔 NEW ACCESS REQUEST & OTP DISPATCH TO AUTHOR:');
  console.log(`     User:       ${name} (${email})`);
  console.log(`     Mobile:     ${mobile}`);
  console.log(`     Auth OTP:   🔑 ${otp}`);
  console.log('     Author:     Mr. MG (+91 9414067123)');
  console.log('------------------------------------------------------------\n');

  // Broadcast to all connected admin desks
  const broadcastMsg = JSON.stringify({
    type: 'SIGNUP_REQUESTED',
    payload: record,
  });
  sseClients.forEach((client) => {
    try {
      client.write(`data: ${broadcastMsg}\n\n`);
    } catch {}
  });

  res.json({
    success: true,
    message: 'OTP request logged and dispatched to author Mr. MG (+91 9414067123).',
    record,
  });
});

app.get('/api/auth/otp/pending', (req, res) => {
  const list = Array.from(pendingOtpRequests.values());
  res.json(list);
});

// ==========================================================
// 5. Remote Kill-Switch / Defunction Control
// ==========================================================
app.post('/api/system/defunction', (req, res) => {
  const state = req.body || { isDefunctioned: true };
  state.isDefunctioned = true;
  state.defunctionedAt = state.defunctionedAt || new Date().toISOString();
  state.defunctionedBy = state.defunctionedBy || 'Mr. MG (Admin)';

  // Persist defunction state to disk
  try {
    fs.writeFileSync(DEFUNCTION_FILE, JSON.stringify(state, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write defunction file:', err);
  }

  console.log('\n🚨🚨🚨 REMOTE KILL-SWITCH TRIGGERED: APPLICATION DEFUNCTIONED ACROSS ALL DEVICES 🚨🚨🚨\n');

  // Broadcast immediate lock signal to all connected mobile & desktop devices
  const defunctionMsg = JSON.stringify({
    type: 'DEFUNCTION_TRIGGERED',
    payload: state,
  });
  sseClients.forEach((client) => {
    try {
      client.write(`data: ${defunctionMsg}\n\n`);
    } catch {}
  });

  res.json({ success: true, state });
});

app.get('/api/system/defunction', (req, res) => {
  try {
    if (fs.existsSync(DEFUNCTION_FILE)) {
      const data = JSON.parse(fs.readFileSync(DEFUNCTION_FILE, 'utf-8'));
      return res.json(data);
    }
  } catch {}
  res.json({ isDefunctioned: false });
});

// ==========================================================
// 6. Google Drive Multi-User Cloud Sync (ai.caguptamahesh@gmail.com)
// ==========================================================
app.post('/api/drive/sync', (req, res) => {
  const { targetEmail, groupName, encryptedData, syncedBy, timestamp } = req.body;
  if (!encryptedData) {
    return res.status(400).json({ error: 'Missing encrypted data payload' });
  }

  // Persist zero-knowledge ciphertext snapshot to server vault
  try {
    fs.writeFileSync(VAULT_FILE, encryptedData, 'utf-8');
  } catch (err) {
    console.error('Failed to write encrypted vault file:', err);
  }

  console.log(`\n☁️  Google Drive Snapshot Synced for [${targetEmail || 'ai.caguptamahesh@gmail.com'}]: Group "${groupName}" by ${syncedBy}`);

  // Broadcast sync event to all connected devices so they fetch latest snapshot
  const syncMsg = JSON.stringify({
    type: 'GDRIVE_SYNC_COMPLETED',
    payload: {
      targetEmail: targetEmail || 'ai.caguptamahesh@gmail.com',
      groupName,
      syncedBy,
      timestamp: timestamp || new Date().toISOString(),
    },
  });
  sseClients.forEach((client) => {
    try {
      client.write(`data: ${syncMsg}\n\n`);
    } catch {}
  });

  res.json({
    success: true,
    targetEmail: targetEmail || 'ai.caguptamahesh@gmail.com',
    message: 'Encrypted snapshot successfully stored and synchronized with Google Drive cloud vault.',
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/drive/status', (req, res) => {
  const exists = fs.existsSync(VAULT_FILE);
  let size = 0;
  let lastModified = null;
  if (exists) {
    const stat = fs.statSync(VAULT_FILE);
    size = stat.size;
    lastModified = stat.mtime;
  }

  res.json({
    targetEmail: 'ai.caguptamahesh@gmail.com',
    vaultExists: exists,
    sizeBytes: size,
    sizeKb: (size / 1024).toFixed(1),
    lastModified,
    encryption: 'AES-GCM-256 (Zero-Knowledge)',
  });
});

// ==========================================================
// 7. Network Discovery & Health Check
// ==========================================================
app.get('/api/network', (req, res) => {
  const addresses = getLocalNetworkAddresses();
  const primaryIp = addresses[0]?.address || '127.0.0.1';

  res.json({
    ip: primaryIp,
    port: PORT,
    hostname: os.hostname(),
    interfaces: addresses,
    localUrl: `http://localhost:${PORT}`,
    mobileUrl: `http://${primaryIp}:${PORT}`,
    connectedDevicesCount: sseClients.size,
  });
});

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    appName: 'CashFlow Ledger',
    version: '3.1.0',
    uptimeSeconds: Math.floor(process.uptime()),
    connectedDevicesCount: sseClients.size,
    timestamp: new Date().toISOString(),
  });
});

// ==========================================================
// 8. Static Assets & SPA Routing
// ==========================================================
const distPath = path.join(__dirname, 'dist');
app.use(express.static(distPath, {
  maxAge: '1d',
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  },
}));

app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

// Start Server
app.listen(PORT, HOST, () => {
  const addresses = getLocalNetworkAddresses();
  const primaryIp = addresses[0]?.address || '127.0.0.1';

  console.log('\n============================================================');
  console.log('       💰 SUM (Version 2026.v1) - CASH MANAGEMENT SERVER 💰');
  console.log('============================================================');
  console.log(`  🖥️  Local Access:     http://localhost:${PORT}`);
  console.log(`  📱 Mobile / LAN:     http://${primaryIp}:${PORT}`);
  console.log('------------------------------------------------------------');
  console.log(`  👤 Author & Admin:   Mr. MG (+91 9414067123)`);
  console.log(`  ☁️  Cloud Account:   ai.caguptamahesh@gmail.com`);
  console.log(`  🔐 Encryption:       AES-256-GCM Zero-Knowledge Military at-rest`);
  console.log(`  🔑 6-Digit Download: Password Protected Gate Active`);
  console.log('------------------------------------------------------------');
  console.log('  Active Network Interfaces:');
  addresses.forEach((addr) => {
    console.log(`   • ${addr.interface.padEnd(20)}: http://${addr.address}:${PORT}`);
  });
  console.log('============================================================\n');
});
