# SUM — Cash Management & Ledger System
### Version 2026.v1 • Copyright © MG • All Rights Reserved

<div align="center">

```
   ███╗   ███╗
   ████╗ ████║
   ██╔████╔██║    S U M  (Version 2026.v1)
   ██║╚██╔╝██║    Cash Management & Distributed Ledger
   ██║ ╚═╝ ██║    Copyright © MG
   ╚═╝     ╚═╝
```

[![React](https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=black)](https://react.dev)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-3178C6?logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![Node.js](https://img.shields.io/badge/Node.js-18%2B-339933?logo=node.js&logoColor=white)](https://nodejs.org/)
[![Vite](https://img.shields.io/badge/Vite-6-646CFF?logo=vite&logoColor=white)](https://vitejs.dev/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-4-38B2AC?logo=tailwind-css&logoColor=white)](https://tailwindcss.com/)
[![Encryption](https://img.shields.io/badge/Storage-AES--256--GCM-critical)](https://en.wikipedia.org/wiki/Advanced_Encryption_Standard)
[![PWA Ready](https://img.shields.io/badge/PWA-Installable-purple)](https://web.dev/progressive-web-apps/)
[![License](https://img.shields.io/badge/License-Copyright%20%C2%A9%20MG-blue)](#copyright--license)

</div>

---

## 🌟 Overview

**SUM** is an enterprise-grade, high-security cash transactions and ledger management application engineered for **local server hosting**, **local Wi-Fi multi-user environments**, and **mobile progressive web app (PWA)** operation.

Built around five core architectural pillars—zero-knowledge cryptography, author-mediated security gatekeeping, continuous bilingual voice logging, real-time multi-user replication, and canonical Lacs financial accounting—SUM provides complete financial tracking while protecting sensitive business data from forensic tools, third-party software, and unauthorized physical extraction.

---

## 🚀 Key Features

### 1. 🎙️ Continuous Bilingual Voice Recognition ("Add by Voice")
- **Dual-Language Speech Capture**: Supports both **English (en-IN / en-US)** and **Hindi (hi-IN)** speech recognition for recording financial transactions.
- **Continuous Listening**: Voice capture runs continuously until terminated by spoken stop keywords (**"Stop"**, **"End"**, or **"Over"**).
- **Ergonomic Floating Action Button (FAB)**: Quick-access microphone button anchored to the bottom-right for instant thumb accessibility on mobile devices.
- **iOS Safari Chrome Fallback**: Automatically detects iOS Safari and prompts or redirects to Google Chrome for iOS (`googlechrome://`) where speech synthesis is fully supported.
- **Speech Parsing Engine**: Automatically parses transaction direction (*"Received from"*, *"Paid to"*), amount, and party name into the transaction modal.

### 2. 🛡️ Author-Mediated Security Gate & Indian Mobile Standards
- **Indian Telecom Validation**: User signup strictly validates 10-digit mobile numbers conforming to Indian standards (`^[6-9]\d{9}$`).
- **Centralized Author OTP Gateway**: When a user registers or requests access, the 6-digit OTP and applicant credentials are automatically dispatched directly to the application author, **Mr. Mahesh Gupta** at **`+91 9414067123`**. Access is granted only after Mr. Mahesh Gupta verifies and relays the OTP to the authorized user.
- **WhatsApp Onboarding with 6-Digit Access Code**: Generates a one-click WhatsApp invitation link containing the app download QR code, public URL, and the user's personal 6-digit installation authorization code.
- **Hard Mobile Uniqueness**: Prevents duplicate accounts; purging a user permanently frees that mobile number for fresh registration.

### 3. 🔒 Zero-Knowledge AES-256 Storage Encryption & Screen-Only Decryption
- **Impenetrable Data-at-Rest**: All financial records, party master entries, notes, and audit trails are encrypted with military-grade AES-256-GCM before writing to disk or database storage.
- **Screen-Only Decryption**: Data exists in plaintext solely during volatile, in-memory active browser sessions; storage files cannot be inspected or decrypted by forensic tools, disk scanners, or unauthorized software.
- **Camouflaged Restorable Backup ("Download Virus")**: Generates a full encrypted, restorable backup file dispatched via SMS/WhatsApp under the camouflaged label *"Download Virus"*—accessible strictly by the registered administrator mobile number.

### 4. ⚡ Emergency Remote Purge (Challenge Code `13`)
- **Top-Left Emergency Wipe Trigger**: A discreet security button on the top-left corner of the dashboard allows the administrator to initiate an immediate remote wipe.
- **Two-Digit Challenge**: Prompts for a 2-digit confirmation code matching **`13`**. Upon validation, all application data, cached sessions, and databases are wiped permanently from all connected devices.
- **Remote Kill-Switch**: Permanently defunctions the application across all client devices if deleted by the administrator.

### 5. 👥 Real-Time Multi-User Synchronization & Group Isolation
- **WebSocket Live Engine**: Instantaneous intra-group broadcast; when any user adds, edits, or deletes a transaction, all group peers receive immediate live updates without manual page refreshing.
- **Automated Lifecycle Sync**: Automatically fetches latest ledger state whenever the application resumes focus or is opened after being idle.
- **Group Role-Based Access Control**: Isolates users strictly into pre-configured Business and Cash groups created by the administrator.
- **Immutable Audit Trail**: Logs every create, update, delete, and restore action with timestamps, previous values, new values, and operator IDs. Peer alerts notify group members when transactions are altered.

### 6. 💰 Canonical Financial Lacs Denomination
- **Native Lacs Representation**: All transaction amounts are stored natively in Lacs with precise floating-point decimals preserved.
- **Clean Numeric Presentation**: Strips all unit suffixes (*"Lac"* or *"Lacs"*) and eliminates absolute rupee subtexts from summary tiles and balances; all figures appear cleanly as pure numbers under the implicit convention that all figures represent Lacs.
- **Flexible Entry**: Users can enter values either in Lacs or absolute figures manually or by voice; the system normalizes values accurately.

### 7. 📱 Responsive PWA & Master Party Directory
- **Fluid Multi-Device UI**: Seamless responsive experience across desktop monitors, laptops, tablets, and smartphones.
- **Branded "M" Identity**: Vector SVG application icon with signature monogram **"M"**, Version **`2026.v1`**, and **`© MG`** footer on every screen.
- **Categorized Party Selectors**: Dropdowns for Receipt, Payment, Receivable, and Payable parties.
- **Contact Privacy Masking**: Party and user phone numbers are masked across general tables and visible strictly within the Admin User Management panel.

---

## 📂 Repository Structure

```
cashflow-ledger/
├── .env.example              # Production configuration template
├── .gitignore                # Git ignore rules for Node, Vite, secrets & builds
├── index.html                # App root entry point with PWA meta & 'M' favicon
├── package.json              # Project dependencies & build scripts
├── server.js                 # Express + WebSocket backend, AES-256 vault & API
├── tsconfig.json             # TypeScript compiler settings
├── vite.config.ts            # Vite bundler configuration
├── public/                   # Static assets & PWA manifest
│   ├── icon-192.svg          # 192x192 SVG App Icon (Monogram 'M')
│   ├── icon-512.svg          # 512x512 SVG App Icon (Monogram 'M')
│   └── manifest.json         # PWA Web App Manifest
├── src/                      # Frontend React 19 + TypeScript application
│   ├── App.tsx               # Root application shell & routing
│   ├── main.tsx              # React DOM mounting
│   ├── index.css             # Tailwind CSS & global styling
│   ├── components/           # UI modules
│   │   ├── AddTransactionModal.tsx  # Transaction modal with bilingual voice input
│   │   ├── CashNotesView.tsx        # Reference memo & notes repository
│   │   ├── DashboardOverview.tsx    # Summary tiles & visual financial gauges
│   │   ├── PartyDirectoryModal.tsx  # Master party management
│   │   ├── TransactionList.tsx      # Ledger journal with audit history
│   │   └── UserManagementModal.tsx  # Admin user management & WhatsApp QR
│   ├── hooks/                # Custom React hooks (useSpeechRecognition, etc.)
│   ├── services/             # API client, WebSocket sync & encryption vault
│   ├── types/                # TypeScript interfaces & domain models
│   └── utils/                # Currency conversion (Lacs), validation & formatters
└── scripts/                  # Automated build, packaging & utility scripts
```

---

## ⚙️ Quick Start

### Prerequisites
- [Node.js](https://nodejs.org/) (v18+ recommended; tested on v20 & v22)
- [npm](https://www.npmjs.com/) (bundled with Node.js)

### 1. Installation
Clone or download the repository, then install dependencies:
```bash
git clone https://github.com/your-username/sum-cash-management.git
cd sum-cash-management
npm install
```

### 2. Environment Setup
Copy the template configuration to create your local `.env`:
```bash
cp .env.example .env
```
*(On Windows PowerShell: `Copy-Item .env.example .env`)*

Configure your desired port and encryption secret in `.env`:
```env
PORT=3000
HOST=0.0.0.0
LEDGER_ENCRYPTION_KEY="your_secure_aes256_passphrase_here"
ADMIN_NAME="Mr. MG"
ADMIN_MOBILE="+91 9414067123"
ADMIN_EMAIL="ai.caguptamahesh@gmail.com"
```

### 3. Build & Run Production Server
```bash
# Build the production frontend
npm run build

# Start the unified Express + WebSocket server
npm start
```

Access the application in your browser:
- **Local machine:** [http://localhost:3000](http://localhost:3000)
- **Local Wi-Fi Network:** `http://<YOUR_LAN_IP>:3000` (e.g. `http://192.168.1.100:3000`)

### 4. Development Mode (with Hot Reloading)
```bash
npm run dev
```

---

## 📱 Mobile Installation (PWA)

1. Connect your smartphone to the same Wi-Fi network as the server (or access via public URL).
2. Open the URL in your phone browser:
   - **Android (Google Chrome):** Tap the **Three Dots (⋮)** ➔ Tap **"Install App"** or **"Add to Home Screen"**.
   - **iOS iPhone (Safari / Chrome):** Tap the **Share** button ➔ Tap **"Add to Home Screen"** (*होम स्क्रीन पर जोड़ें*).
3. The **"M"** icon app **SUM** will be installed directly on your home screen and operates in full-screen standalone mode.

---

## 🔒 Security Architecture

| Security Layer | Implementation Mechanism |
| :--- | :--- |
| **Authentication** | Indian mobile validation (`^[6-9]\d{9}$`), centralized author-dispatched OTP to Mr. Mahesh Gupta (`+91 9414067123`), unique 6-digit access codes. |
| **At-Rest Cryptography** | AES-256-GCM cipher with PBKDF2 key derivation applied to all persistent storage files. |
| **Volatile In-Memory Display** | Sensitive financial records are decrypted exclusively into transient memory for active screen rendering. |
| **Emergency Kill-Switch** | Top-left challenge code `13` initiates an irreversible global wipe across all connected client nodes and databases. |
| **Contact Privacy** | Phone numbers captured during onboarding are masked across all public ledger screens, visible strictly to the Admin. |
| **Audit Trail** | Tamper-evident logging of all transactions, modifications, and deletions with real-time peer alerts. |

---

## 📄 Copyright & License

**Copyright © 2026 MG. All Rights Reserved.**

This software and associated documentation files are the proprietary and confidential property of **MG**. Unauthorized copying, modification, distribution, reverse engineering, or public display of this software is strictly prohibited without prior written permission from the copyright owner.

For licensing inquiries or administrative access:
* **Author / Administrator:** MG
* **Official Mobile:** +91 9414067123
* **Official Email:** ai.caguptamahesh@gmail.com
