import React, { useState, useEffect } from 'react';
import {
  X,
  Shield,
  User,
  Key,
  UserPlus,
  Check,
  Lock,
  Mail,
  UserCheck,
  Phone,
  MessageSquare,
  AlertCircle,
  ExternalLink,
  Ban,
  ShieldAlert,
  Send,
  Sparkles,
  Copy,
  CheckCircle2,
  LockKeyhole,
  Smartphone,
  Trash2,
  Edit2,
  Building,
  RefreshCw,
  FolderMinus,
  QrCode,
  Download,
  Share2,
} from 'lucide-react';
import QRCode from 'qrcode';
import { User as UserType, UserSignupRequest, Group } from '../types/ledger';
import { storageService } from '../services/storageService';
import { validateIndianMobile } from './PartyManagerModal';

interface UserAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: UserType[];
  currentUser: UserType;
  groups?: Group[];
  onSwitchUser: (user: UserType) => void;
  onAddUser?: (user: Omit<UserType, 'id'>) => void;
  onRefresh?: () => void;
  onLockDevice?: () => void;
}

export const UserAuthModal: React.FC<UserAuthModalProps> = ({
  isOpen,
  onClose,
  users,
  currentUser,
  groups = [],
  onSwitchUser,
  onAddUser,
  onRefresh,
  onLockDevice,
}) => {
  const [activeTab, setActiveTab] = useState<'switch' | 'add_team' | 'new_user' | 'author_desk'>('switch');

  // Available groups list (if not passed, fetch from storage)
  const availableGroups = groups.length > 0 ? groups : storageService.getGroups();

  // Admin Add Team Member Form State
  const [teamName, setTeamName] = useState('');
  const [teamEmail, setTeamEmail] = useState('');
  const [teamMobile, setTeamMobile] = useState('');
  const [teamRole, setTeamRole] = useState<'user' | 'admin'>('user');
  const [teamAllowedGroupIds, setTeamAllowedGroupIds] = useState<string[]>([]);
  const [teamError, setTeamError] = useState('');
  const [createdTeamResult, setCreatedTeamResult] = useState<{ user: UserType; activationCode: string } | null>(null);
  const [isAddingTeam, setIsAddingTeam] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  // Edit User State
  const [editingUser, setEditingUser] = useState<UserType | null>(null);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editMobile, setEditMobile] = useState('');
  const [editRole, setEditRole] = useState<'user' | 'admin'>('user');
  const [editAllowedGroupIds, setEditAllowedGroupIds] = useState<string[]>([]);
  const [editError, setEditError] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  // Self Registration New User Form State
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newMobile, setNewMobile] = useState('');
  const [mobileError, setMobileError] = useState('');
  
  // OTP Verification Flow State
  const [activeRequest, setActiveRequest] = useState<UserSignupRequest | null>(null);
  const [enteredOtp, setEnteredOtp] = useState('');
  const [otpVerifyMessage, setOtpVerifyMessage] = useState<{ success: boolean; text: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Synchronized user list for instant deletion and addition feedback
  const [userList, setUserList] = useState<UserType[]>(users);
  useEffect(() => {
    setUserList(users);
  }, [users]);

  // QR Code & WhatsApp Share State
  const [qrModalUser, setQrModalUser] = useState<UserType | null>(null);
  const [qrModalDataUrl, setQrModalDataUrl] = useState<string>('');
  const [teamQrDataUrl, setTeamQrDataUrl] = useState<string>('');
  const [lanDownloadUrl, setLanDownloadUrl] = useState<string>('');
  const [isSharingQr, setIsSharingQr] = useState<boolean>(false);
  const [qrShareNotice, setQrShareNotice] = useState<string>('');

  // Author Desk & Clear All State
  const [pendingRequests, setPendingRequests] = useState<UserSignupRequest[]>([]);
  const [defunctionConfirmText, setDefunctionConfirmText] = useState('');
  const [showDefunctionModal, setShowDefunctionModal] = useState(false);
  const [showClearAllModal, setShowClearAllModal] = useState(false);
  const [clearAllConfirmText, setClearAllConfirmText] = useState('');
  const [isClearingAll, setIsClearingAll] = useState(false);

  const authorMobile = '+91 9414067123';
  const authorName = 'Mr. MG';
  const authorEmail = 'ai.caguptamahesh@gmail.com';

  // Detect LAN Download URL on mount
  useEffect(() => {
    if (!isOpen) return;
    const detectDownloadHost = async () => {
      try {
        const port = window.location.port || '3000';
        const res = await fetch('/api/network');
        if (res.ok) {
          const data = await res.json();
          if (data.ip) {
            setLanDownloadUrl(`http://${data.ip}:${port}`);
            return;
          }
        }
      } catch {}
      setLanDownloadUrl(window.location.origin);
    };
    detectDownloadHost();
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) {
      setPendingRequests(storageService.getPendingSignups());
      // Default new user group selection to the first group
      if (availableGroups.length > 0 && teamAllowedGroupIds.length === 0) {
        setTeamAllowedGroupIds([availableGroups[0].id]);
      }
    }
  }, [isOpen, activeTab, availableGroups]);

  // Generate QR Code for a given user
  const generateQrForUser = async (userObj: UserType) => {
    const code = userObj.activationCode || (userObj.role === 'admin' ? '941406' : '123456');
    const targetUrl = lanDownloadUrl || window.location.origin;
    const fullActivationUrl = `${targetUrl}?code=${code}`;

    try {
      const dataUrl = await QRCode.toDataURL(fullActivationUrl, {
        width: 320,
        margin: 2,
        color: {
          dark: '#0369a1', // sky-700
          light: '#ffffff',
        },
      });
      return { dataUrl, fullActivationUrl, code };
    } catch (e) {
      console.error('QR generation error:', e);
      return { dataUrl: '', fullActivationUrl: targetUrl, code };
    }
  };

  // Generate QR whenever a new team member is registered
  useEffect(() => {
    if (createdTeamResult?.user) {
      generateQrForUser(createdTeamResult.user).then((res) => {
        setTeamQrDataUrl(res.dataUrl);
      });
    } else {
      setTeamQrDataUrl('');
    }
  }, [createdTeamResult, lanDownloadUrl]);

  // Open QR Code Preview Modal for any user
  const handleOpenQrModal = async (userObj: UserType) => {
    setQrModalUser(userObj);
    setQrShareNotice('');
    const res = await generateQrForUser(userObj);
    setQrModalDataUrl(res.dataUrl);
  };

  // Generate Invite Card Blob using HTML Canvas
  const generateInviteCardBlob = async (userObj: UserType, code: string, qrUrl: string): Promise<Blob | null> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      canvas.width = 640;
      canvas.height = 780;
      const ctx = canvas.getContext('2d');
      if (!ctx) return resolve(null);

      // Background gradient
      const grad = ctx.createLinearGradient(0, 0, 0, 780);
      grad.addColorStop(0, '#0f172a'); // slate-900
      grad.addColorStop(1, '#0369a1'); // sky-700
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 640, 780);

      // Inner Card
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.roundRect(24, 24, 592, 732, 24);
      ctx.fill();

      // Top Brand Header
      ctx.fillStyle = '#0284c7'; // sky-600
      ctx.beginPath();
      ctx.roundRect(24, 24, 592, 100, [24, 24, 0, 0]);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('💰 CASHFLOW LEDGER', 320, 68);

      ctx.font = '12px sans-serif';
      ctx.fillStyle = '#e0f2fe';
      ctx.fillText('Authorized by Mr. MG (+91 9414067123)', 320, 96);

      // Member Box
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.roundRect(50, 145, 540, 80, 16);
      ctx.fill();
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 17px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(`Member: ${userObj.name}`, 320, 175);

      ctx.fillStyle = '#64748b';
      ctx.font = '13px monospace';
      ctx.fillText(`Mobile: ${userObj.mobile} • Role: ${userObj.role.toUpperCase()}`, 320, 205);

      // Draw QR Code
      const qrImg = new Image();
      qrImg.onload = () => {
        ctx.drawImage(qrImg, 195, 245, 250, 250);

        // 6-digit code box
        ctx.fillStyle = '#ecfdf5';
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.roundRect(80, 515, 480, 90, 16);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#065f46';
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('YOUR 6-DIGIT DOWNLOAD & ACTIVATION CODE', 320, 542);

        ctx.fillStyle = '#047857';
        ctx.font = 'bold 36px monospace';
        ctx.fillText(code, 320, 586);

        // Instructions
        ctx.fillStyle = '#334155';
        ctx.font = '13px sans-serif';
        ctx.fillText('1. Scan QR code above to download the app', 320, 635);
        ctx.fillText(`2. Enter code ${code} to activate your session`, 320, 660);

        // Security footer
        ctx.fillStyle = '#94a3b8';
        ctx.font = '11px sans-serif';
        ctx.fillText('🔒 Enterprise AES-256-GCM Zero-Knowledge Encryption', 320, 715);

        canvas.toBlob((blob) => resolve(blob), 'image/png');
      };
      qrImg.onerror = () => resolve(null);
      qrImg.src = qrUrl;
    });
  };

  // 1-Click Download QR Invite Card PNG
  const handleDownloadQrCard = async (userObj: UserType) => {
    const code = userObj.activationCode || (userObj.role === 'admin' ? '941406' : '123456');
    const qr = await generateQrForUser(userObj);
    const blob = await generateInviteCardBlob(userObj, code, qr.dataUrl);
    if (!blob) return;

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `CashFlow_Invite_${userObj.name.replace(/\s+/g, '_')}_Code_${code}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setQrShareNotice('Invite Card downloaded! You can attach it to WhatsApp.');
  };

  // Share QR Card & Code directly to WhatsApp (Web Share API with file attachment)
  const handleShareQrCardWhatsApp = async (userObj: UserType) => {
    setIsSharingQr(true);
    setQrShareNotice('');
    try {
      const code = userObj.activationCode || (userObj.role === 'admin' ? '941406' : '123456');
      const appUrl = lanDownloadUrl || window.location.origin;
      const qr = await generateQrForUser(userObj);
      const blob = await generateInviteCardBlob(userObj, code, qr.dataUrl);

      const shareText = `*CASHFLOW LEDGER - APP DOWNLOAD & ACCESS CODE*\n\n` +
        `Hello ${userObj.name},\n` +
        `You are authorized by Admin MG to download CashFlow Ledger for your assigned group.\n\n` +
        `📱 *1. Download / Open App:*\n${appUrl}\n\n` +
        `🔑 *2. 6-Digit Download & Activation Code:*\n*${code}*\n\n` +
        `⚡ *3. Direct 1-Click Link:*\n${appUrl}?code=${code}\n\n` +
        `📷 *Or scan the attached QR Code Image card.*`;

      // Try Web Share API (supported on mobile Android/iOS and modern Windows browsers)
      if (blob && navigator.canShare && navigator.canShare({ files: [new File([blob], 'invite.png', { type: 'image/png' })] })) {
        const file = new File([blob], `CashFlow_Invite_${userObj.name.replace(/\s+/g, '_')}.png`, { type: 'image/png' });
        await navigator.share({
          title: 'CashFlow Ledger Download Invite',
          text: shareText,
          files: [file],
        });
        setQrShareNotice('Shared successfully via WhatsApp!');
        return;
      }

      // Fallback: Download image and launch WhatsApp click-to-chat
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `CashFlow_Invite_${userObj.name.replace(/\s+/g, '_')}_Code_${code}.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }

      const cleanPhone = (userObj.mobile || '').replace(/[\s\-\(\)\+]/g, '');
      const waUrl = cleanPhone
        ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(shareText)}`
        : `https://wa.me/?text=${encodeURIComponent(shareText)}`;
      window.open(waUrl, '_blank');
      setQrShareNotice('QR Card downloaded to device & WhatsApp opened! Attach the card to your chat.');
    } catch (err: any) {
      console.warn('Share error:', err);
    } finally {
      setIsSharingQr(false);
    }
  };

  if (!isOpen) return null;

  // Toggle group selection for Add User form
  const handleToggleAddGroup = (groupId: string) => {
    setTeamAllowedGroupIds((prev) =>
      prev.includes(groupId)
        ? (prev.length > 1 ? prev.filter((id) => id !== groupId) : prev)
        : [...prev, groupId]
    );
  };

  // Toggle group selection for Edit User form
  const handleToggleEditGroup = (groupId: string) => {
    setEditAllowedGroupIds((prev) =>
      prev.includes(groupId)
        ? (prev.length > 1 ? prev.filter((id) => id !== groupId) : prev)
        : [...prev, groupId]
    );
  };

  // Open Edit User Modal
  const handleOpenEdit = (user: UserType) => {
    setEditingUser(user);
    setEditName(user.name);
    setEditEmail(user.email);
    setEditMobile(user.mobile);
    setEditRole(user.role);
    setEditAllowedGroupIds(user.allowedGroupIds || availableGroups.map((g) => g.id));
    setEditError('');
  };

  // Save Edited User with duplicate mobile restriction
  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setEditError('');

    if (!editName.trim()) {
      setEditError('Please enter user name.');
      return;
    }
    if (!editEmail.trim()) {
      setEditError('Please enter user email.');
      return;
    }

    const check = validateIndianMobile(editMobile);
    if (!check.valid) {
      setEditError(check.message || 'Please enter a valid 10-digit Indian mobile number (+91 98XXX XXXXX).');
      return;
    }

    // Check duplicate mobile excluding the active user being edited
    const dup = storageService.checkDuplicateMobile(check.formatted, editingUser.id);
    if (dup.isDuplicate) {
      setEditError(`RESTRICTED: Mobile number (${check.formatted}) is already registered to user "${dup.existingUser?.name}". Each user must have a unique mobile number.`);
      return;
    }

    setIsUpdating(true);
    try {
      const updated = await storageService.updateUser(editingUser.id, {
        name: editName.trim(),
        email: editEmail.trim(),
        mobile: check.formatted,
        role: editRole,
        allowedGroupIds: editAllowedGroupIds,
      });

      if (updated) {
        setUserList((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
      }
      setEditingUser(null);
      if (onRefresh) onRefresh();
    } catch (err: any) {
      setEditError(err.message || 'Failed to update user.');
    } finally {
      setIsUpdating(false);
    }
  };

  // Delete User (Admin Only) - Immediately purges from database and UI
  const handleDeleteUser = async (user: UserType) => {
    if (user.id === 'usr_admin') {
      alert('Master Administrator account (MG) cannot be deleted.');
      return;
    }

    const confirmed = window.confirm(
      `Are you sure you want to permanently delete user "${user.name}" (${user.mobile})?\n\nThis user will be permanently removed from the database and users list. Their mobile number will become available for new registration.`
    );
    if (!confirmed) return;

    // Immediately remove from UI list so it vanishes from screen instantly
    setUserList((prev) => prev.filter((u) => u.id !== user.id));

    try {
      await storageService.deleteUser(user.id);
      if (onRefresh) onRefresh();
    } catch (err: any) {
      alert(err.message || 'Failed to delete user.');
      if (onRefresh) onRefresh();
    }
  };

  // Handle Admin Add Team User & Generate 6-Digit Code with strict duplicate check
  const handleAddTeamUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setTeamError('');
    setCreatedTeamResult(null);

    if (!teamName.trim()) {
      setTeamError('Please enter user full name.');
      return;
    }
    if (!teamEmail.trim()) {
      setTeamError('Please enter user email address.');
      return;
    }

    const check = validateIndianMobile(teamMobile);
    if (!check.valid) {
      setTeamError(check.message || 'Please enter a valid 10-digit Indian mobile number (+91 98XXX XXXXX).');
      return;
    }

    // STRICT CHECK 1: Local database duplicate mobile verification
    const dup = storageService.checkDuplicateMobile(check.formatted);
    if (dup.isDuplicate) {
      setTeamError(`RESTRICTED: Mobile number (${check.formatted}) is already registered to user "${dup.existingUser?.name}". Each user must have a unique mobile number.`);
      return;
    }

    if (teamAllowedGroupIds.length === 0) {
      setTeamError('Please select at least one business & cash group for this user.');
      return;
    }

    setIsAddingTeam(true);
    try {
      const res = await storageService.addUserWithActivationCode({
        name: teamName.trim(),
        email: teamEmail.trim(),
        mobile: check.formatted,
        role: teamRole,
        allowedGroupIds: teamAllowedGroupIds,
      });

      setCreatedTeamResult(res);
      setUserList((prev) => [...prev.filter((u) => u.id !== res.user.id), res.user]);
      if (onRefresh) onRefresh();
    } catch (err: any) {
      setTeamError(err.message || 'Failed to add user with 6-digit code.');
    } finally {
      setIsAddingTeam(false);
    }
  };

  // Step 1: Validate Indian Mobile & Request OTP from Mr. MG
  const handleRequestOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setMobileError('');
    setOtpVerifyMessage(null);

    if (!newName.trim()) {
      setMobileError('Please enter your full name.');
      return;
    }
    if (!newEmail.trim()) {
      setMobileError('Please enter your email address.');
      return;
    }

    const check = validateIndianMobile(newMobile);
    if (!check.valid) {
      setMobileError(check.message || 'Please enter a valid 10-digit Indian mobile number (+91 98XXX XXXXX).');
      return;
    }

    setIsSubmitting(true);
    try {
      const req = storageService.requestUserSignup(newName.trim(), newEmail.trim(), check.formatted);
      setActiveRequest(req);
      setPendingRequests(storageService.getPendingSignups());
      setOtpVerifyMessage({
        success: true,
        text: `OTP generated! Verification details sent to author ${authorName} at ${authorMobile}.`,
      });
    } catch (err: any) {
      setMobileError(err.message || 'Failed to generate OTP request.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Step 2: User Enters OTP received from Mr. MG
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRequest) return;

    if (!enteredOtp.trim() || enteredOtp.trim().length !== 6) {
      setOtpVerifyMessage({
        success: false,
        text: 'Please enter the 6-digit OTP received from Mr. MG.',
      });
      return;
    }

    const result = storageService.verifyUserOtp(activeRequest.mobile, enteredOtp.trim());
    if (result.success && result.user) {
      setOtpVerifyMessage({
        success: true,
        text: result.message,
      });
      onSwitchUser(result.user);
      if (onRefresh) onRefresh();
      setTimeout(() => {
        onClose();
      }, 1500);
    } else {
      setOtpVerifyMessage({
        success: false,
        text: result.message,
      });
    }
  };

  // Author 1-Click Approve in Desk
  const handleAuthorApprove = (req: UserSignupRequest) => {
    const user = storageService.approveSignupByAdmin(req.id);
    setPendingRequests(storageService.getPendingSignups());
    if (user && onRefresh) onRefresh();
  };

  // Execute Admin "Clear All" with 2-digit "13" code
  const handleExecuteClearAll = async () => {
    if (clearAllConfirmText.trim() !== '13') {
      alert('Please enter 2-digit confirmation code "13" to confirm wiping all ledger records.');
      return;
    }

    setIsClearingAll(true);
    try {
      await storageService.clearAllData(currentUser);
      setShowClearAllModal(false);
      setClearAllConfirmText('');
      if (onRefresh) onRefresh();
      alert('All transactions, parties, notes, and tallies have been cleared successfully by Admin MG.');
    } catch (e: any) {
      alert(e.message || 'Failed to clear ledger data.');
    } finally {
      setIsClearingAll(false);
    }
  };

  // Trigger Remote Kill-Switch
  const handleTriggerKillSwitch = () => {
    if (defunctionConfirmText.trim().toUpperCase() !== 'DEFUNCTION') {
      alert('Please type DEFUNCTION to confirm permanent shutdown.');
      return;
    }
    storageService.triggerDefunction(
      currentUser,
      `System decommissioned by Master Administrator ${authorName} (${authorEmail}).`
    );
    setShowDefunctionModal(false);
  };

  // WhatsApp share link for 6-Digit Download/Activation Code & QR Download Link
  const generateDownloadCodeWhatsApp = (userObj: UserType) => {
    const cleanUserPhone = (userObj.mobile || '').replace(/[\s\-\(\)\+]/g, '');
    const code = userObj.activationCode || (userObj.role === 'admin' ? '941406' : '123456');
    const appUrl = lanDownloadUrl || window.location.origin;
    const directLink = `${appUrl}?code=${code}`;

    const text = `*CASHFLOW LEDGER - APP DOWNLOAD & ACCESS CODE*\n\n` +
      `Hello ${userObj.name},\n` +
      `You are invited by Admin MG to download and access CashFlow Ledger.\n\n` +
      `📱 *Step 1: Download / Open App on Mobile or PC:*\n` +
      `${appUrl}\n\n` +
      `🔑 *Step 2: Enter your 6-Digit Download & Activation Code:*\n` +
      `*${code}*\n\n` +
      `⚡ *Direct 1-Click Link:*\n` +
      `${directLink}\n\n` +
      `📷 *Or scan the QR Code Card to open directly on your mobile device.*\n\n` +
      `Regards,\n${authorName} (Author & Administrator)\n${authorMobile}\n` +
      `Enterprise AES-256 GCM Zero-Knowledge Security`;

    if (cleanUserPhone) {
      return `https://wa.me/${cleanUserPhone}?text=${encodeURIComponent(text)}`;
    }
    return `https://wa.me/?text=${encodeURIComponent(text)}`;
  };

  // Pre-generate WhatsApp message for Author
  const generateAuthorWhatsAppLink = (req: UserSignupRequest) => {
    const text = `*CashFlow Ledger - Access Authorization Request*\n\n` +
      `Hello ${authorName},\n` +
      `A new user has registered for the CashFlow Ledger app:\n\n` +
      `👤 *Name:* ${req.name}\n` +
      `📧 *Email:* ${req.email}\n` +
      `📱 *Mobile:* ${req.mobile}\n` +
      `🔑 *Generated Authorization OTP:* ${req.otp}\n\n` +
      `Please provide this OTP to the user to grant app access.\n` +
      `Timestamp: ${new Date(req.requestedAt).toLocaleString()}`;
    return `https://wa.me/919414067123?text=${encodeURIComponent(text)}`;
  };

  // Pre-generate WhatsApp reply to send OTP to user
  const generateUserWhatsAppReply = (req: UserSignupRequest) => {
    const cleanUserPhone = req.mobile.replace(/[\s\-\(\)\+]/g, '');
    const text = `Hello ${req.name},\n\n` +
      `Your authorization OTP for CashFlow Ledger is: *${req.otp}*.\n\n` +
      `Enter this code in the app to activate your session.\n` +
      `- ${authorName} (Author & Administrator)`;
    return `https://wa.me/${cleanUserPhone}?text=${encodeURIComponent(text)}`;
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-sky-100 w-full max-w-xl overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-gradient-to-r from-sky-50 via-white to-blue-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-600 to-blue-600 text-white flex items-center justify-center shadow-sm">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                User Access & Security Console
              </h2>
              <div className="text-[11px] text-slate-500">
                Author & Master Admin: <b className="text-slate-800">{authorName}</b> ({authorMobile})
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex border-b border-slate-100 text-xs font-semibold bg-slate-50/50 overflow-x-auto no-scrollbar">
          <button
            onClick={() => {
              setActiveTab('switch');
              setEditingUser(null);
            }}
            className={`flex-1 min-w-[120px] py-3 text-center transition-colors cursor-pointer ${
              activeTab === 'switch'
                ? 'text-sky-700 border-b-2 border-sky-600 bg-white shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Users ({users.length})
          </button>
          <button
            onClick={() => {
              setActiveTab('add_team');
              setCreatedTeamResult(null);
              setEditingUser(null);
            }}
            className={`flex-1 min-w-[130px] py-3 text-center transition-colors cursor-pointer ${
              activeTab === 'add_team'
                ? 'text-sky-700 border-b-2 border-sky-600 bg-white shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            + Add User & Group
          </button>
          <button
            onClick={() => {
              setActiveTab('new_user');
              setEditingUser(null);
            }}
            className={`flex-1 min-w-[120px] py-3 text-center transition-colors cursor-pointer ${
              activeTab === 'new_user'
                ? 'text-sky-700 border-b-2 border-sky-600 bg-white shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Self-Register OTP
          </button>
          <button
            onClick={() => {
              setActiveTab('author_desk');
              setEditingUser(null);
            }}
            className={`flex-1 min-w-[110px] py-3 text-center transition-colors cursor-pointer ${
              activeTab === 'author_desk'
                ? 'text-sky-700 border-b-2 border-sky-600 bg-white shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Admin / Author
            {pendingRequests.length > 0 && (
              <span className="ml-1.5 px-1.5 py-0.2 rounded-full text-[10px] bg-rose-600 text-white font-bold">
                {pendingRequests.length}
              </span>
            )}
          </button>
        </div>

        <div className="p-6">
          
          {/* TAB 1: User Directory with Edit / Delete & 6-Digit Download Codes */}
          {activeTab === 'switch' && (
            <div className="space-y-4">
              
              {/* If currently editing a user, show inline edit panel */}
              {editingUser ? (
                <div className="p-4 bg-sky-50/60 border border-sky-200 rounded-2xl space-y-3.5">
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-bold text-sky-950 flex items-center gap-1.5">
                      <Edit2 className="w-4 h-4 text-sky-700" />
                      <span>Edit User Profile: {editingUser.name}</span>
                    </div>
                    <button
                      onClick={() => setEditingUser(null)}
                      className="text-xs text-slate-500 hover:text-slate-800 underline"
                    >
                      Cancel
                    </button>
                  </div>

                  {editError && (
                    <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>{editError}</span>
                    </div>
                  )}

                  <form onSubmit={handleSaveEdit} className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 outline-none"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          value={editEmail}
                          onChange={(e) => setEditEmail(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 outline-none"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                          Indian Mobile Number (+91) *
                        </label>
                        <input
                          type="tel"
                          value={editMobile}
                          onChange={(e) => setEditMobile(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 outline-none"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                          System Role
                        </label>
                        <select
                          value={editRole}
                          onChange={(e) => setEditRole(e.target.value as 'user' | 'admin')}
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 outline-none"
                          disabled={editingUser.id === 'usr_admin'}
                        >
                          <option value="user">User (Assigned Group Only)</option>
                          <option value="admin">Admin (All Groups Access)</option>
                        </select>
                      </div>
                    </div>

                    {/* Assigned Business Groups */}
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Assigned Business & Cash Groups (Scoped Access):
                      </label>
                      <div className="space-y-1.5 max-h-32 overflow-y-auto p-2 bg-white border border-slate-200 rounded-xl">
                        {availableGroups.map((grp) => {
                          const isSelected = editAllowedGroupIds.includes(grp.id);
                          return (
                            <label
                              key={grp.id}
                              className="flex items-center gap-2 text-xs p-1.5 rounded-lg hover:bg-slate-50 cursor-pointer"
                            >
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => handleToggleEditGroup(grp.id)}
                                className="w-3.5 h-3.5 rounded text-sky-600 focus:ring-0"
                              />
                              <span className="font-semibold text-slate-800">{grp.name}</span>
                              <span className="text-[10px] text-slate-500">({grp.purpose})</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    <div className="flex gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setEditingUser(null)}
                        className="flex-1 py-2 bg-white border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={isUpdating}
                        className="flex-1 py-2 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                      >
                        {isUpdating ? 'Saving Changes...' : 'Save Changes'}
                      </button>
                    </div>
                  </form>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between text-xs text-slate-600">
                    <span>Manage user accounts, assigned groups, or switch session:</span>
                    <span className="font-semibold text-slate-800">
                      Current: {currentUser.name} ({currentUser.role})
                    </span>
                  </div>

                  <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                    {userList.map((u) => {
                      const isActive = u.id === currentUser.id;
                      const code = u.activationCode || (u.role === 'admin' ? '941406' : '123456');
                      const userGroupNames = availableGroups
                        .filter((g) => (u.allowedGroupIds || []).includes(g.id))
                        .map((g) => g.name);

                      return (
                        <div
                          key={u.id}
                          className={`p-3.5 rounded-2xl border transition-all ${
                            isActive
                              ? 'border-sky-500 bg-sky-50/80 ring-2 ring-sky-500/20 shadow-xs'
                              : 'border-slate-200 hover:border-slate-300 bg-white'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-xl ${u.avatarBg || 'bg-sky-600'} text-white flex items-center justify-center font-bold text-sm shadow-xs shrink-0`}>
                                {u.name.charAt(0)}
                              </div>
                              <div>
                                <div className="text-xs font-bold text-slate-900 flex items-center gap-2">
                                  <span>{u.name}</span>
                                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase ${
                                    u.role === 'admin' ? 'bg-sky-100 text-sky-800' : 'bg-slate-100 text-slate-600'
                                  }`}>
                                    {u.role}
                                  </span>
                                  {isActive && (
                                    <span className="text-[10px] text-sky-700 font-bold bg-white px-2 py-0.5 rounded-md border border-sky-200">
                                      Active Session
                                    </span>
                                  )}
                                </div>
                                <div className="text-[11px] text-slate-600 mt-0.5 flex items-center gap-2 font-mono">
                                  <span>{u.mobile || 'No Mobile'}</span>
                                  <span>•</span>
                                  <span>{u.email}</span>
                                </div>
                                <div className="text-[10px] text-slate-500 mt-0.5 flex items-center gap-1">
                                  <Building className="w-3 h-3 text-slate-400" />
                                  <span>
                                    Group Access: {u.role === 'admin' ? 'All Groups (Universal)' : (userGroupNames.join(', ') || 'Default Group')}
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5">
                              {!isActive && (
                                <button
                                  onClick={() => {
                                    onSwitchUser(u);
                                    onClose();
                                  }}
                                  className="px-2.5 py-1.5 bg-slate-100 hover:bg-sky-600 hover:text-white text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                                  title="Switch active user session"
                                >
                                  Switch
                                </button>
                              )}

                              {currentUser.role === 'admin' && (
                                <>
                                  <button
                                    onClick={() => handleOpenEdit(u)}
                                    className="p-1.5 text-slate-400 hover:text-sky-600 hover:bg-sky-50 rounded-lg transition-colors cursor-pointer"
                                    title="Edit user profile & assigned groups"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                  {u.id !== 'usr_admin' && (
                                    <button
                                      onClick={() => handleDeleteUser(u)}
                                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                      title="Delete user permanently from database"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </>
                              )}
                            </div>
                          </div>

                          {/* 6-Digit Download / Activation Code & QR Share Section */}
                          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                                Download Code:
                              </span>
                              <span className="font-mono font-black text-xs text-sky-800 bg-sky-100/70 px-2 py-0.5 rounded border border-sky-200 tracking-widest">
                                {code}
                              </span>
                            </div>

                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() => handleCopyCode(code)}
                                className="px-2 py-1 text-[11px] text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded flex items-center gap-1 transition-colors cursor-pointer"
                                title="Copy 6-digit code"
                              >
                                <Copy className="w-3 h-3" />
                                <span>Copy</span>
                              </button>

                              <button
                                onClick={() => handleOpenQrModal(u)}
                                className="px-2.5 py-1 text-[11px] text-sky-800 hover:text-sky-900 bg-sky-50 hover:bg-sky-100 border border-sky-200 rounded font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                                title="View and share QR download card"
                              >
                                <QrCode className="w-3.5 h-3.5 text-sky-600" />
                                <span>QR & Code Invite</span>
                              </button>

                              <button
                                onClick={() => handleShareQrCardWhatsApp(u)}
                                className="px-2.5 py-1 text-[11px] text-emerald-800 hover:text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                                title="Share QR & code directly via WhatsApp"
                              >
                                <MessageSquare className="w-3 h-3 text-emerald-600" />
                                <span>WhatsApp</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Lock Device Action */}
                  {onLockDevice && (
                    <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                      <div className="text-[11px] text-slate-500">
                        Lock terminal to password-protected download gate?
                      </div>
                      <button
                        onClick={() => {
                          onClose();
                          onLockDevice();
                        }}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-rose-50 hover:text-rose-700 text-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <LockKeyhole className="w-3.5 h-3.5" />
                        <span>Lock Device to 6-Digit Gate</span>
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* TAB 2: Admin Adds User with Group Selection & 6-Digit Code */}
          {activeTab === 'add_team' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-gradient-to-r from-sky-50 to-blue-50 border border-sky-200/80 rounded-2xl text-xs space-y-1">
                <div className="font-bold text-sky-950 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-sky-700" />
                  <span>Admin User Creation & Group-Scoped Assignment</span>
                </div>
                <p className="text-[11px] text-sky-900 leading-relaxed">
                  Select the business & cash groups for this user. The user will be restricted to accessing only their assigned groups. A unique 6-digit code is generated and can be shared via WhatsApp. Mobile numbers must be strictly unique.
                </p>
              </div>

              {teamError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{teamError}</span>
                </div>
              )}

              {createdTeamResult ? (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-3.5 animate-fadeIn">
                  <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span>User Registered & 6-Digit Download Code Generated!</span>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-emerald-100 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500">Member Name:</span>
                      <span className="font-bold text-slate-800">{createdTeamResult.user.name} ({createdTeamResult.user.role})</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500">Mobile Number:</span>
                      <span className="font-mono font-bold text-slate-800">{createdTeamResult.user.mobile}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500">Assigned Groups:</span>
                      <span className="font-semibold text-sky-800">
                        {availableGroups.filter((g) => (createdTeamResult.user.allowedGroupIds || []).includes(g.id)).map(g => g.name).join(', ') || 'Main Counter'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100">
                      <span className="text-slate-500 font-semibold">6-Digit Download Code:</span>
                      <span className="font-mono font-black text-xl text-emerald-700 tracking-widest bg-emerald-50 px-3 py-0.5 rounded border border-emerald-200">
                        {createdTeamResult.activationCode}
                      </span>
                    </div>

                    {teamQrDataUrl && (
                      <div className="flex flex-col items-center justify-center p-3 bg-white rounded-xl border border-emerald-100 space-y-1.5">
                        <div className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5">
                          <QrCode className="w-3.5 h-3.5 text-sky-600" />
                          <span>App Download & Activation QR Code</span>
                        </div>
                        <div className="p-2 bg-white rounded-lg border border-slate-200 shadow-xs">
                          <img src={teamQrDataUrl} alt="App Download QR" className="w-32 h-32 object-contain" />
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono text-center">
                          Download URL: {lanDownloadUrl || window.location.origin}
                        </span>
                      </div>
                    )}
                  </div>

                  {qrShareNotice && (
                    <div className="p-2.5 bg-emerald-100/80 border border-emerald-300 rounded-xl text-xs text-emerald-900 font-semibold text-center">
                      {qrShareNotice}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                    <button
                      onClick={() => handleCopyCode(createdTeamResult.activationCode)}
                      className="py-2.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Copy className="w-4 h-4 text-slate-500" />
                      <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
                    </button>

                    <button
                      onClick={() => handleDownloadQrCard(createdTeamResult.user)}
                      className="py-2.5 bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      title="Download printable PNG card with QR and Code"
                    >
                      <Download className="w-4 h-4 text-sky-600" />
                      <span>Download QR Card</span>
                    </button>

                    <button
                      onClick={() => handleShareQrCardWhatsApp(createdTeamResult.user)}
                      disabled={isSharingQr}
                      className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>{isSharingQr ? 'Opening WhatsApp...' : 'Share on WhatsApp'}</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="pt-2 text-center">
                    <button
                      onClick={() => {
                        setCreatedTeamResult(null);
                        setTeamName('');
                        setTeamEmail('');
                        setTeamMobile('');
                      }}
                      className="text-xs font-semibold text-emerald-800 hover:underline"
                    >
                      + Add Another Team Member
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleAddTeamUser} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      value={teamName}
                      onChange={(e) => setTeamName(e.target.value)}
                      placeholder="e.g. Ramesh Patel"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-sky-500 outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        value={teamEmail}
                        onChange={(e) => setTeamEmail(e.target.value)}
                        placeholder="ramesh@ledger.com"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-sky-500 outline-none"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        System Role
                      </label>
                      <select
                        value={teamRole}
                        onChange={(e) => setTeamRole(e.target.value as 'user' | 'admin')}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-sky-500 outline-none"
                      >
                        <option value="user">User (Assigned Group Only)</option>
                        <option value="admin">Admin (All Groups Control)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center justify-between">
                      <span>Unique Indian Mobile Number (+91) *</span>
                      <span className="text-[10px] text-slate-500 font-normal">Must not be used by other users</span>
                    </label>
                    <div className="relative">
                      <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center gap-1 text-slate-500 text-xs font-mono font-semibold">
                        <span>🇮🇳 +91</span>
                      </div>
                      <input
                        type="tel"
                        value={teamMobile}
                        onChange={(e) => {
                          setTeamMobile(e.target.value);
                          setTeamError('');
                        }}
                        placeholder="9829012345"
                        className="w-full pl-20 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:border-sky-500 outline-none"
                        required
                      />
                    </div>
                  </div>

                  {/* Business & Cash Group Selection */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center justify-between">
                      <span>Assign Business & Cash Group(s) *</span>
                      <span className="text-[10px] text-slate-500 font-normal">User gets access to selected group only</span>
                    </label>
                    <div className="space-y-1.5 p-3 bg-slate-50 border border-slate-200 rounded-xl max-h-36 overflow-y-auto">
                      {availableGroups.map((grp) => {
                        const isSelected = teamAllowedGroupIds.includes(grp.id);
                        return (
                          <label
                            key={grp.id}
                            className="flex items-center gap-2.5 text-xs p-1.5 rounded-lg hover:bg-white cursor-pointer transition-colors"
                          >
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => handleToggleAddGroup(grp.id)}
                              className="w-4 h-4 rounded text-sky-600 focus:ring-0 cursor-pointer"
                            />
                            <div>
                              <div className="font-bold text-slate-900">{grp.name}</div>
                              <div className="text-[10px] text-slate-500">{grp.purpose}</div>
                            </div>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isAddingTeam}
                      className="w-full py-3 bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>{isAddingTeam ? 'Generating 6-Digit Code...' : 'Add Member & Generate 6-Digit Download Code'}</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* TAB 3: Register User with Indian Mobile & OTP Gate */}
          {activeTab === 'new_user' && (
            <div className="space-y-4">
              
              <div className="p-3.5 bg-gradient-to-r from-sky-50 to-blue-50 border border-sky-200/80 rounded-2xl text-xs space-y-1">
                <div className="font-bold text-sky-950 flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-sky-700" />
                  <span>Indian Mobile & Author OTP Verification Gate</span>
                </div>
                <p className="text-[11px] text-sky-900 leading-relaxed">
                  As per system security protocol, enter your unique Indian mobile number (+91). Clicking "Generate OTP" dispatches your user details directly to author <b>{authorName}</b> at <b>{authorMobile}</b>. Enter the OTP provided by him to gain instant access.
                </p>
              </div>

              {otpVerifyMessage && (
                <div className={`p-3.5 rounded-2xl border text-xs flex items-center gap-2 ${
                  otpVerifyMessage.success
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                    : 'bg-rose-50 border-rose-200 text-rose-900'
                }`}>
                  {otpVerifyMessage.success ? (
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  <span>{otpVerifyMessage.text}</span>
                </div>
              )}

              {mobileError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{mobileError}</span>
                </div>
              )}

              {!activeRequest ? (
                <form onSubmit={handleRequestOtp} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      placeholder="e.g. Ramesh Patel"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-sky-500 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      placeholder="e.g. ramesh@counter.local"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-sky-500 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center justify-between">
                      <span>Unique Indian Mobile Number (+91) *</span>
                      <span className="text-[10px] text-slate-500 font-normal">10 digits starting with 6, 7, 8, or 9</span>
                    </label>
                    <div className="relative">
                      <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center gap-1 text-slate-500 text-xs font-mono font-semibold">
                        <span>🇮🇳 +91</span>
                      </div>
                      <input
                        type="tel"
                        value={newMobile}
                        onChange={(e) => {
                          setNewMobile(e.target.value);
                          setMobileError('');
                        }}
                        placeholder="9414067123"
                        className="w-full pl-20 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:border-sky-500 outline-none"
                        required
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-3 bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>Generate OTP & Send to Mr. MG (+91 9414067123)</span>
                    </button>
                  </div>
                </form>
              ) : (
                <div className="space-y-4">
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-600">Requester:</span>
                      <span className="font-bold text-slate-900">{activeRequest.name}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-600">Mobile:</span>
                      <span className="font-mono font-bold text-slate-900">{activeRequest.mobile}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-600">Author Target:</span>
                      <span className="font-bold text-sky-800">{authorName} ({authorMobile})</span>
                    </div>

                    <div className="pt-2 border-t border-slate-200">
                      <a
                        href={generateAuthorWhatsAppLink(activeRequest)}
                        target="_blank"
                        rel="noreferrer"
                        className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
                      >
                        <MessageSquare className="w-4 h-4" />
                        <span>Send Details to Mr. MG on WhatsApp (1-Click)</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>

                  <form onSubmit={handleVerifyOtp} className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Enter 6-Digit OTP Received from Mr. MG *
                      </label>
                      <input
                        type="text"
                        maxLength={6}
                        value={enteredOtp}
                        onChange={(e) => setEnteredOtp(e.target.value)}
                        placeholder="e.g. 549210"
                        className="w-full text-center tracking-[0.5em] px-4 py-3 bg-sky-50/50 border border-sky-300 rounded-xl font-mono text-xl font-black text-sky-900 focus:bg-white focus:border-sky-500 outline-none"
                        required
                        autoFocus
                      />
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setActiveRequest(null);
                          setEnteredOtp('');
                          setOtpVerifyMessage(null);
                        }}
                        className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
                      >
                        Back
                      </button>
                      <button
                        type="submit"
                        className="flex-2 py-2.5 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
                      >
                        Verify OTP & Activate Account
                      </button>
                    </div>
                  </form>
                </div>
              )}

            </div>
          )}

          {/* TAB 4: Author / Admin Desk (For Mr. MG) & "Clear All" Feature */}
          {activeTab === 'author_desk' && (
            <div className="space-y-5">
              
              {/* Author Profile Card */}
              <div className="p-4 bg-gradient-to-r from-slate-900 to-sky-950 text-white rounded-2xl space-y-2 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-sky-400 uppercase tracking-wider">
                    Author & Master Administrator Desk
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-sky-500/20 text-sky-300 border border-sky-500/30">
                    Authority Root
                  </span>
                </div>
                <div className="text-base font-black">{authorName}</div>
                <div className="text-xs text-slate-300 font-mono space-y-0.5">
                  <div>Mobile: <b className="text-white">{authorMobile}</b></div>
                  <div>Email: <b className="text-white">{authorEmail}</b></div>
                  <div className="pt-1 text-[11px] text-amber-300">
                    Master Bypass Code: <span className="font-mono bg-amber-400/20 px-2 py-0.5 rounded border border-amber-400/30 text-amber-200 font-bold">941406</span> or <span className="font-mono bg-amber-400/20 px-2 py-0.5 rounded border border-amber-400/30 text-amber-200 font-bold">admin123</span>
                  </div>
                </div>
              </div>

              {/* ADMIN ACTION: "CLEAR ALL" BUTTON IN PROFILE PANEL */}
              {currentUser.role === 'admin' && (
                <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FolderMinus className="w-4 h-4 text-amber-700" />
                      <span className="text-xs font-bold text-amber-950 uppercase tracking-wider">
                        Admin Ledger Data Management
                      </span>
                    </div>
                    <span className="text-[10px] font-bold text-amber-800 bg-amber-200/60 px-2 py-0.5 rounded">
                      Admin Only
                    </span>
                  </div>
                  <p className="text-[11px] text-amber-900 leading-relaxed">
                    Need a clean slate? The <b>"Clear All"</b> feature wipes all recorded transactions, parties, reference notes, and tallies across all business groups while maintaining user accounts and business group structures.
                  </p>

                  {!showClearAllModal ? (
                    <button
                      onClick={() => setShowClearAllModal(true)}
                      className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Clear All (Wipe All Operational Data)</span>
                    </button>
                  ) : (
                    <div className="p-3.5 bg-white border border-amber-300 rounded-xl space-y-2.5 animate-fadeIn">
                      <div className="text-xs font-bold text-amber-900">
                        ⚠️ Confirm "Clear All" Data Wipe
                      </div>
                      <p className="text-[11px] text-slate-600">
                        Enter 2-digit confirmation code <b>13</b> below to confirm wiping all ledger records across all devices.
                      </p>
                      <input
                        type="text"
                        maxLength={2}
                        value={clearAllConfirmText}
                        onChange={(e) => setClearAllConfirmText(e.target.value.replace(/\D/g, ''))}
                        placeholder="Enter 13"
                        className="w-full px-3 py-2 bg-slate-50 border border-amber-300 rounded-xl text-center text-lg font-mono font-bold text-slate-900 outline-none"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            setShowClearAllModal(false);
                            setClearAllConfirmText('');
                          }}
                          className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={handleExecuteClearAll}
                          disabled={isClearingAll}
                          className="flex-1 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                        >
                          {isClearingAll ? 'Clearing Data...' : 'Confirm Clear All'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Pending OTP Authorization Queue */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Pending OTP Access Requests ({pendingRequests.length})
                  </h4>
                  <button
                    onClick={() => setPendingRequests(storageService.getPendingSignups())}
                    className="text-[11px] font-semibold text-sky-700 hover:underline flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Refresh</span>
                  </button>
                </div>

                {pendingRequests.length === 0 ? (
                  <div className="p-6 bg-slate-50 border border-slate-200/80 rounded-2xl text-center text-xs text-slate-500">
                    No pending registration requests. All users have been authorized.
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                    {pendingRequests.map((req) => (
                      <div
                        key={req.id}
                        className="p-3.5 bg-white border border-sky-200 rounded-2xl shadow-xs space-y-2.5"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-xs font-bold text-slate-900">{req.name}</div>
                            <div className="text-[11px] text-slate-500 font-mono">
                              {req.mobile} • {req.email}
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] text-slate-400 block">Generated OTP</span>
                            <span className="font-mono font-black text-sm text-sky-700 bg-sky-50 px-2 py-0.5 rounded-md border border-sky-200">
                              {req.otp}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 pt-1">
                          <a
                            href={generateUserWhatsAppReply(req)}
                            target="_blank"
                            rel="noreferrer"
                            className="flex-1 py-1.5 px-3 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 text-[11px] font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                          >
                            <MessageSquare className="w-3 h-3 text-emerald-600" />
                            <span>Share OTP on WhatsApp</span>
                          </a>
                          <button
                            onClick={() => handleAuthorApprove(req)}
                            className="py-1.5 px-3 bg-sky-600 hover:bg-sky-700 text-white text-[11px] font-bold rounded-lg shadow-xs transition-colors cursor-pointer"
                          >
                            1-Click Approve
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* REMOTE KILL-SWITCH / DEFUNCTION SECTION */}
              <div className="pt-4 border-t border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-rose-600" />
                    <span className="text-xs font-bold text-rose-950 uppercase tracking-wider">
                      Emergency Remote Kill-Switch (Defunction)
                    </span>
                  </div>
                </div>
                <p className="text-[11px] text-slate-600">
                  Author-level kill switch: Once activated, the app will immediately defunction across all user phones, tablets, and computers, permanently locking all sessions.
                </p>

                {!showDefunctionModal ? (
                  <button
                    onClick={() => setShowDefunctionModal(true)}
                    className="w-full py-2.5 bg-rose-50 hover:bg-rose-100 border border-rose-300 text-rose-700 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <Ban className="w-4 h-4 text-rose-600" />
                    <span>Trigger Defunction & Lock All Devices</span>
                  </button>
                ) : (
                  <div className="p-4 bg-rose-50 border border-rose-300 rounded-2xl space-y-3">
                    <div className="text-xs font-bold text-rose-900">
                      ⚠️ Confirm Permanent Decommissioning
                    </div>
                    <p className="text-[11px] text-rose-800">
                      Type <b>DEFUNCTION</b> in the field below to permanently lock all connected devices.
                    </p>
                    <input
                      type="text"
                      value={defunctionConfirmText}
                      onChange={(e) => setDefunctionConfirmText(e.target.value)}
                      placeholder="Type DEFUNCTION"
                      className="w-full px-3 py-2 bg-white border border-rose-300 rounded-xl text-xs font-mono font-bold text-rose-900 outline-none"
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={() => setShowDefunctionModal(false)}
                        className="flex-1 py-2 bg-white border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleTriggerKillSwitch}
                        className="flex-1 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition-colors"
                      >
                        Confirm Kill-Switch
                      </button>
                    </div>
                  </div>
                )}
              </div>

            </div>
          )}

        </div>

        <div className="p-3 border-t border-slate-100 text-center text-[10px] text-slate-500 font-mono">
          SUM • Version 2026.v1 • © MG
        </div>

      </div>

      {/* Dedicated QR Code & WhatsApp Invite Card Modal */}
      {qrModalUser && (
        <div className="fixed inset-0 z-60 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl border border-sky-100 text-center animate-fadeIn">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="text-left">
                <div className="text-xs font-bold text-slate-900">{qrModalUser.name}</div>
                <div className="text-[11px] text-slate-500 font-mono">{qrModalUser.mobile}</div>
              </div>
              <button
                onClick={() => setQrModalUser(null)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-gradient-to-b from-sky-50 to-white rounded-2xl border border-sky-100 flex flex-col items-center">
              <span className="text-[11px] font-bold text-sky-900 mb-2">Scan to Download CashFlow Ledger</span>
              {qrModalDataUrl && (
                <img src={qrModalDataUrl} alt="Download QR" className="w-48 h-48 rounded-xl shadow-xs border border-slate-200" />
              )}
              <div className="mt-3 px-3 py-1 bg-emerald-50 border border-emerald-200 rounded-lg">
                <span className="text-[10px] text-emerald-800 font-bold uppercase tracking-wider block">6-Digit Download Code</span>
                <span className="text-lg font-mono font-black text-emerald-700 tracking-widest">
                  {qrModalUser.activationCode || (qrModalUser.role === 'admin' ? '941406' : '123456')}
                </span>
              </div>
            </div>

            {qrShareNotice && (
              <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-medium">
                {qrShareNotice}
              </div>
            )}

            <div className="space-y-2 pt-1">
              <button
                onClick={() => handleShareQrCardWhatsApp(qrModalUser)}
                disabled={isSharingQr}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>{isSharingQr ? 'Sharing via WhatsApp...' : 'Send QR Card & Code via WhatsApp'}</span>
              </button>

              <button
                onClick={() => handleDownloadQrCard(qrModalUser)}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                <span>Download Invite Card Image (PNG)</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
