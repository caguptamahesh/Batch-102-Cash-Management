import React, { useState } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Wallet,
  Users,
  Plus,
  Minus,
  TrendingUp,
  Receipt,
  Scale,
  CreditCard,
  Building2,
  Trash2,
  AlertTriangle,
  X,
  ShieldAlert,
} from 'lucide-react';
import { Group, LedgerDashboardMetrics } from '../types/ledger';

interface DashboardMetricsProps {
  metrics: LedgerDashboardMetrics;
  group: Group;
  onOpenIncomeModal: () => void;
  onOpenExpenseModal: () => void;
  onViewAllTransactions: () => void;
  onViewParties: () => void;
  isAdmin?: boolean;
  onClearAllData?: () => void;
}

export const DashboardMetrics: React.FC<DashboardMetricsProps> = ({
  metrics,
  group,
  onOpenIncomeModal,
  onOpenExpenseModal,
  onViewAllTransactions,
  onViewParties,
  isAdmin = false,
  onClearAllData,
}) => {
  const currency = group?.currency || '₹';
  const [showClearModal, setShowClearModal] = useState(false);
  const [clearCode, setClearCode] = useState('');
  const [clearError, setClearError] = useState('');

  const formatAmount = (val: number) => {
    return val.toLocaleString('en-IN', { maximumFractionDigits: 5 });
  };

  const handleConfirmClear = () => {
    if (clearCode.trim() !== '13') {
      setClearError('Invalid 2-digit code! You must enter "13" to clear all data.');
      return;
    }
    setShowClearModal(false);
    setClearCode('');
    setClearError('');
    onClearAllData?.();
  };

  return (
    <div className="space-y-6">
      {/* Top Left Corner: Admin "Clear All" with 2-Digit Confirmation Code */}
      <div className="flex items-center justify-between">
        {isAdmin ? (
          <button
            onClick={() => {
              setClearCode('');
              setClearError('');
              setShowClearModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg shadow-xs transition-colors cursor-pointer"
            title="Admin Clear All: Wipe all ledger records across all devices and database"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-600" />
            <span>Clear All</span>
          </button>
        ) : (
          <div />
        )}
        <div className="text-[11px] text-slate-500 font-mono">
          SUM • Version 2026.v1 • © MG
        </div>
      </div>

      {/* Hero Action Banner with Two Main Buttons */}
      <div className="bg-gradient-to-r from-sky-500/10 via-blue-500/10 to-indigo-500/10 border border-sky-200/80 rounded-2xl p-6 backdrop-blur-md relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-sky-800 font-semibold text-xs tracking-wider uppercase mb-1">
              <Building2 className="w-4 h-4 text-sky-600" />
              <span>{group?.name}</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-sky-200/70 text-sky-900 font-mono">
                2026.v1
              </span>
            </div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 text-balance">
                SUM
              </h1>
              <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-sky-100 text-sky-800 border border-sky-200">
                Cash Management
              </span>
            </div>
            <p className="text-sm text-slate-600 mt-1 max-w-xl">
              {group?.purpose || 'Maintain cash transactions with directional entries in Lacs, party ledgers & real-time sync.'}
            </p>
          </div>

          {/* TWO MAIN BUTTONS: Income and Expenditure */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 w-full sm:w-auto shrink-0">
            <button
              onClick={onOpenIncomeModal}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-b from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-semibold shadow-md shadow-emerald-500/20 active:translate-y-0.5 transition-all text-sm whitespace-nowrap cursor-pointer"
            >
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                <ArrowDownLeft className="w-4 h-4 text-white" />
              </div>
              <div className="text-left">
                <div className="text-xs text-emerald-100 font-normal leading-tight">Cash Inflow</div>
                <div className="text-sm font-bold leading-tight">+ Income</div>
              </div>
            </button>

            <button
              onClick={onOpenExpenseModal}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-b from-rose-500 to-rose-600 hover:from-rose-600 hover:to-rose-700 text-white font-semibold shadow-md shadow-rose-500/20 active:translate-y-0.5 transition-all text-sm whitespace-nowrap cursor-pointer"
            >
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                <ArrowUpRight className="w-4 h-4 text-white" />
              </div>
              <div className="text-left">
                <div className="text-xs text-rose-100 font-normal leading-tight">Cash Outflow</div>
                <div className="text-sm font-bold leading-tight">- Expenditure</div>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Core Summary Cards (Amounts Recorded in Lacs) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Net Cash Balance */}
        <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-xl p-5 shadow-xs hover:border-sky-200 transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Net Cash Balance
            </span>
            <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 tracking-tight">
            {formatAmount(metrics.netCashBalance)}
          </div>
          <div className="mt-2 text-xs text-slate-500 flex items-center justify-between border-t border-slate-100 pt-2">
            <span>Overall Ledger</span>
            <span className={`font-mono font-medium ${metrics.netOverallPosition >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
              {formatAmount(metrics.netOverallPosition)}
            </span>
          </div>
        </div>

        {/* Card 2: Total Income */}
        <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-xl p-5 shadow-xs hover:border-sky-200 transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-700">
              Total Income / Received
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <ArrowDownLeft className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-emerald-700 tracking-tight">
            {formatAmount(metrics.totalCashReceived)}
          </div>
          <div className="mt-2 text-xs text-slate-500 flex items-center justify-between border-t border-slate-100 pt-2">
            <span>Receivable from Parties</span>
            <span className="font-mono font-medium text-sky-600">
              +{formatAmount(metrics.totalReceivable)}
            </span>
          </div>
        </div>

        {/* Card 3: Total Expenditure */}
        <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-xl p-5 shadow-xs hover:border-sky-200 transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-rose-700">
              Total Expenditure / Paid
            </span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-rose-700 tracking-tight">
            {formatAmount(metrics.totalCashPaid)}
          </div>
          <div className="mt-2 text-xs text-slate-500 flex items-center justify-between border-t border-slate-100 pt-2">
            <span>Payable to Parties</span>
            <span className="font-mono font-medium text-amber-600">
              -{formatAmount(metrics.totalPayable)}
            </span>
          </div>
        </div>

        {/* Card 4: Party Balances Overview */}
        <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-xl p-5 shadow-xs hover:border-sky-200 transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Party Balances
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 tracking-tight">
            {metrics.activePartiesCount} Parties
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Isolated to {group.name}
          </div>
          <div className="mt-2 text-xs text-slate-500 flex items-center justify-between border-t border-slate-100 pt-2">
            <span>Total Journal Entries</span>
            <button
              onClick={onViewAllTransactions}
              className="text-sky-600 hover:text-sky-700 font-semibold hover:underline"
            >
              {metrics.totalTransactionsCount} entries →
            </button>
          </div>
        </div>

      </div>

      {/* Accounting Relationship Guide: Replacing Dr/Cr */}
      <div className="bg-sky-50/70 border border-sky-200/60 rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-sky-600 text-white flex items-center justify-center shrink-0">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-sky-900">
              Standardized Directional Terminology
            </div>
            <div className="text-xs text-sky-700 mt-0.5">
              Clear financial directions: <span className="font-semibold text-emerald-800">"Received from"</span> & <span className="font-semibold text-sky-800">"Receivable from"</span> for Inflows/Assets · <span className="font-semibold text-rose-800">"Paid to"</span> & <span className="font-semibold text-amber-800">"Payable to"</span> for Outflows/Liabilities.
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onViewParties}
            className="px-3.5 py-1.5 text-xs font-semibold text-sky-800 bg-white hover:bg-sky-100 border border-sky-300 rounded-lg shadow-xs transition-colors"
          >
            Open Party Ledger Statements
          </button>
        </div>
      </div>

      {/* Admin Clear All Confirmation Modal with 2-digit "13" verification */}
      {showClearModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-rose-100 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Clear All Application Data
                  </h3>
                  <p className="text-xs text-rose-600 font-medium">
                    Permanent Purge Across All Devices & Database
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowClearModal(false);
                  setClearCode('');
                  setClearError('');
                }}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 space-y-1">
              <p className="font-semibold">⚠️ Attention Administrator MG:</p>
              <p>
                This will instantly delete all transactions, parties, notes, and tallies from every connected phone, tablet, and database.
              </p>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">
                Enter 2-digit confirmation code:
              </label>
              <div className="relative">
                <input
                  type="text"
                  maxLength={2}
                  autoFocus
                  value={clearCode}
                  onChange={(e) => {
                    setClearCode(e.target.value.replace(/\D/g, ''));
                    setClearError('');
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleConfirmClear();
                  }}
                  placeholder="Enter 13"
                  className="w-full text-center font-mono font-bold text-2xl tracking-widest px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-rose-500 focus:ring-2 focus:ring-rose-200 outline-none transition-all"
                />
              </div>
              <p className="text-[11px] text-slate-500 text-center">
                Enter the authorized 2-digit code <span className="font-mono font-bold text-rose-600">"13"</span> to authorize deletion.
              </p>
              {clearError && (
                <p className="text-xs text-rose-600 font-semibold text-center">
                  {clearError}
                </p>
              )}
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => {
                  setShowClearModal(false);
                  setClearCode('');
                  setClearError('');
                }}
                className="flex-1 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmClear}
                className="flex-1 py-2.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-md shadow-rose-600/20 transition-all cursor-pointer"
              >
                Wipe All Data
              </button>
            </div>

            <div className="pt-2 border-t border-slate-100 text-center text-[10px] text-slate-600 font-mono">
              SUM • Version 2026.v1 • © MG
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
