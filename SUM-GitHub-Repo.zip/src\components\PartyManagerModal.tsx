import React, { useState, useEffect } from 'react';
import {
  X,
  Users,
  Phone,
  Mail,
  User,
  Building,
  CreditCard,
  FileText,
  CheckCircle2,
  AlertCircle,
  Plus,
  Save,
  ArrowDownLeft,
  ArrowUpRight,
} from 'lucide-react';
import { Group, Party, User as UserType } from '../types/ledger';
import { storageService } from '../services/storageService';

interface PartyManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (party: Party) => void;
  group: Group;
  currentUser: UserType;
  existingParty?: Party | null;
}

// Indian standard mobile number validator (+91 or 0 prefix, 10 digits starting with 6, 7, 8, 9)
export const validateIndianMobile = (phone: string): { valid: boolean; formatted: string; message?: string } => {
  if (!phone || phone.trim() === '') {
    return { valid: true, formatted: '' }; // Optional for party, but validated if entered
  }

  const cleaned = phone.replace(/[\s\-\(\)]/g, '');
  const indianMobileRegex = /^(?:(?:\+|0{0,2})91)?[6789]\d{9}$/;

  if (!indianMobileRegex.test(cleaned)) {
    return {
      valid: false,
      formatted: phone,
      message: 'Invalid Indian mobile number. Must be 10 digits starting with 6, 7, 8, or 9 (e.g. 9414067123 or +91 9414067123).',
    };
  }

  // Extract pure 10 digits
  const last10Digits = cleaned.slice(-10);
  return {
    valid: true,
    formatted: `+91 ${last10Digits.slice(0, 5)} ${last10Digits.slice(5)}`,
  };
};

export const PartyManagerModal: React.FC<PartyManagerModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  group,
  currentUser,
  existingParty,
}) => {
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [email, setEmail] = useState('');
  const [gstin, setGstin] = useState('');
  const [address, setAddress] = useState('');
  const [openingBalance, setOpeningBalance] = useState('');
  const [openingBalanceType, setOpeningBalanceType] = useState<'RECEIVABLE' | 'PAYABLE' | 'NONE'>('NONE');
  const [notes, setNotes] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if (existingParty) {
      setName(existingParty.name);
      setMobile(existingParty.mobile || '');
      setContactPerson(existingParty.contactPerson || '');
      setEmail(existingParty.email || '');
      setGstin(existingParty.gstin || '');
      setAddress(existingParty.address || '');
      setOpeningBalance(existingParty.openingBalance ? existingParty.openingBalance.toString() : '');
      setOpeningBalanceType(existingParty.openingBalanceType || 'NONE');
      setNotes(existingParty.notes || '');
    } else {
      setName('');
      setMobile('');
      setContactPerson('');
      setEmail('');
      setGstin('');
      setAddress('');
      setOpeningBalance('');
      setOpeningBalanceType('NONE');
      setNotes('');
    }
    setErrorMessage('');
  }, [existingParty, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!name.trim()) {
      setErrorMessage('Party Name is mandatory.');
      return;
    }

    if (!mobile.trim()) {
      setErrorMessage('Party Mobile Number * is mandatory at creation.');
      return;
    }

    // Validate Indian Mobile Number
    const mobileCheck = validateIndianMobile(mobile);
    if (!mobileCheck.valid) {
      setErrorMessage(mobileCheck.message || 'Please enter a valid Indian mobile number.');
      return;
    }

    const rawOpeningBalance = parseFloat(openingBalance) || 0;
    // Store in Lacs per SUM ledger requirements (Requirement 13)
    const openingBalanceInLacs = rawOpeningBalance > 0 ? parseFloat((rawOpeningBalance / 100000).toString()) : 0;

    let savedParty: Party;
    if (existingParty) {
      savedParty = storageService.updateParty(existingParty.id, {
        name: name.trim(),
        mobile: mobileCheck.formatted,
        contactPerson: contactPerson.trim() || undefined,
        email: email.trim() || undefined,
        gstin: gstin.trim().toUpperCase() || undefined,
        address: address.trim() || undefined,
        openingBalance: openingBalanceInLacs,
        openingBalanceType,
        notes: notes.trim() || undefined,
      })!;
    } else {
      savedParty = storageService.createParty({
        groupId: group.id,
        name: name.trim(),
        mobile: mobileCheck.formatted,
        contactPerson: contactPerson.trim() || undefined,
        email: email.trim() || undefined,
        gstin: gstin.trim().toUpperCase() || undefined,
        address: address.trim() || undefined,
        openingBalance: openingBalanceInLacs,
        openingBalanceType,
        notes: notes.trim() || undefined,
        status: 'active',
      });

      // If an opening balance is configured, automatically record an opening ledger entry in Lacs
      if (openingBalanceInLacs > 0 && openingBalanceType !== 'NONE') {
        const txType = openingBalanceType === 'RECEIVABLE' ? 'RECEIVABLE_FROM' : 'PAYABLE_TO';
        storageService.createTransaction({
          groupId: group.id,
          type: txType,
          amount: openingBalanceInLacs,
          partyName: savedParty.name,
          date: new Date().toISOString().slice(0, 10),
          narration: `Opening balance brought forward for ${savedParty.name}`,
        });
      }
    }

    onSuccess(savedParty);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-sky-100 max-w-lg w-full p-6 space-y-4 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-600 to-blue-500 text-white flex items-center justify-center shadow-xs">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {existingParty ? 'Edit Party Profile' : 'Add New Customer / Vendor Party'}
              </h3>
              <div className="text-xs text-slate-500">
                Business Group: {group.name}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-rose-800 text-xs font-semibold">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          
          {/* Party Name */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              Party / Trade Name *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Sharma & Sons Traders, Apex Hardware, M/s Royal Fabrics"
              className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 text-xs font-semibold"
            />
          </div>

          {/* Mobile & Contact Person */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-sky-600" />
                <span>Mobile (Indian Standard) *</span>
              </label>
              <input
                type="text"
                required
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                placeholder="+91 94140 XXXXX"
                className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 text-xs font-mono font-semibold"
              />
              <span className="text-[10px] text-slate-500">
                e.g., 9414067123 or +91 9414067123
              </span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-slate-500" />
                <span>Contact Person</span>
              </label>
              <input
                type="text"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                placeholder="Manager / Owner name"
                className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 text-xs"
              />
            </div>
          </div>

          {/* Email & GSTIN */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <Mail className="w-3.5 h-3.5 text-slate-500" />
                <span>Email Address (Optional)</span>
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="party@example.com"
                className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <Building className="w-3.5 h-3.5 text-slate-500" />
                <span>GSTIN / Tax ID</span>
              </label>
              <input
                type="text"
                value={gstin}
                onChange={(e) => setGstin(e.target.value.toUpperCase())}
                placeholder="22AAAAA0000A1Z5"
                className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 font-mono text-xs uppercase"
              />
            </div>
          </div>

          {/* Opening Balance Setup */}
          <div className="p-3.5 bg-sky-50/60 rounded-xl border border-sky-100 space-y-2">
            <label className="block font-bold text-slate-800">
              Opening Balance Setup
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <span className="text-[11px] text-slate-600 block mb-1">
                  Opening Balance Amount ({group.currency}):
                </span>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={openingBalance}
                  onChange={(e) => setOpeningBalance(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono font-bold text-xs focus:ring-2 focus:ring-sky-500/20"
                />
              </div>

              <div>
                <span className="text-[11px] text-slate-600 block mb-1">
                  Balance Position:
                </span>
                <select
                  value={openingBalanceType}
                  onChange={(e) => setOpeningBalanceType(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold"
                >
                  <option value="NONE">Nil / Zero Balance</option>
                  <option value="RECEIVABLE">Receivable from Party (Asset - They owe us)</option>
                  <option value="PAYABLE">Payable to Party (Liability - We owe them)</option>
                </select>
              </div>
            </div>
            {parseFloat(openingBalance) > 0 && openingBalanceType !== 'NONE' && (
              <div className="text-[11px] text-sky-800 bg-sky-100/70 p-2 rounded-lg font-medium flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                <span>
                  An initial ledger entry of {group.currency}{parseFloat(openingBalance).toLocaleString()} ({openingBalanceType === 'RECEIVABLE' ? 'Receivable from' : 'Payable to'}) will be automatically created.
                </span>
              </div>
            )}
          </div>

          {/* Address & Notes */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Business Address & Delivery Terms
            </label>
            <textarea
              rows={2}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Shop No, Market Road, City, State, PIN..."
              className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 text-xs"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Internal Ledger Notes / Credit Terms
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. 15-day credit cycle, 2% cash discount on same-day settlement"
              className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 text-xs"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 rounded-xl font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl font-bold shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{existingParty ? 'Update Party' : 'Create Party Profile'}</span>
            </button>
          </div>

        </form>

        {/* Footer with App Version and Copyright */}
        <div className="text-center text-[10px] text-slate-400 py-2 border-t border-slate-100">
          SUM • Version 2026.v1 • © MG
        </div>

      </div>
    </div>
  );
};
