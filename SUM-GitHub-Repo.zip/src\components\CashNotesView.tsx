import React, { useState, useMemo } from 'react';
import {
  FileText,
  Pin,
  Plus,
  Search,
  Filter,
  Copy,
  Check,
  Trash2,
  Edit3,
  Calendar,
  AlertCircle,
  Tag,
  Building2,
  Clock,
  Sparkles,
  Download,
  BookOpen,
  CheckCircle2,
  Bookmark,
  Share2,
} from 'lucide-react';
import { Group, NoteColor, NotePriority, NoteTag, ReferenceNote, User } from '../types/ledger';
import { storageService } from '../services/storageService';
import { ExportService } from '../services/exportService';

interface CashNotesViewProps {
  notes: ReferenceNote[];
  group: Group;
  currentUser: User;
  onRefresh: () => void;
  existingParties: string[];
}

const TAG_CONFIG: Record<NoteTag, { label: string; color: string; bg: string }> = {
  GENERAL: { label: 'General Memo', color: 'text-slate-700', bg: 'bg-slate-100' },
  REMINDER: { label: 'Payment Reminder', color: 'text-rose-700', bg: 'bg-rose-100' },
  CASH_HANDOVER: { label: 'Cash Handover / SOP', color: 'text-amber-800', bg: 'bg-amber-100' },
  AUDIT: { label: 'Audit & Check', color: 'text-purple-700', bg: 'bg-purple-100' },
  BANK_DETAILS: { label: 'Bank / IFSC / UPI', color: 'text-sky-800', bg: 'bg-sky-100' },
  TAX_GST: { label: 'GST & Compliance', color: 'text-emerald-800', bg: 'bg-emerald-100' },
  TERMS: { label: 'Credit Terms', color: 'text-indigo-800', bg: 'bg-indigo-100' },
  DISCREPANCY: { label: 'Tally Discrepancy', color: 'text-orange-800', bg: 'bg-orange-100' },
};

const COLOR_CONFIG: Record<
  NoteColor,
  { border: string; bg: string; accent: string; headerBg: string }
> = {
  amber: {
    border: 'border-amber-200',
    bg: 'bg-amber-50/50',
    accent: 'bg-amber-500',
    headerBg: 'bg-amber-100/60',
  },
  blue: {
    border: 'border-sky-200',
    bg: 'bg-sky-50/50',
    accent: 'bg-sky-500',
    headerBg: 'bg-sky-100/60',
  },
  emerald: {
    border: 'border-emerald-200',
    bg: 'bg-emerald-50/50',
    accent: 'bg-emerald-500',
    headerBg: 'bg-emerald-100/60',
  },
  rose: {
    border: 'border-rose-200',
    bg: 'bg-rose-50/50',
    accent: 'bg-rose-500',
    headerBg: 'bg-rose-100/60',
  },
  purple: {
    border: 'border-purple-200',
    bg: 'bg-purple-50/50',
    accent: 'bg-purple-500',
    headerBg: 'bg-purple-100/60',
  },
  slate: {
    border: 'border-slate-200',
    bg: 'bg-slate-50/60',
    accent: 'bg-slate-500',
    headerBg: 'bg-slate-100/70',
  },
};

export const CashNotesView: React.FC<CashNotesViewProps> = ({
  notes,
  group,
  currentUser,
  onRefresh,
  existingParties,
}) => {
  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('ALL');
  const [selectedPriority, setSelectedPriority] = useState<string>('ALL');
  const [copiedNoteId, setCopiedNoteId] = useState<string | null>(null);

  // Note Modal (Create & Edit)
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<ReferenceNote | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formTag, setFormTag] = useState<NoteTag>('GENERAL');
  const [formPriority, setFormPriority] = useState<NotePriority>('NORMAL');
  const [formColor, setFormColor] = useState<NoteColor>('amber');
  const [formIsPinned, setFormIsPinned] = useState(false);
  const [formRelatedParty, setFormRelatedParty] = useState('');

  // Open Editor for New Note
  const handleOpenNewNote = () => {
    setEditingNote(null);
    setFormTitle('');
    setFormContent('');
    setFormTag('GENERAL');
    setFormPriority('NORMAL');
    setFormColor('amber');
    setFormIsPinned(false);
    setFormRelatedParty('');
    setIsEditorOpen(true);
  };

  // Open Editor for Existing Note
  const handleOpenEditNote = (note: ReferenceNote) => {
    setEditingNote(note);
    setFormTitle(note.title);
    setFormContent(note.content);
    setFormTag(note.tag);
    setFormPriority(note.priority);
    setFormColor(note.color);
    setFormIsPinned(note.isPinned);
    setFormRelatedParty(note.relatedParty || '');
    setIsEditorOpen(true);
  };

  // Save Note
  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() && !formContent.trim()) return;

    if (editingNote) {
      storageService.updateReferenceNote(editingNote.id, {
        title: formTitle,
        content: formContent,
        tag: formTag,
        priority: formPriority,
        color: formColor,
        isPinned: formIsPinned,
        relatedParty: formRelatedParty || undefined,
      });
    } else {
      storageService.createReferenceNote({
        groupId: group.id,
        title: formTitle,
        content: formContent,
        tag: formTag,
        priority: formPriority,
        color: formColor,
        isPinned: formIsPinned,
        relatedParty: formRelatedParty || undefined,
      });
    }

    setIsEditorOpen(false);
    onRefresh();
  };

  // Delete Note
  const handleDeleteNote = (id: string, title: string) => {
    if (window.confirm(`Delete reference note "${title}"?`)) {
      storageService.deleteReferenceNote(id);
      onRefresh();
    }
  };

  // Toggle Pin
  const handleTogglePin = (id: string) => {
    storageService.togglePinReferenceNote(id);
    onRefresh();
  };

  // Copy Note Text to Clipboard
  const handleCopyText = (note: ReferenceNote) => {
    const textToCopy = `${note.title}\n-------------------------\n${note.content}${
      note.relatedParty ? `\nParty: ${note.relatedParty}` : ''
    }`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedNoteId(note.id);
    setTimeout(() => {
      setCopiedNoteId((curr) => (curr === note.id ? null : curr));
    }, 2000);
  };

  // Filtered Notes
  const filteredNotes = useMemo(() => {
    return notes.filter((n) => {
      const matchesSearch =
        searchQuery.trim() === '' ||
        n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (n.relatedParty && n.relatedParty.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesTag = selectedTag === 'ALL' || n.tag === selectedTag;
      const matchesPriority = selectedPriority === 'ALL' || n.priority === selectedPriority;

      return matchesSearch && matchesTag && matchesPriority;
    });
  }, [notes, searchQuery, selectedTag, selectedPriority]);

  const pinnedNotes = useMemo(() => filteredNotes.filter((n) => n.isPinned), [filteredNotes]);
  const otherNotes = useMemo(() => filteredNotes.filter((n) => !n.isPinned), [filteredNotes]);

  // Statistics
  const totalNotes = notes.length;
  const pinnedCount = notes.filter((n) => n.isPinned).length;
  const remindersCount = notes.filter((n) => n.tag === 'REMINDER' || n.priority === 'URGENT').length;
  const bankAndSopCount = notes.filter(
    (n) => n.tag === 'BANK_DETAILS' || n.tag === 'CASH_HANDOVER'
  ).length;

  return (
    <div className="space-y-6">
      
      {/* Top Hero Banner */}
      <div className="bg-gradient-to-r from-amber-500/10 via-sky-500/10 to-indigo-500/10 border border-amber-200/80 rounded-2xl p-5 sm:p-6 backdrop-blur-md relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-amber-800 font-semibold text-xs tracking-wider uppercase mb-1">
              <BookOpen className="w-4 h-4 text-amber-600" />
              <span>Reference & Memo Ledger · {group.name}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
              Cash Notes & Reference Panel
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              Record, organize, and quickly retrieve essential instructions, bank account details,
              cash handover procedures, credit reminders, and notes for future reference.
            </p>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <button
              onClick={handleOpenNewNote}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs shadow-md shadow-amber-600/20 active:translate-y-0.5 transition-all cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>+ New Reference Note</span>
            </button>

            <button
              onClick={() => ExportService.exportNotesToText(group, notes)}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-medium text-xs shadow-xs transition-colors"
              title="Download notes as formatted document"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden sm:inline">Export</span>
            </button>
          </div>
        </div>

        {/* 4 Quick Stat Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-amber-200/60 text-xs">
          <div className="bg-white/80 rounded-xl p-3 border border-slate-100">
            <div className="text-slate-500 text-[11px] font-medium">Total Reference Notes</div>
            <div className="text-lg font-bold text-slate-900 mt-0.5">{totalNotes}</div>
          </div>
          <div className="bg-white/80 rounded-xl p-3 border border-slate-100">
            <div className="text-slate-500 text-[11px] font-medium">Pinned & Quick SOPs</div>
            <div className="text-lg font-bold text-amber-700 mt-0.5 flex items-center gap-1">
              <Pin className="w-3.5 h-3.5" />
              <span>{pinnedCount}</span>
            </div>
          </div>
          <div className="bg-white/80 rounded-xl p-3 border border-slate-100">
            <div className="text-slate-500 text-[11px] font-medium">Active Reminders / Urgent</div>
            <div className="text-lg font-bold text-rose-700 mt-0.5">{remindersCount}</div>
          </div>
          <div className="bg-white/80 rounded-xl p-3 border border-slate-100">
            <div className="text-slate-500 text-[11px] font-medium">Bank & Cash Handover</div>
            <div className="text-lg font-bold text-sky-700 mt-0.5">{bankAndSopCount}</div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-sky-100 rounded-2xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search reference notes, bank details, party names, keywords..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 text-slate-900"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
              >
                Clear
              </button>
            )}
          </div>

          {/* Priority Filter */}
          <div className="flex items-center gap-2">
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
            >
              <option value="ALL">All Priorities</option>
              <option value="URGENT">Urgent Priority</option>
              <option value="HIGH">High Priority</option>
              <option value="NORMAL">Normal Priority</option>
              <option value="LOW">Low Priority</option>
            </select>
          </div>
        </div>

        {/* Tag Pills Filter Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
          <button
            onClick={() => setSelectedTag('ALL')}
            className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              selectedTag === 'ALL'
                ? 'bg-amber-600 text-white font-semibold'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            All Notes ({notes.length})
          </button>
          {(Object.keys(TAG_CONFIG) as NoteTag[]).map((tagKey) => {
            const count = notes.filter((n) => n.tag === tagKey).length;
            const cfg = TAG_CONFIG[tagKey];
            return (
              <button
                key={tagKey}
                onClick={() => setSelectedTag(tagKey)}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  selectedTag === tagKey
                    ? 'bg-amber-600 text-white font-semibold shadow-xs'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200/60'
                }`}
              >
                <span>{cfg.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    selectedTag === tagKey ? 'bg-amber-700 text-amber-100' : 'bg-slate-200/80 text-slate-600'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Pinned Notes Section */}
      {pinnedNotes.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Pin className="w-4 h-4 text-amber-600 fill-amber-600" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Pinned References & Standard Operating Procedures ({pinnedNotes.length})
              </h2>
            </div>
            <span className="text-[11px] text-slate-500">Quick-access at top</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pinnedNotes.map((note) => renderNoteCard(note))}
          </div>
        </div>
      )}

      {/* Other Notes Grid */}
      <div className="space-y-3">
        {pinnedNotes.length > 0 && otherNotes.length > 0 && (
          <div className="flex items-center gap-2 pt-2">
            <Bookmark className="w-4 h-4 text-slate-500" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              General Memos & Reminders ({otherNotes.length})
            </h2>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {otherNotes.map((note) => renderNoteCard(note))}
        </div>

        {filteredNotes.length === 0 && (
          <div className="bg-white border border-dashed border-slate-200 rounded-2xl p-12 text-center">
            <FileText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-slate-800">No reference notes match your criteria</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Try adjusting your search query or tag filter, or record a new reference note using the button above.
            </p>
            <button
              onClick={handleOpenNewNote}
              className="mt-4 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-semibold shadow-xs"
            >
              + Create First Note
            </button>
          </div>
        )}
      </div>

      {/* Note Editor Modal */}
      {isEditorOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-amber-100 max-w-xl w-full p-6 space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {editingNote ? 'Edit Reference Note' : 'New Reference Note for Future Reference'}
                </h3>
                <div className="text-xs text-slate-500">
                  Business Group: {group.name}
                </div>
              </div>
              <button
                onClick={() => setIsEditorOpen(false)}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveNote} className="space-y-4 text-xs">
              {/* Title */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Note Title / Headline *
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g., Bank NEFT Details, Cash Handover SOP, Loan Agreement Summary..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 text-xs font-semibold"
                />
              </div>

              {/* Content Textarea */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Reference Text & Instructions *
                </label>
                <textarea
                  required
                  rows={6}
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  placeholder="Type down the memo, bank details, telephone numbers, safe drawer rules, payment conditions, or notes to remember..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 text-xs font-mono leading-relaxed"
                />
              </div>

              {/* Tag & Priority Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Category Tag
                  </label>
                  <select
                    value={formTag}
                    onChange={(e) => setFormTag(e.target.value as NoteTag)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-xs"
                  >
                    {(Object.keys(TAG_CONFIG) as NoteTag[]).map((tagKey) => (
                      <option key={tagKey} value={tagKey}>
                        {TAG_CONFIG[tagKey].label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Priority Level
                  </label>
                  <select
                    value={formPriority}
                    onChange={(e) => setFormPriority(e.target.value as NotePriority)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-xs"
                  >
                    <option value="LOW">Low</option>
                    <option value="NORMAL">Normal</option>
                    <option value="HIGH">High</option>
                    <option value="URGENT">Urgent Action</option>
                  </select>
                </div>
              </div>

              {/* Related Party & Color Theme */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Associated Party (Optional)
                  </label>
                  <select
                    value={formRelatedParty}
                    onChange={(e) => setFormRelatedParty(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-xs"
                  >
                    <option value="">-- None / General --</option>
                    {existingParties.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Color Accent
                  </label>
                  <div className="flex items-center gap-2 py-1">
                    {(['amber', 'blue', 'emerald', 'rose', 'purple', 'slate'] as NoteColor[]).map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setFormColor(c)}
                        className={`w-6 h-6 rounded-full border-2 transition-transform ${
                          c === 'amber'
                            ? 'bg-amber-400'
                            : c === 'blue'
                            ? 'bg-sky-400'
                            : c === 'emerald'
                            ? 'bg-emerald-400'
                            : c === 'rose'
                            ? 'bg-rose-400'
                            : c === 'purple'
                            ? 'bg-purple-400'
                            : 'bg-slate-400'
                        } ${formColor === c ? 'scale-125 border-slate-800' : 'border-transparent'}`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Pin Checkbox */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="pinNoteCheckbox"
                  checked={formIsPinned}
                  onChange={(e) => setFormIsPinned(e.target.checked)}
                  className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4 cursor-pointer"
                />
                <label htmlFor="pinNoteCheckbox" className="font-semibold text-slate-700 cursor-pointer">
                  Pin to top for instant quick reference (e.g. Bank details or daily SOP)
                </label>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditorOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold shadow-xs transition-colors"
                >
                  {editingNote ? 'Save Changes' : 'Save Reference Note'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Requirement 12: Copyright and Version Footer */}
      <footer className="text-center text-xs text-slate-500 font-mono pt-6 border-t border-sky-100">
        SUM • Version 2026.v1 • © MG
      </footer>
    </div>
  );

  function renderNoteCard(note: ReferenceNote) {
    const colorStyle = COLOR_CONFIG[note.color] || COLOR_CONFIG.amber;
    const tagStyle = TAG_CONFIG[note.tag] || TAG_CONFIG.GENERAL;
    const isCopied = copiedNoteId === note.id;

    return (
      <div
        key={note.id}
        className={`bg-white rounded-2xl border ${colorStyle.border} shadow-xs hover:shadow-md transition-all flex flex-col overflow-hidden relative group`}
      >
        {/* Top Header Strip */}
        <div className={`p-3.5 sm:px-4 ${colorStyle.headerBg} border-b ${colorStyle.border} flex items-center justify-between gap-2`}>
          <div className="flex items-center gap-2 min-w-0">
            <span
              className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${tagStyle.bg} ${tagStyle.color}`}
            >
              {tagStyle.label}
            </span>

            {note.priority === 'URGENT' && (
              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-rose-600 text-white animate-pulse">
                Urgent
              </span>
            )}
            {note.priority === 'HIGH' && (
              <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-500 text-white">
                High
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 shrink-0">
            {/* Copy Button */}
            <button
              onClick={() => handleCopyText(note)}
              className="p-1 rounded-md text-slate-500 hover:text-slate-800 hover:bg-white/80 transition-colors"
              title="Copy note text to clipboard"
            >
              {isCopied ? (
                <Check className="w-3.5 h-3.5 text-emerald-600" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
            </button>

            {/* Pin Toggle */}
            <button
              onClick={() => handleTogglePin(note.id)}
              className={`p-1 rounded-md transition-colors ${
                note.isPinned
                  ? 'text-amber-600 bg-amber-100 hover:bg-amber-200'
                  : 'text-slate-400 hover:text-slate-700 hover:bg-white/80'
              }`}
              title={note.isPinned ? 'Unpin note' : 'Pin note to top'}
            >
              <Pin className={`w-3.5 h-3.5 ${note.isPinned ? 'fill-amber-600' : ''}`} />
            </button>

            {/* Edit */}
            <button
              onClick={() => handleOpenEditNote(note)}
              className="p-1 rounded-md text-slate-500 hover:text-slate-800 hover:bg-white/80 transition-colors"
              title="Edit note"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>

            {/* Delete */}
            <button
              onClick={() => handleDeleteNote(note.id, note.title)}
              className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
              title="Delete note"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Card Body */}
        <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
          <div>
            <h3 className="font-bold text-slate-900 text-sm tracking-tight mb-2">
              {note.title}
            </h3>

            <div className="text-xs text-slate-700 whitespace-pre-wrap font-sans leading-relaxed break-words bg-slate-50/70 p-3 rounded-xl border border-slate-100 max-h-56 overflow-y-auto">
              {note.content}
            </div>
          </div>

          {/* Footer Metadata */}
          <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between text-[11px] text-slate-500 gap-2">
            <div className="flex items-center gap-1.5 truncate">
              {note.relatedParty && (
                <span className="font-semibold text-sky-800 bg-sky-50 px-2 py-0.5 rounded-md truncate border border-sky-100">
                  Party: {note.relatedParty}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 text-[10px] text-slate-600 shrink-0">
              <span>by {note.createdBy.name}</span>
              <span>·</span>
              <span>{new Date(note.updatedAt).toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      </div>
    );
  }
};
