const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const rootDir = path.resolve(__dirname, '..');
const outDir = path.join(rootDir, 'temp-github-repo');
const finalDir = 'C:\\Users\\91941\\Downloads\\SUM-GitHub-Repo';
const zipPathDownloads = 'C:\\Users\\91941\\Downloads\\SUM-GitHub-Repo.zip';
const zipPathProject = path.join(rootDir, 'downloads', 'SUM-GitHub-Repo.zip');

console.log('--- Step 1: Cleaning previous temp folders ---');
if (fs.existsSync(outDir)) {
  fs.rmSync(outDir, { recursive: true, force: true });
}
if (fs.existsSync(finalDir)) {
  fs.rmSync(finalDir, { recursive: true, force: true });
}
fs.mkdirSync(outDir, { recursive: true });

function copyFolderRecursiveSync(source, target, excludeSubdirs = []) {
  if (!fs.existsSync(target)) {
    fs.mkdirSync(target, { recursive: true });
  }
  const items = fs.readdirSync(source);
  items.forEach(item => {
    if (excludeSubdirs.includes(item)) return;
    const curSource = path.join(source, item);
    const curTarget = path.join(target, item);
    if (fs.lstatSync(curSource).isDirectory()) {
      copyFolderRecursiveSync(curSource, curTarget, excludeSubdirs);
    } else {
      fs.copyFileSync(curSource, curTarget);
    }
  });
}

console.log('--- Step 2: Copying pristine repository files ---');
const filesToCopy = [
  'README.md',
  'LICENSE',
  '.gitignore',
  '.env.example',
  'package.json',
  'package-lock.json',
  'index.html',
  'metadata.json',
  'vite.config.ts',
  'tsconfig.json',
  'server.js'
];

filesToCopy.forEach(file => {
  const src = path.join(rootDir, file);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, path.join(outDir, file));
    console.log(`Copied: ${file}`);
  }
});

// Copy src/
console.log('Copying src/ directory...');
copyFolderRecursiveSync(path.join(rootDir, 'src'), path.join(outDir, 'src'));

// Copy public/ (excluding public/downloads)
console.log('Copying public/ directory (excluding downloads)...');
copyFolderRecursiveSync(path.join(rootDir, 'public'), path.join(outDir, 'public'), ['downloads']);

// Copy scripts/ (excluding generated temp and JSON)
console.log('Copying scripts/ directory...');
copyFolderRecursiveSync(path.join(rootDir, 'scripts'), path.join(outDir, 'scripts'), ['extracted-prompts.json']);

// Add GITHUB-UPLOAD-GUIDE.md inside the repo folder
const uploadGuideContent = `# How to Upload this Repository to GitHub
**SUM — Cash Management System (Version 2026.v1) • © MG**

Follow any of the three simple methods below to publish your code to GitHub.

---

## Method 1: Upload via Web Browser (No Software Required) 🌐

This is the fastest method if you don't have Git installed:

1. Go to [https://github.com](https://github.com) and log in to your account.
2. Click the **"+"** button at the top-right corner and select **"New repository"**.
3. Fill in the details:
   - **Repository name:** \`sum-cash-management\` (or any name you prefer)
   - **Description:** \`SUM - Cash Management System (Version 2026.v1) © MG\`
   - **Visibility:** Choose **Private** (recommended for proprietary cash ledger) or **Public**.
   - **Do NOT** check "Add a README file" (as we already have a complete one).
4. Click **"Create repository"**.
5. On the next screen, click the link: **"uploading an existing file"**.
6. Open your folder: \`C:\\Users\\91941\\Downloads\\SUM-GitHub-Repo\`
7. Select **all files and folders** inside \`SUM-GitHub-Repo\` and drag-and-drop them into the browser.
8. Scroll to the bottom:
   - Commit title: \`Initial commit: SUM Version 2026.v1 release\`
   - Click **"Commit changes"**.

Your project is now fully published on GitHub!

---

## Method 2: Upload via GitHub Desktop (Easiest GUI) 💻

If you prefer a clean Windows visual interface:

1. Download and install [GitHub Desktop](https://desktop.github.com/).
2. Open GitHub Desktop and log in with your GitHub account.
3. Click **File** > **New Repository...**
   - **Name:** \`sum-cash-management\`
   - **Local Path:** Select your folder or \`C:\\Users\\91941\\Downloads\`
   - Click **Create Repository**.
4. Copy all files from \`C:\\Users\\91941\\Downloads\\SUM-GitHub-Repo\` into your newly created repository folder.
5. GitHub Desktop will immediately detect all the files.
6. Type a summary: \`Release SUM v2026.v1\` and click **"Commit to main"**.
7. Click **"Publish repository"** to upload it to your GitHub account!

---

## Method 3: Upload via Git Command Line ⌨️

If you install Git ([https://git-scm.com/download/win](https://git-scm.com/download/win)):

\`\`\`bash
# 1. Open PowerShell in this folder:
cd "C:\\Users\\91941\\Downloads\\SUM-GitHub-Repo"

# 2. Initialize git repository:
git init -b main

# 3. Add all files:
git add .

# 4. Commit files:
git commit -m "Initial commit: SUM Version 2026.v1 release (c) MG"

# 5. Link to your GitHub remote repository (replace with your repo URL):
git remote add origin https://github.com/<YOUR-USERNAME>/sum-cash-management.git

# 6. Push to GitHub:
git push -u origin main
\`\`\`

---

## 🔒 Security Note
- Your \`.env\` file containing private encryption keys is excluded by \`.gitignore\`.
- Only \`.env.example\` is included so that your production secrets are never exposed on GitHub.
`;

fs.writeFileSync(path.join(outDir, 'GITHUB-UPLOAD-GUIDE.md'), uploadGuideContent);

console.log('--- Step 3: Copying clean repo to User Downloads folder ---');
copyFolderRecursiveSync(outDir, finalDir);

console.log('--- Step 4: Compressing SUM-GitHub-Repo.zip ---');
fs.mkdirSync(path.join(rootDir, 'downloads'), { recursive: true });

// Use PowerShell to compress outDir into SUM-GitHub-Repo.zip
const psCmd = `powershell -Command "Compress-Archive -Path '${outDir}\\*' -DestinationPath '${zipPathDownloads}' -Force"`;
console.log('Executing PowerShell compression...');
execSync(psCmd, { stdio: 'inherit' });

// Copy ZIP into project downloads and public/downloads
fs.copyFileSync(zipPathDownloads, zipPathProject);
if (fs.existsSync(path.join(rootDir, 'public', 'downloads'))) {
  fs.copyFileSync(zipPathDownloads, path.join(rootDir, 'public', 'downloads', 'SUM-GitHub-Repo.zip'));
}
if (fs.existsSync(path.join(rootDir, 'dist', 'downloads'))) {
  fs.copyFileSync(zipPathDownloads, path.join(rootDir, 'dist', 'downloads', 'SUM-GitHub-Repo.zip'));
}

// Clean temp directory
fs.rmSync(outDir, { recursive: true, force: true });

const stats = fs.statSync(zipPathDownloads);
console.log('======================================================');
console.log('SUCCESS! GitHub Package is ready:');
console.log(`1. Clean Folder on Disk:  ${finalDir}`);
console.log(`2. ZIP Archive on Disk:   ${zipPathDownloads} (${stats.size} bytes)`);
console.log(`3. Project Download Link: ${zipPathProject}`);
console.log('======================================================');
