import React, { useState, useEffect } from 'react';
import {
  X,
  Copy,
  Check,
  Pin,
  Save,
  Trash2,
  ExternalLink,
  Sparkles,
  BookOpen,
  ArrowRight,
} from 'lucide-react';
import { Group, ReferenceNote, User } from '../types/ledger';
import { storageService } from '../services/storageService';

interface QuickNotesDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  notes: ReferenceNote[];
  group: Group;
  currentUser: User;
  onNavigateToNotesTab: () => void;
  onRefresh: () => void;
}

export const QuickNotesDrawer: React.FC<QuickNotesDrawerProps> = ({
  isOpen,
  onClose,
  notes,
  group,
  currentUser,
  onNavigateToNotesTab,
  onRefresh,
}) => {
  const [scratchpadText, setScratchpadText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [saveToast, setSaveToast] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setScratchpadText(storageService.getQuickScratchpad());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleScratchpadChange = (text: string) => {
    setScratchpadText(text);
    storageService.setQuickScratchpad(text);
  };

  const handleClearScratchpad = () => {
    if (window.confirm('Clear quick scratchpad memo?')) {
      setScratchpadText('');
      storageService.setQuickScratchpad('');
    }
  };

  const handleConvertPermanently = () => {
    if (!scratchpadText.trim()) return;

    // Use first line as title, rest as content
    const lines = scratchpadText.trim().split('\n');
    const title = lines[0].slice(0, 60);
    const content = lines.slice(1).join('\n') || lines[0];

    storageService.createReferenceNote({
      groupId: group.id,
      title: title || 'Quick Counter Memo',
      content: content || scratchpadText,
      tag: 'GENERAL',
      priority: 'NORMAL',
      color: 'amber',
      isPinned: false,
    });

    setScratchpadText('');
    storageService.setQuickScratchpad('');
    onRefresh();
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 3000);
  };

  const handleCopyNote = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => {
      setCopiedId((curr) => (curr === id ? null : curr));
    }, 2000);
  };

  const pinnedNotes = notes.filter((n) => n.isPinned);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col border-l border-amber-100">
          
          {/* Drawer Header */}
          <div className="p-4 bg-gradient-to-r from-amber-500/10 via-amber-50 to-sky-50 border-b border-amber-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-white flex items-center justify-center shadow-xs">
                <BookOpen className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">
                  Text Panel & Quick Notepad
                </h3>
                <div className="text-[11px] text-slate-600">
                  {group.name} · Auto-saved memo
                </div>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-white/80"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Drawer Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-5 text-xs">
            
            {/* Instant Scratchpad Section */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-800 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Instant Counter Scratchpad</span>
                </label>
                <div className="flex items-center gap-2">
                  {scratchpadText && (
                    <button
                      onClick={handleClearScratchpad}
                      className="text-[11px] text-slate-400 hover:text-rose-600 flex items-center gap-0.5"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Clear</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="relative">
                <textarea
                  rows={6}
                  value={scratchpadText}
                  onChange={(e) => handleScratchpadChange(e.target.value)}
                  placeholder="Jot down quick text, phone numbers, customer requests, temporary amounts, or instructions here... Auto-saves as you type."
                  className="w-full p-3 bg-amber-50/40 border border-amber-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 font-mono text-xs leading-relaxed text-slate-800"
                />
              </div>

              {saveToast && (
                <div className="p-2 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-[11px] font-medium flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Converted to permanent Reference Note!</span>
                </div>
              )}

              <div className="flex items-center justify-between pt-1">
                <button
                  type="button"
                  disabled={!scratchpadText.trim()}
                  onClick={handleConvertPermanently}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white font-semibold text-xs transition-colors"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save as Permanent Reference Note</span>
                </button>

                <button
                  type="button"
                  disabled={!scratchpadText.trim()}
                  onClick={() => {
                    navigator.clipboard.writeText(scratchpadText);
                    setCopiedId('scratchpad');
                    setTimeout(() => setCopiedId(null), 2000);
                  }}
                  className="px-2.5 py-1.5 text-slate-600 hover:bg-slate-100 rounded-lg font-medium flex items-center gap-1"
                >
                  {copiedId === 'scratchpad' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>Copy</span>
                </button>
              </div>
            </div>

            {/* Pinned Reference Notes Quick Copy */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 font-bold text-slate-800">
                  <Pin className="w-3.5 h-3.5 text-amber-600 fill-amber-600" />
                  <span>Pinned Reference Cards ({pinnedNotes.length})</span>
                </div>
                <button
                  onClick={() => {
                    onClose();
                    onNavigateToNotesTab();
                  }}
                  className="text-[11px] text-sky-700 hover:underline flex items-center gap-0.5"
                >
                  <span>View All Notes</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <div className="space-y-2.5">
                {pinnedNotes.map((note) => {
                  const isCopied = copiedId === note.id;
                  return (
                    <div
                      key={note.id}
                      className="p-3 bg-slate-50 hover:bg-amber-50/40 border border-slate-200 rounded-xl transition-all space-y-1.5"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="font-bold text-slate-900 truncate">
                          {note.title}
                        </div>
                        <button
                          onClick={() => handleCopyNote(note.id, `${note.title}\n${note.content}`)}
                          className="p-1 rounded text-slate-500 hover:text-slate-800 hover:bg-white"
                          title="Copy note to clipboard"
                        >
                          {isCopied ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>

                      <div className="text-[11px] text-slate-700 whitespace-pre-wrap font-sans line-clamp-3 bg-white/70 p-2 rounded-lg border border-slate-100">
                        {note.content}
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
                        <span className="font-semibold text-amber-800 bg-amber-100/70 px-1.5 py-0.2 rounded">
                          {note.tag}
                        </span>
                        <span>{new Date(note.updatedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  );
                })}

                {pinnedNotes.length === 0 && (
                  <div className="text-center py-6 text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                    No pinned reference notes yet. Pin notes from the Notes panel to see them here for 1-click access.
                  </div>
                )}
              </div>
            </div>

          </div>

          {/* Drawer Footer */}
          <div className="p-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
            <button
              onClick={() => {
                onClose();
                onNavigateToNotesTab();
              }}
              className="w-full flex items-center justify-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-bold text-xs shadow-xs transition-colors"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Open Full Reference Notes Manager</span>
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
