import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Calendar,
  ArrowDownLeft,
  ArrowUpRight,
  Edit2,
  Trash2,
  History,
  FileSpreadsheet,
  Download,
  Plus,
  Clock,
  User as UserIcon,
} from 'lucide-react';
import { Group, Transaction, TransactionType, User } from '../types/ledger';
import { storageService } from '../services/storageService';

interface TransactionTableProps {
  transactions: Transaction[];
  group: Group;
  currentUser: User;
  onEdit: (tx: Transaction) => void;
  onDelete: (id: string) => void;
  onViewAudit: (tx: Transaction) => void;
  onSelectParty: (partyName: string) => void;
  onOpenIncomeModal: () => void;
  onOpenExpenseModal: () => void;
}

export const TransactionTable: React.FC<TransactionTableProps> = ({
  transactions,
  group,
  currentUser,
  onEdit,
  onDelete,
  onViewAudit,
  onSelectParty,
  onOpenIncomeModal,
  onOpenExpenseModal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | TransactionType>('ALL');
  const [dateFilter, setDateFilter] = useState<'ALL' | 'TODAY' | 'WEEK' | 'MONTH'>('ALL');
  const [selectedPartyFilter, setSelectedPartyFilter] = useState<string>('ALL');

  const currency = group?.currency || '₹';

  // Get list of unique parties in current list
  const partyList = useMemo(() => {
    const set = new Set<string>();
    transactions.forEach((t) => set.add(t.partyName));
    return Array.from(set).sort();
  }, [transactions]);

  // Filtered transactions
  const filtered = useMemo(() => {
    return transactions.filter((tx) => {
      // Search term
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchParty = tx.partyName.toLowerCase().includes(q);
        const matchNarration = (tx.narration || '').toLowerCase().includes(q);
        const matchReceipt = tx.receiptNumber.toLowerCase().includes(q);
        const matchType = storageService.formatTypeLabel(tx.type).toLowerCase().includes(q);
        if (!matchParty && !matchNarration && !matchReceipt && !matchType) return false;
      }

      // Type filter
      if (typeFilter !== 'ALL' && tx.type !== typeFilter) {
        return false;
      }

      // Party filter
      if (selectedPartyFilter !== 'ALL' && tx.partyName !== selectedPartyFilter) {
        return false;
      }

      // Date filter
      if (dateFilter !== 'ALL') {
        const txDate = new Date(tx.date);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (dateFilter === 'TODAY') {
          const isToday = txDate.toISOString().slice(0, 10) === today.toISOString().slice(0, 10);
          if (!isToday) return false;
        } else if (dateFilter === 'WEEK') {
          const oneWeekAgo = new Date(today);
          oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
          if (txDate < oneWeekAgo) return false;
        } else if (dateFilter === 'MONTH') {
          const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
          if (txDate < firstDayOfMonth) return false;
        }
      }

      return true;
    });
  }, [transactions, searchTerm, typeFilter, dateFilter, selectedPartyFilter]);

  const getTypeStyle = (type: TransactionType) => {
    switch (type) {
      case 'RECEIVED_FROM':
        return {
          label: 'Received from',
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          amountClass: 'text-emerald-700 font-bold',
          icon: <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600" />,
        };
      case 'RECEIVABLE_FROM':
        return {
          label: 'Receivable from',
          bg: 'bg-sky-50 text-sky-700 border-sky-200',
          amountClass: 'text-sky-700 font-bold',
          icon: <ArrowDownLeft className="w-3.5 h-3.5 text-sky-600" />,
        };
      case 'PAID_TO':
        return {
          label: 'Paid to',
          bg: 'bg-rose-50 text-rose-700 border-rose-200',
          amountClass: 'text-rose-700 font-bold',
          icon: <ArrowUpRight className="w-3.5 h-3.5 text-rose-600" />,
        };
      case 'PAYABLE_TO':
        return {
          label: 'Payable to',
          bg: 'bg-amber-50 text-amber-700 border-amber-200',
          amountClass: 'text-amber-700 font-bold',
          icon: <ArrowUpRight className="w-3.5 h-3.5 text-amber-600" />,
        };
    }
  };

  return (
    <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-2xl shadow-xs overflow-hidden">
      
      {/* Table Header & Search Filter Bar */}
      <div className="p-4 sm:p-5 border-b border-slate-100 space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Transactions Journal
            </h2>
            <div className="text-xs text-slate-500 mt-0.5">
              Showing {filtered.length} of {transactions.length} entries · Isolated to {group.name}
            </div>
          </div>

          {/* Quick Search */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search party, narration, receipt..."
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:bg-white focus:border-sky-500 focus:ring-1 focus:ring-sky-500 outline-none"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
              >
                ×
              </button>
            )}
          </div>
        </div>

        {/* Filter Controls (Segmented Functional Buttons) */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          {/* Directional Type Filters */}
          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              onClick={() => setTypeFilter('ALL')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                typeFilter === 'ALL'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Types
            </button>
            <button
              onClick={() => setTypeFilter('RECEIVED_FROM')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                typeFilter === 'RECEIVED_FROM'
                  ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                  : 'text-emerald-700 hover:bg-white/60'
              }`}
            >
              Received from
            </button>
            <button
              onClick={() => setTypeFilter('RECEIVABLE_FROM')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                typeFilter === 'RECEIVABLE_FROM'
                  ? 'bg-sky-600 text-white shadow-xs font-semibold'
                  : 'text-sky-700 hover:bg-white/60'
              }`}
            >
              Receivable from
            </button>
            <button
              onClick={() => setTypeFilter('PAID_TO')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                typeFilter === 'PAID_TO'
                  ? 'bg-rose-600 text-white shadow-xs font-semibold'
                  : 'text-rose-700 hover:bg-white/60'
              }`}
            >
              Paid to
            </button>
            <button
              onClick={() => setTypeFilter('PAYABLE_TO')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                typeFilter === 'PAYABLE_TO'
                  ? 'bg-amber-600 text-white shadow-xs font-semibold'
                  : 'text-amber-700 hover:bg-white/60'
              }`}
            >
              Payable to
            </button>
          </div>

          {/* Date Range Quick Filter */}
          <div className="flex items-center gap-1 text-xs">
            <span className="text-slate-600 text-[11px] mr-1 hidden sm:inline">Date:</span>
            {(['ALL', 'TODAY', 'WEEK', 'MONTH'] as const).map((d) => (
              <button
                key={d}
                onClick={() => setDateFilter(d)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                  dateFilter === d
                    ? 'bg-sky-100 text-sky-800 font-semibold'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {d === 'ALL' ? 'All Time' : d === 'TODAY' ? 'Today' : d === 'WEEK' ? '7 Days' : 'This Month'}
              </button>
            ))}
          </div>
        </div>

        {/* Party Filter if multiple parties */}
        {partyList.length > 1 && (
          <div className="flex flex-wrap items-center gap-1.5 text-xs pt-1 border-t border-slate-100">
            <span className="text-[11px] text-slate-600">Filter by Party:</span>
            <button
              onClick={() => setSelectedPartyFilter('ALL')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                selectedPartyFilter === 'ALL'
                  ? 'bg-slate-800 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              All ({partyList.length})
            </button>
            {partyList.slice(0, 8).map((p) => (
              <button
                key={p}
                onClick={() => setSelectedPartyFilter(p)}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                  selectedPartyFilter === p
                    ? 'bg-sky-600 text-white'
                    : 'bg-sky-50 text-sky-800 hover:bg-sky-100'
                }`}
              >
                {p}
              </button>
            ))}
            {selectedPartyFilter !== 'ALL' && (
              <button
                onClick={() => setSelectedPartyFilter('ALL')}
                className="text-[11px] text-rose-600 hover:underline ml-1"
              >
                Clear
              </button>
            )}
          </div>
        )}
      </div>

      {/* Transaction Journal Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
              <th className="py-3 px-4 w-28">Receipt #</th>
              <th className="py-3 px-3 w-28">Date</th>
              <th className="py-3 px-3 w-36">Direction</th>
              <th className="py-3 px-4">Party Name</th>
              <th className="py-3 px-4 text-right">Amount</th>
              <th className="py-3 px-4">Narration</th>
              <th className="py-3 px-4">Audit Signature</th>
              <th className="py-3 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-12 text-center text-slate-500">
                  <div className="max-w-xs mx-auto space-y-3">
                    <p className="text-sm font-medium text-slate-600">No transactions found</p>
                    <p className="text-xs text-slate-500">
                      Try adjusting search filters or record a new cash entry using the buttons below.
                    </p>
                    <div className="flex items-center justify-center gap-2 pt-2">
                      <button
                        onClick={onOpenIncomeModal}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700"
                      >
                        + Record Income
                      </button>
                      <button
                        onClick={onOpenExpenseModal}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-rose-600 rounded-lg hover:bg-rose-700"
                      >
                        - Record Expenditure
                      </button>
                    </div>
                  </div>
                </td>
              </tr>
            ) : (
              filtered.map((tx) => {
                const style = getTypeStyle(tx.type);
                // All users allowed to edit/delete with strict audit logging
                const canModify = true;

                return (
                  <tr
                    key={tx.id}
                    className="hover:bg-sky-50/40 transition-colors group"
                  >
                    {/* Receipt Number */}
                    <td className="py-3 px-4 font-mono font-semibold text-slate-700 whitespace-nowrap">
                      {tx.receiptNumber}
                    </td>

                    {/* Date */}
                    <td className="py-3 px-3 font-mono text-slate-600 whitespace-nowrap">
                      {tx.date}
                    </td>

                    {/* Transaction Direction (Replacing Dr/Cr) */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-semibold border ${style.bg}`}>
                        {style.icon}
                        <span>{style.label}</span>
                      </span>
                    </td>

                    {/* Party Name */}
                    <td className="py-3 px-4 font-medium text-slate-900">
                      <button
                        onClick={() => onSelectParty(tx.partyName)}
                        className="text-left hover:text-sky-700 hover:underline font-semibold"
                        title="Click to view full party ledger statement"
                      >
                        {tx.partyName}
                      </button>
                    </td>

                    {/* Amount */}
                    <td className={`py-3 px-4 text-right font-mono text-sm tabular-nums whitespace-nowrap font-bold ${style.amountClass}`}>
                      {tx.amount.toLocaleString('en-IN', { maximumFractionDigits: 6 })}
                    </td>

                    {/* Narration */}
                    <td className="py-3 px-4 text-slate-600 max-w-xs truncate" title={tx.narration}>
                      {tx.narration || <span className="text-slate-300 italic">None</span>}
                    </td>

                    {/* Audit Stamp */}
                    <td className="py-3 px-4 text-[11px] text-slate-500 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <span className="font-medium text-slate-700">{tx.createdBy.name}</span>
                        <span className="text-slate-400">·</span>
                        <span className="font-mono text-slate-400">{new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                      {tx.updatedBy && (
                        <div className="text-[10px] text-amber-700 font-medium">
                          Edited by {tx.updatedBy.name}
                        </div>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => onViewAudit(tx)}
                          className="p-1 text-slate-400 hover:text-sky-600 rounded hover:bg-sky-50 transition-colors"
                          title="View audit trail for this entry"
                        >
                          <History className="w-4 h-4" />
                        </button>
                        {canModify && (
                          <>
                            <button
                              onClick={() => onEdit(tx)}
                              className="p-1 text-slate-400 hover:text-blue-600 rounded hover:bg-blue-50 transition-colors"
                              title="Edit transaction"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => {
                                if (window.confirm(`Are you sure you want to delete receipt ${tx.receiptNumber} (${tx.partyName} of ${currency}${tx.amount})? This will be recorded in the audit trail.`)) {
                                  onDelete(tx.id);
                                }
                              }}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors"
                              title="Delete transaction (Audited)"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
      <div className="p-3 border-t border-slate-100 text-center text-[10px] text-slate-500 font-mono">
        SUM • Version 2026.v1 • © MG
      </div>
    </div>
  );
};
