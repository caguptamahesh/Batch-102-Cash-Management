import React, { useState, useMemo } from 'react';
import {
  Users,
  Search,
  ArrowDownLeft,
  ArrowUpRight,
  Printer,
  Plus,
  ArrowLeft,
  ExternalLink,
  Scale,
  Calendar,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { Group, PartySummary, Transaction, User } from '../types/ledger';
import { storageService } from '../services/storageService';

interface PartyLedgerViewProps {
  partySummaries: PartySummary[];
  transactions: Transaction[];
  group: Group;
  currentUser: User;
  selectedPartyName?: string | null;
  onSelectParty: (name: string | null) => void;
  onRecordForParty: (partyName: string, flow: 'INCOME' | 'EXPENDITURE') => void;
  onOpenPartyModal?: () => void;
}

export const PartyLedgerView: React.FC<PartyLedgerViewProps> = ({
  partySummaries,
  transactions,
  group,
  currentUser,
  selectedPartyName,
  onSelectParty,
  onRecordForParty,
  onOpenPartyModal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [balanceFilter, setBalanceFilter] = useState<'ALL' | 'RECEIVABLE' | 'PAYABLE' | 'SETTLED'>('ALL');

  const currency = group?.currency || '₹';

  // Filter parties
  const filteredParties = useMemo(() => {
    return partySummaries.filter((p) => {
      if (searchTerm.trim() && !p.partyName.toLowerCase().includes(searchTerm.toLowerCase())) {
        return false;
      }
      if (balanceFilter === 'RECEIVABLE' && p.netBalance <= 0) return false;
      if (balanceFilter === 'PAYABLE' && p.netBalance >= 0) return false;
      if (balanceFilter === 'SETTLED' && p.netBalance !== 0) return false;
      return true;
    });
  }, [partySummaries, searchTerm, balanceFilter]);

  // If a specific party is selected for detailed ledger statement
  const activePartyData = useMemo(() => {
    if (!selectedPartyName) return null;
    const summary = partySummaries.find((p) => p.partyName === selectedPartyName);
    const partyTx = transactions
      .filter((t) => t.partyName === selectedPartyName)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    // Calculate running balance for each transaction
    let running = 0;
    const items = partyTx.map((tx) => {
      if (tx.type === 'RECEIVABLE_FROM' || tx.type === 'PAID_TO') {
        running += tx.amount;
      } else {
        running -= tx.amount;
      }
      return {
        ...tx,
        runningBalance: running,
      };
    });

    return {
      summary,
      transactions: items,
      netBalance: running,
    };
  }, [selectedPartyName, partySummaries, transactions]);

  // Aggregate totals
  const totalReceivablesFromAll = useMemo(() => {
    return partySummaries.reduce((sum, p) => p.netBalance > 0 ? sum + p.netBalance : sum, 0);
  }, [partySummaries]);

  const totalPayablesToAll = useMemo(() => {
    return partySummaries.reduce((sum, p) => p.netBalance < 0 ? sum + Math.abs(p.netBalance) : sum, 0);
  }, [partySummaries]);

  // If viewing a single party's statement
  if (selectedPartyName && activePartyData) {
    const isReceivable = activePartyData.netBalance > 0;
    const isPayable = activePartyData.netBalance < 0;
    const isSettled = activePartyData.netBalance === 0;

    return (
      <div className="space-y-5">
        {/* Navigation & Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white/90 backdrop-blur-sm border border-sky-100 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center gap-3">
            <button
              onClick={() => onSelectParty(null)}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors"
              title="Back to all parties"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Party Statement & Running Ledger
              </div>
              <h2 className="text-xl font-bold text-slate-900">
                {selectedPartyName}
              </h2>
            </div>
          </div>

          {/* Quick Actions for this Party */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onRecordForParty(selectedPartyName, 'INCOME')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Received from {selectedPartyName}</span>
            </button>
            <button
              onClick={() => onRecordForParty(selectedPartyName, 'EXPENDITURE')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>- Paid to {selectedPartyName}</span>
            </button>
            <button
              onClick={() => window.print()}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
              title="Print Party Statement"
            >
              <Printer className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Current Net Position Card for this Party */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          <div className="bg-white border border-sky-100 rounded-xl p-4 shadow-xs">
            <div className="text-xs text-slate-500 uppercase font-semibold">Net Balance Position</div>
            <div className={`text-xl font-mono font-bold mt-1 tabular-nums ${
              isReceivable ? 'text-sky-700' : isPayable ? 'text-rose-700' : 'text-slate-700'
            }`}>
              {isReceivable && `Receivable: ${activePartyData.netBalance.toLocaleString('en-IN', { maximumFractionDigits: 5 })}`}
              {isPayable && `Payable: ${Math.abs(activePartyData.netBalance).toLocaleString('en-IN', { maximumFractionDigits: 5 })}`}
              {isSettled && `Settled (0.00)`}
            </div>
            <div className="text-[11px] text-slate-600 mt-1">
              {isReceivable && 'Party owes this amount to the business'}
              {isPayable && 'Business owes this amount to party'}
              {isSettled && 'All balances reconciled and balanced'}
            </div>
          </div>

          <div className="bg-white border border-sky-100 rounded-xl p-4 shadow-xs">
            <div className="text-xs text-emerald-700 uppercase font-semibold">Total Received</div>
            <div className="text-lg font-mono font-bold text-emerald-700 mt-1 tabular-nums">
              {(activePartyData.summary?.totalReceived || 0).toLocaleString('en-IN', { maximumFractionDigits: 5 })}
            </div>
            <div className="text-[11px] text-slate-600 mt-1">Cash received from party</div>
          </div>

          <div className="bg-white border border-sky-100 rounded-xl p-4 shadow-xs">
            <div className="text-xs text-sky-700 uppercase font-semibold">Total Receivable</div>
            <div className="text-lg font-mono font-bold text-sky-700 mt-1 tabular-nums">
              {(activePartyData.summary?.totalReceivable || 0).toLocaleString('en-IN', { maximumFractionDigits: 5 })}
            </div>
            <div className="text-[11px] text-slate-600 mt-1">Goods or credit supplied</div>
          </div>

          <div className="bg-white border border-sky-100 rounded-xl p-4 shadow-xs">
            <div className="text-xs text-rose-700 uppercase font-semibold">Total Paid to Party</div>
            <div className="text-lg font-mono font-bold text-rose-700 mt-1 tabular-nums">
              {(activePartyData.summary?.totalPaid || 0).toLocaleString('en-IN', { maximumFractionDigits: 5 })}
            </div>
            <div className="text-[11px] text-slate-600 mt-1">Cash payments made to party</div>
          </div>
        </div>

        {/* Detailed Running Statement Table */}
        <div className="bg-white border border-sky-100 rounded-2xl shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">
              Chronological Statement of Account
            </h3>
            <span className="text-xs text-slate-600">
              {activePartyData.transactions.length} entries
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="py-2.5 px-4">Receipt #</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Direction</th>
                  <th className="py-2.5 px-4">Narration</th>
                  <th className="py-2.5 px-4 text-right">Inflow</th>
                  <th className="py-2.5 px-4 text-right">Outflow</th>
                  <th className="py-2.5 px-4 text-right">Running Position</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {activePartyData.transactions.map((tx) => {
                  const isInflow = tx.type === 'RECEIVED_FROM' || tx.type === 'RECEIVABLE_FROM';
                  return (
                    <tr key={tx.id} className="hover:bg-sky-50/30 transition-colors">
                      <td className="py-2.5 px-4 font-mono font-semibold text-slate-700">
                        {tx.receiptNumber}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-600">
                        {tx.date}
                      </td>
                      <td className="py-2.5 px-3 font-medium">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                          tx.type === 'RECEIVED_FROM' ? 'bg-emerald-50 text-emerald-800' :
                          tx.type === 'RECEIVABLE_FROM' ? 'bg-sky-50 text-sky-800' :
                          tx.type === 'PAID_TO' ? 'bg-rose-50 text-rose-800' :
                          'bg-amber-50 text-amber-800'
                        }`}>
                          {storageService.formatTypeLabel(tx.type)}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-slate-600">
                        {tx.narration || '-'}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-emerald-700 font-medium">
                        {isInflow ? tx.amount.toLocaleString('en-IN', { maximumFractionDigits: 5 }) : '-'}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-rose-700 font-medium">
                        {!isInflow ? tx.amount.toLocaleString('en-IN', { maximumFractionDigits: 5 }) : '-'}
                      </td>
                      <td className={`py-2.5 px-4 text-right font-mono font-bold tabular-nums ${
                        tx.runningBalance > 0 ? 'text-sky-700' : tx.runningBalance < 0 ? 'text-rose-700' : 'text-slate-600'
                      }`}>
                        {Math.abs(tx.runningBalance).toLocaleString('en-IN', { maximumFractionDigits: 5 })}
                        <span className="text-[10px] ml-1 font-normal text-slate-600">
                          {tx.runningBalance > 0 ? 'Receivable' : tx.runningBalance < 0 ? 'Payable' : 'Settled'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="p-3 border-t border-slate-100 text-center text-[10px] text-slate-500 font-mono">
            SUM • Version 2026.v1 • © MG
          </div>
        </div>
      </div>
    );
  }

  // Parties Master List View
  return (
    <div className="space-y-5">
      {/* Summary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-xl p-4 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Total Parties with Balances
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1">
            {partySummaries.length} Parties
          </div>
          <div className="text-xs text-slate-600 mt-1">
            Across {group.name} ledger
          </div>
        </div>

        <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-xl p-4 shadow-xs">
          <div className="text-xs font-semibold text-sky-700 uppercase tracking-wider">
            Total Net Receivable from Parties
          </div>
          <div className="text-2xl font-bold font-mono text-sky-700 mt-1 tabular-nums">
            {currency}{totalReceivablesFromAll.toLocaleString()}
          </div>
          <div className="text-xs text-slate-600 mt-1">
            Assets due to business
          </div>
        </div>

        <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-xl p-4 shadow-xs">
          <div className="text-xs font-semibold text-amber-700 uppercase tracking-wider">
            Total Net Payable to Parties
          </div>
          <div className="text-2xl font-bold font-mono text-amber-700 mt-1 tabular-nums">
            {currency}{totalPayablesToAll.toLocaleString()}
          </div>
          <div className="text-xs text-slate-600 mt-1">
            Liabilities owed by business
          </div>
        </div>
      </div>

      {/* Parties Table with Filters */}
      <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-2xl shadow-xs overflow-hidden">
        
        {/* Header & Filter Controls */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Party-wise Balances
            </h2>
            <div className="text-xs text-slate-500 mt-0.5">
              Click any party to view individual ledger statement and running balance
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Filter buttons */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs">
              {(['ALL', 'RECEIVABLE', 'PAYABLE', 'SETTLED'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setBalanceFilter(filter)}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                    balanceFilter === filter
                      ? 'bg-white text-slate-900 shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {filter === 'ALL' ? 'All' :
                   filter === 'RECEIVABLE' ? 'Receivable Only' :
                   filter === 'PAYABLE' ? 'Payable Only' : 'Settled'}
                </button>
              ))}
            </div>

            {/* Search */}
            <div className="relative w-full sm:w-48">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search party..."
                className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:bg-white focus:border-sky-500"
              />
            </div>

            {onOpenPartyModal && (
              <button
                onClick={onOpenPartyModal}
                className="px-3.5 py-1.5 bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white font-bold text-xs rounded-lg shadow-xs transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add Party</span>
              </button>
            )}
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                <th className="py-3 px-4">Party Name</th>
                <th className="py-3 px-3 text-right">Received</th>
                <th className="py-3 px-3 text-right">Receivable</th>
                <th className="py-3 px-3 text-right">Paid</th>
                <th className="py-3 px-3 text-right">Payable</th>
                <th className="py-3 px-4 text-right">Net Position</th>
                <th className="py-3 px-4 text-center">Entries</th>
                <th className="py-3 px-4 text-right">Statement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredParties.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-600">
                    No parties match the filter criteria.
                  </td>
                </tr>
              ) : (
                filteredParties.map((party) => {
                  const isReceivable = party.netBalance > 0;
                  const isPayable = party.netBalance < 0;
                  const isSettled = party.netBalance === 0;

                  return (
                    <tr
                      key={party.partyName}
                      className="hover:bg-sky-50/40 transition-colors group cursor-pointer"
                      onClick={() => onSelectParty(party.partyName)}
                    >
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center font-bold text-xs shrink-0">
                            {party.partyName.charAt(0)}
                          </div>
                          <div>
                            <div className="group-hover:text-sky-700 group-hover:underline">
                              {party.partyName}
                            </div>
                            <div className="text-[10px] text-slate-600">
                              Last active: {party.lastTransactionDate}
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-700">
                        {party.totalReceived.toLocaleString('en-IN', { maximumFractionDigits: 5 })}
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums text-sky-700">
                        {party.totalReceivable.toLocaleString('en-IN', { maximumFractionDigits: 5 })}
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums text-rose-700">
                        {party.totalPaid.toLocaleString('en-IN', { maximumFractionDigits: 5 })}
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums text-amber-700">
                        {party.totalPayable.toLocaleString('en-IN', { maximumFractionDigits: 5 })}
                      </td>

                      {/* Net Balance Position */}
                      <td className="py-3 px-4 text-right font-mono tabular-nums whitespace-nowrap">
                        {isReceivable && (
                          <span className="font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
                            Receivable: {party.netBalance.toLocaleString('en-IN', { maximumFractionDigits: 5 })}
                          </span>
                        )}
                        {isPayable && (
                          <span className="font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                            Payable: {Math.abs(party.netBalance).toLocaleString('en-IN', { maximumFractionDigits: 5 })}
                          </span>
                        )}
                        {isSettled && (
                          <span className="font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                            Settled (0.00)
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center font-mono text-slate-600">
                        {party.transactionCount}
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectParty(party.partyName);
                          }}
                          className="px-2.5 py-1 text-xs font-semibold text-sky-700 hover:text-sky-800 bg-sky-50 hover:bg-sky-100 rounded-lg transition-colors inline-flex items-center gap-1"
                        >
                          <span>View Statement</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        <div className="p-3 border-t border-slate-100 text-center text-[10px] text-slate-500 font-mono">
          SUM • Version 2026.v1 • © MG
        </div>
      </div>
    </div>
  );
};
