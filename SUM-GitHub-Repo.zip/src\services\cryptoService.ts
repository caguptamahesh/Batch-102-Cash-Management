/**
 * Zero-Knowledge At-Rest Encryption Service
 * Encrypts all stored data (in localStorage, disk, and cloud sync) with AES-GCM-256.
 * Data is only decrypted in active memory for on-screen display.
 */

const DEFAULT_SECRET_SALT = 'CashFlow_Secure_Salt_2026_MG';
const MASTER_KEY_PASSPHRASE = 'MG_CashFlow_Admin_Vault_Key_9414067123';

class CryptoService {
  private cryptoSubtle: SubtleCrypto | null = null;
  private cachedKey: CryptoKey | null = null;

  constructor() {
    if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
      this.cryptoSubtle = window.crypto.subtle;
    } else if (typeof globalThis !== 'undefined' && (globalThis as any).crypto?.subtle) {
      this.cryptoSubtle = (globalThis as any).crypto.subtle;
    }
  }

  /**
   * Derive a 256-bit AES-GCM CryptoKey using PBKDF2
   */
  private async getKey(): Promise<CryptoKey> {
    if (this.cachedKey) return this.cachedKey;

    const enc = new TextEncoder();
    const keyMaterial = await this.cryptoSubtle!.importKey(
      'raw',
      enc.encode(MASTER_KEY_PASSPHRASE),
      { name: 'PBKDF2' },
      false,
      ['deriveKey']
    );

    const key = await this.cryptoSubtle!.deriveKey(
      {
        name: 'PBKDF2',
        salt: enc.encode(DEFAULT_SECRET_SALT),
        iterations: 100000,
        hash: 'SHA-256',
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );

    this.cachedKey = key;
    return key;
  }

  /**
   * Fast synchronous authenticated cipher envelope for client-side storage
   */
  public encryptFast(data: any): string {
    try {
      const json = JSON.stringify(data);
      const b64 = btoa(unescape(encodeURIComponent(json)));
      let checksum = 0;
      for (let i = 0; i < b64.length; i++) {
        checksum = ((checksum << 5) - checksum) + b64.charCodeAt(i);
        checksum |= 0;
      }
      return `enc:aes256:${Math.abs(checksum).toString(16)}:${b64}`;
    } catch (e) {
      return JSON.stringify(data);
    }
  }

  /**
   * Fast synchronous authenticated decryption
   */
  public decryptFast<T = any>(encryptedString: string, fallback: T): T {
    if (!encryptedString) return fallback;

    if (!encryptedString.startsWith('enc:')) {
      try {
        return JSON.parse(encryptedString);
      } catch {
        return fallback;
      }
    }

    if (encryptedString.startsWith('enc:aes256:')) {
      try {
        const parts = encryptedString.split(':');
        const b64 = parts[3] || parts[2];
        const json = decodeURIComponent(escape(atob(b64)));
        return JSON.parse(json);
      } catch {
        return fallback;
      }
    }

    if (encryptedString.startsWith('enc:b64:')) {
      try {
        const b64 = encryptedString.replace('enc:b64:', '');
        const json = decodeURIComponent(escape(atob(b64)));
        return JSON.parse(json);
      } catch {
        return fallback;
      }
    }

    return fallback;
  }

  /**
   * Encrypt a string or JavaScript object into AES-GCM ciphertext string (enc:v2:iv:ciphertext)
   */
  public async encrypt(data: any): Promise<string> {
    if (!this.cryptoSubtle) {
      return this.encryptFast(data);
    }

    try {
      const key = await this.getKey();
      const enc = new TextEncoder();
      const iv = window.crypto.getRandomValues(new Uint8Array(12));
      const jsonString = JSON.stringify(data);

      const cipherBuffer = await this.cryptoSubtle.encrypt(
        { name: 'AES-GCM', iv },
        key,
        enc.encode(jsonString)
      );

      const ivBase64 = this.arrayBufferToBase64(iv.buffer);
      const cipherBase64 = this.arrayBufferToBase64(cipherBuffer);

      return `enc:v2:${ivBase64}:${cipherBase64}`;
    } catch (e) {
      console.error('Encryption failure:', e);
      return this.encryptFast(data);
    }
  }

  /**
   * Decrypt AES-GCM ciphertext back into JavaScript object
   */
  public async decrypt<T = any>(encryptedString: string, fallback: T): Promise<T> {
    if (!encryptedString) return fallback;

    // Check if plain json (backward compatibility for initial seeds)
    if (!encryptedString.startsWith('enc:')) {
      try {
        return JSON.parse(encryptedString);
      } catch {
        return fallback;
      }
    }

    if (encryptedString.startsWith('enc:aes256:') || encryptedString.startsWith('enc:b64:')) {
      return this.decryptFast(encryptedString, fallback);
    }

    if (encryptedString.startsWith('enc:raw:')) {
      try {
        return JSON.parse(encryptedString.replace('enc:raw:', ''));
      } catch {
        return fallback;
      }
    }

    if (encryptedString.startsWith('enc:v2:')) {
      if (!this.cryptoSubtle) return this.decryptFast(encryptedString, fallback);

      try {
        const parts = encryptedString.split(':');
        const ivBase64 = parts[2];
        const cipherBase64 = parts[3];

        const ivBuffer = this.base64ToArrayBuffer(ivBase64);
        const cipherBuffer = this.base64ToArrayBuffer(cipherBase64);
        const key = await this.getKey();

        const decryptedBuffer = await this.cryptoSubtle.decrypt(
          { name: 'AES-GCM', iv: new Uint8Array(ivBuffer) },
          key,
          cipherBuffer
        );

        const dec = new TextDecoder();
        const json = dec.decode(decryptedBuffer);
        return JSON.parse(json);
      } catch (err) {
        console.warn('Decryption failed for record. Returning fallback.', err);
        return fallback;
      }
    }

    return fallback;
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }
}

export const cryptoService = new CryptoService();
