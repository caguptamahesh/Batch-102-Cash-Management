const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const rootDir = path.resolve(__dirname, '..');
const downloadsDir = path.join(rootDir, 'downloads');
const publicDownloadsDir = path.join(rootDir, 'public', 'downloads');
const tempDir = path.join(rootDir, 'temp_packages');

// Ensure directories exist
if (!fs.existsSync(downloadsDir)) fs.mkdirSync(downloadsDir, { recursive: true });
if (!fs.existsSync(publicDownloadsDir)) fs.mkdirSync(publicDownloadsDir, { recursive: true });
if (fs.existsSync(tempDir)) fs.rmSync(tempDir, { recursive: true, force: true });
fs.mkdirSync(tempDir, { recursive: true });

console.log('--- Step 1: Building production frontend with Vite ---');
execSync('npm run build', { cwd: rootDir, stdio: 'inherit' });

console.log('--- Step 2: Preparing Package 1 - Web Hosting Bundle ---');
const webHostingDir = path.join(tempDir, 'SUM-2026.v1-WebHosting');
fs.mkdirSync(webHostingDir, { recursive: true });

// Copy dist contents to web hosting bundle
copyFolderRecursiveSync(path.join(rootDir, 'dist'), webHostingDir);

// Add SPA routing configs
// 1. Netlify / Cloudflare _redirects
fs.writeFileSync(path.join(webHostingDir, '_redirects'), '/*  /index.html  200\n');

// 2. Apache / cPanel .htaccess
fs.writeFileSync(path.join(webHostingDir, '.htaccess'), `<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  Header set X-Frame-Options "DENY"
</IfModule>
`);

// 3. Vercel vercel.json
fs.writeFileSync(path.join(webHostingDir, 'vercel.json'), JSON.stringify({
  rewrites: [{ source: "/(.*)", destination: "/index.html" }]
}, null, 2));

// 4. Nginx snippet
fs.writeFileSync(path.join(webHostingDir, 'nginx.conf'), `server {
    listen 80;
    server_name yourdomain.com;
    root /var/www/sum-app;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
}
`);

// 5. README-WebHosting.txt
fs.writeFileSync(path.join(webHostingDir, 'README-WebHosting.txt'), `========================================================================
SUM - Version 2026.v1 (© MG) - WEB HOSTING DEPLOYMENT PACKAGE
========================================================================

This archive contains the pre-compiled, optimized production web application
ready to upload to any static web host or server.

SUPPORTED HOSTING PLATFORMS:
1. cPanel / Shared Hosting / Apache:
   - Upload all files inside this folder directly to your 'public_html' directory.
   - The included '.htaccess' file handles Single-Page Application (SPA) routing automatically.

2. Netlify:
   - Drag and drop this folder directly into the Netlify Dashboard (https://app.netlify.com/drop).
   - The included '_redirects' file ensures seamless URL routing.

3. Vercel:
   - Deploy using the Vercel CLI ('vercel deploy') or connect to GitHub.
   - The included 'vercel.json' configures rewrites automatically.

4. Nginx VPS / Ubuntu:
   - Copy all files to /var/www/sum-app.
   - Use the sample server block from 'nginx.conf'.

FEATURES:
- Full client-side offline storage & encryption
- Responsive layout for iPhone, iPad, Android & Desktop
- "M" App Logo and SUM 2026.v1 branding (© MG)
- Directional Ledger, Cash Notes, Denomination Counter & Voice Assistant

Author & Copyright: Mr. MG (+91 9414067123)
========================================================================
`);

console.log('--- Step 3: Preparing Package 2 - Local Server Hosting Bundle ---');
const localServerDir = path.join(tempDir, 'SUM-2026.v1-LocalServer');
fs.mkdirSync(localServerDir, { recursive: true });

// Copy server.js, package.json
fs.copyFileSync(path.join(rootDir, 'server.js'), path.join(localServerDir, 'server.js'));

// Create production package.json for server
const rootPkg = JSON.parse(fs.readFileSync(path.join(rootDir, 'package.json'), 'utf8'));
const serverPkg = {
  name: "sum-cashflow-server",
  version: "2026.v1",
  description: "SUM Ledger Local Server with WebSocket Sync (© MG)",
  main: "server.js",
  scripts: {
    "start": "node server.js"
  },
  dependencies: {
    "cors": rootPkg.dependencies?.cors || "^2.8.5",
    "express": rootPkg.dependencies?.express || "^4.21.2",
    "ws": rootPkg.dependencies?.ws || "^8.18.0"
  }
};
fs.writeFileSync(path.join(localServerDir, 'package.json'), JSON.stringify(serverPkg, null, 2));

// Copy dist into local server so it serves it out-of-the-box
copyFolderRecursiveSync(path.join(rootDir, 'dist'), path.join(localServerDir, 'dist'));

// Windows 1-click batch launcher
fs.writeFileSync(path.join(localServerDir, 'start-server.bat'), `@echo off
title SUM - Version 2026.v1 Local Server (c) MG
color 0B
echo ========================================================
echo   SUM - CASH MANAGEMENT LOCAL SERVER (Version 2026.v1)
echo   Copyright (c) MG - All Rights Reserved
echo ========================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Node.js is not found in your system PATH!
  echo Please install Node.js from https://nodejs.org
  pause
  exit /b 1
)

if not exist node_modules (
  echo [1/2] Installing required lightweight server modules (express, ws, cors)...
  call npm install --omit=dev
  echo.
)

echo [2/2] Launching SUM Local Server on port 3000...
echo.
start "" http://localhost:3000
node server.js
pause
`);

// Linux / macOS 1-click shell launcher
fs.writeFileSync(path.join(localServerDir, 'start-server.sh'), `#!/bin/bash
echo "========================================================"
echo "  SUM - CASH MANAGEMENT LOCAL SERVER (Version 2026.v1)"
echo "  Copyright (c) MG - All Rights Reserved"
echo "========================================================"
echo ""

if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js is not installed. Please install from https://nodejs.org"
    exit 1
fi

if [ ! -d "node_modules" ]; then
    echo "[1/2] Installing dependencies..."
    npm install --omit=dev
fi

echo "[2/2] Starting server at http://localhost:3000..."
if command -v xdg-open &> /dev/null; then
    xdg-open http://localhost:3000 &
elif command -v open &> /dev/null; then
    open http://localhost:3000 &
fi

node server.js
`);

// Make start-server.sh executable
try { fs.chmodSync(path.join(localServerDir, 'start-server.sh'), '755'); } catch {}

// README-LocalServer.txt
fs.writeFileSync(path.join(localServerDir, 'README-LocalServer.txt'), `========================================================================
SUM - Version 2026.v1 (© MG) - LOCAL SERVER HOSTING PACKAGE
========================================================================

This package provides everything needed to run the SUM Cash Management app
on your local computer, office server, or private local area network (LAN / Wi-Fi).

QUICK START (WINDOWS):
1. Double-click 'start-server.bat'.
2. The server will launch and automatically open http://localhost:3000 in your browser!

QUICK START (MAC / LINUX):
1. Open Terminal in this folder.
2. Run: chmod +x start-server.sh && ./start-server.sh

CONNECTING PHONES & TABLETS ON THE SAME WI-FI:
1. When the server starts, it prints your local IP address in the console:
   e.g. http://192.168.1.X:3000
2. Open that URL on any iPhone, iPad, or Android phone connected to the same Wi-Fi.
3. On iPhones (iOS):
   - For Voice Recognition, open the URL in Google Chrome (googlechrome://).
   - If opened in Safari, the app provides a 1-tap "Open in Chrome" button.
4. All devices stay synchronized in real-time via WebSockets!

SERVER FEATURES:
- Built-in AES-256 encrypted storage
- Automated sync across all connected phones and desktops
- Dedicated Encrypted Backup ("Download Virus.enc")
- Admin remote defunction & 2-digit "13" instant data wipe
- Voice entry (English & Hindi) with "Stop" / "Over" commands

Author & Administrator: Mr. MG (+91 9414067123)
========================================================================
`);

console.log('--- Step 4: Preparing Package 3 - Complete Source Code Bundle ---');
const sourceCodeDir = path.join(tempDir, 'SUM-2026.v1-SourceCode');
fs.mkdirSync(sourceCodeDir, { recursive: true });

// Copy source code files excluding node_modules, dist, temp, git, downloads
const sourceFilesToCopy = [
  'src',
  'public',
  'index.html',
  'package.json',
  'package-lock.json',
  'server.js',
  'vite.config.ts',
  'tsconfig.json',
  'tsconfig.app.json',
  'tsconfig.node.json',
  'README.md'
];

for (const item of sourceFilesToCopy) {
  const srcPath = path.join(rootDir, item);
  if (fs.existsSync(srcPath)) {
    const destPath = path.join(sourceCodeDir, item);
    if (fs.statSync(srcPath).isDirectory()) {
      copyFolderRecursiveSync(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

fs.writeFileSync(path.join(sourceCodeDir, 'README-SourceCode.txt'), `========================================================================
SUM - Version 2026.v1 (© MG) - COMPLETE SOURCE CODE
========================================================================

DEVELOPMENT SETUP:
1. Ensure Node.js (v18+) is installed.
2. Run: npm install
3. Start development server: npm run dev
4. Build production: npm run build
5. Start local server with sync: node server.js

TECH STACK:
- React 19 + TypeScript + Vite
- Tailwind CSS
- Web Speech API + VoiceService
- WebSockets for multi-device real-time sync
- Express.js backend with local AES-256 encryption

Author & Administrator: Mr. MG (+91 9414067123)
========================================================================
`);

console.log('--- Step 5: Compressing to ZIP archives using PowerShell ---');

const zip1 = path.join(downloadsDir, 'SUM-2026.v1-WebHosting.zip');
const zip2 = path.join(downloadsDir, 'SUM-2026.v1-LocalServer.zip');
const zip3 = path.join(downloadsDir, 'SUM-2026.v1-SourceCode.zip');

if (fs.existsSync(zip1)) fs.unlinkSync(zip1);
if (fs.existsSync(zip2)) fs.unlinkSync(zip2);
if (fs.existsSync(zip3)) fs.unlinkSync(zip3);

// Compress each folder
console.log('Compressing WebHosting bundle...');
execSync(`powershell -NoProfile -Command "Compress-Archive -Path '${webHostingDir}\\*' -DestinationPath '${zip1}' -Force"`, { stdio: 'inherit' });

console.log('Compressing LocalServer bundle...');
execSync(`powershell -NoProfile -Command "Compress-Archive -Path '${localServerDir}\\*' -DestinationPath '${zip2}' -Force"`, { stdio: 'inherit' });

console.log('Compressing SourceCode bundle...');
execSync(`powershell -NoProfile -Command "Compress-Archive -Path '${sourceCodeDir}\\*' -DestinationPath '${zip3}' -Force"`, { stdio: 'inherit' });

// Also copy ZIPs into public/downloads and dist/downloads so browser can download them directly
console.log('--- Step 6: Mirroring ZIP files into public/downloads and dist/downloads ---');
const distDownloadsDir = path.join(rootDir, 'dist', 'downloads');
if (!fs.existsSync(distDownloadsDir)) fs.mkdirSync(distDownloadsDir, { recursive: true });

for (const zip of [zip1, zip2, zip3]) {
  const filename = path.basename(zip);
  fs.copyFileSync(zip, path.join(publicDownloadsDir, filename));
  fs.copyFileSync(zip, path.join(distDownloadsDir, filename));
}

// Clean up temp dir
try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch {}

console.log('\n======================================================');
console.log('SUCCESS! All 3 packages created:');
console.log('1. Web Hosting Package:   ', zip1, `(${fs.statSync(zip1).size} bytes)`);
console.log('2. Local Server Package:  ', zip2, `(${fs.statSync(zip2).size} bytes)`);
console.log('3. Source Code Package:    ', zip3, `(${fs.statSync(zip3).size} bytes)`);
console.log('======================================================\n');

function copyFolderRecursiveSync(source, target) {
  if (!fs.existsSync(target)) fs.mkdirSync(target, { recursive: true });

  const files = fs.readdirSync(source);
  for (const file of files) {
    const curSource = path.join(source, file);
    const curTarget = path.join(target, file);

    if (fs.lstatSync(curSource).isDirectory()) {
      copyFolderRecursiveSync(curSource, curTarget);
    } else {
      fs.copyFileSync(curSource, curTarget);
    }
  }
}
