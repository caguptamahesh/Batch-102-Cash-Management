import { Group, PartySummary, Transaction, ReferenceNote, CashTallySession } from '../types/ledger';
import { storageService } from './storageService';

export class ExportService {
  /**
   * Export transactions as CSV
   */
  public static exportToCSV(group: Group, transactions: Transaction[]): void {
    const headers = [
      'Receipt No',
      'Date',
      'Transaction Type',
      'Party Name',
      'Amount',
      'Narration',
      'Recorded By',
      'Recorded Role',
      'Created Timestamp',
      'Last Modified By',
      'Status',
    ];

    const rows = transactions.map((t) => [
      `"${t.receiptNumber}"`,
      `"${t.date}"`,
      `"${storageService.formatTypeLabel(t.type)}"`,
      `"${t.partyName.replace(/"/g, '""')}"`,
      t.amount,
      `"${(t.narration || '').replace(/"/g, '""')}"`,
      `"${t.createdBy.name}"`,
      `"${t.createdBy.role}"`,
      `"${new Date(t.createdAt).toLocaleString()}"`,
      `"${t.updatedBy ? t.updatedBy.name : '-'}"`,
      `"${t.status}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const filename = `${group.name.replace(/[^a-zA-Z0-9]/g, '_')}_SUM_Ledger_${new Date().toISOString().slice(0, 10)}.csv`;
    
    this.downloadBlob(blob, filename);
  }

  /**
   * Export transactions to Excel (HTML table MIME type which opens natively in Microsoft Excel)
   */
  public static exportToExcel(group: Group, transactions: Transaction[], partySummaries: PartySummary[]): void {
    const formatType = (type: Transaction['type']) => storageService.formatTypeLabel(type);

    let html = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>SUM Ledger</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
        <meta http-equiv="content-type" content="text/plain; charset=UTF-8"/>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Arial, sans-serif; }
          table { border-collapse: collapse; width: 100%; margin-bottom: 24px; }
          th { background-color: #0284c7; color: #ffffff; padding: 10px; border: 1px solid #cbd5e1; text-align: left; }
          td { padding: 8px 10px; border: 1px solid #e2e8f0; font-size: 13px; }
          .num { text-align: right; font-family: monospace; }
          .income { color: #047857; font-weight: bold; }
          .expense { color: #b91c1c; font-weight: bold; }
          .title { font-size: 20px; font-weight: bold; color: #0369a1; padding: 10px 0; }
          .subtitle { font-size: 13px; color: #64748b; margin-bottom: 12px; }
        </style>
      </head>
      <body>
        <div class="title">${group.name} - SUM Cash Statement (Version 2026.v1)</div>
        <div class="subtitle">Purpose: ${group.purpose} | Generated on ${new Date().toLocaleString()}</div>
        
        <h3>1. Transaction Journal</h3>
        <table>
          <thead>
            <tr>
              <th>Receipt No</th>
              <th>Date</th>
              <th>Type</th>
              <th>Party Name</th>
              <th>Amount</th>
              <th>Narration</th>
              <th>Recorded By</th>
              <th>Timestamp</th>
            </tr>
          </thead>
          <tbody>
    `;

    transactions.forEach((tx) => {
      const isIncome = tx.type === 'RECEIVED_FROM' || tx.type === 'RECEIVABLE_FROM';
      html += `
        <tr>
          <td><b>${tx.receiptNumber}</b></td>
          <td>${tx.date}</td>
          <td class="${isIncome ? 'income' : 'expense'}">${formatType(tx.type)}</td>
          <td><b>${tx.partyName}</b></td>
          <td class="num">${tx.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 5 })}</td>
          <td>${tx.narration || '-'}</td>
          <td>${tx.createdBy.name} (${tx.createdBy.role})</td>
          <td>${new Date(tx.createdAt).toLocaleDateString()}</td>
        </tr>
      `;
    });

    html += `
          </tbody>
        </table>

        <h3>2. Party-wise Balances</h3>
        <table>
          <thead>
            <tr>
              <th>Party Name</th>
              <th>Received from</th>
              <th>Receivable from</th>
              <th>Paid to</th>
              <th>Payable to</th>
              <th>Net Balance Position</th>
              <th>Transactions</th>
            </tr>
          </thead>
          <tbody>
    `;

    partySummaries.forEach((p) => {
      const posLabel = p.netBalance > 0 ? `Receivable: ${p.netBalance.toLocaleString()}` :
                       p.netBalance < 0 ? `Payable: ${Math.abs(p.netBalance).toLocaleString()}` :
                       'Settled';
      html += `
        <tr>
          <td><b>${p.partyName}</b></td>
          <td class="num">${p.totalReceived.toLocaleString()}</td>
          <td class="num">${p.totalReceivable.toLocaleString()}</td>
          <td class="num">${p.totalPaid.toLocaleString()}</td>
          <td class="num">${p.totalPayable.toLocaleString()}</td>
          <td><b>${posLabel}</b></td>
          <td>${p.transactionCount}</td>
        </tr>
      `;
    });

    html += `
          </tbody>
        </table>
      </body>
      </html>
    `;

    const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const filename = `${group.name.replace(/[^a-zA-Z0-9]/g, '_')}_Report_${new Date().toISOString().slice(0, 10)}.xls`;
    this.downloadBlob(blob, filename);
  }

  /**
   * Export Reference Notes as clean Markdown / Plain Text
   */
  public static exportNotesToText(group: Group, notes: ReferenceNote[]): void {
    let output = `# CASHFLOW LEDGER - REFERENCE NOTES & MEMOS\n`;
    output += `Business Group: ${group.name} (${group.purpose})\n`;
    output += `Generated At: ${new Date().toLocaleString()}\n`;
    output += `Total Notes: ${notes.length}\n`;
    output += `========================================================\n\n`;

    notes.forEach((note, idx) => {
      output += `### ${idx + 1}. ${note.title} ${note.isPinned ? '[PINNED]' : ''}\n`;
      output += `Tag: ${note.tag} | Priority: ${note.priority}\n`;
      if (note.relatedParty) output += `Related Party: ${note.relatedParty}\n`;
      output += `Recorded By: ${note.createdBy.name} (${note.createdBy.role})\n`;
      output += `Date: ${new Date(note.createdAt).toLocaleString()}\n`;
      output += `--------------------------------------------------------\n`;
      output += `${note.content}\n`;
      output += `\n========================================================\n\n`;
    });

    const blob = new Blob([output], { type: 'text/markdown;charset=utf-8;' });
    const filename = `${group.name.replace(/[^a-zA-Z0-9]/g, '_')}_Reference_Notes_${new Date().toISOString().slice(0, 10)}.md`;
    this.downloadBlob(blob, filename);
  }

  /**
   * Export Reference Notes as CSV
   */
  public static exportNotesToCSV(group: Group, notes: ReferenceNote[]): void {
    const headers = ['Title', 'Tag', 'Priority', 'Pinned', 'Related Party', 'Content', 'Author', 'Created Date'];
    const rows = notes.map((n) => [
      `"${n.title.replace(/"/g, '""')}"`,
      `"${n.tag}"`,
      `"${n.priority}"`,
      n.isPinned ? 'Yes' : 'No',
      `"${(n.relatedParty || '').replace(/"/g, '""')}"`,
      `"${n.content.replace(/"/g, '""')}"`,
      `"${n.createdBy.name}"`,
      `"${new Date(n.createdAt).toLocaleDateString()}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const filename = `${group.name.replace(/[^a-zA-Z0-9]/g, '_')}_Reference_Notes_${new Date().toISOString().slice(0, 10)}.csv`;
    this.downloadBlob(blob, filename);
  }

  /**
   * Export Cash Tally Slip as Text Slip
   */
  public static exportTallySlip(group: Group, tally: CashTallySession): void {
    let slip = `========================================================\n`;
    slip += `          CASH TALLY & DRAWER CLOSING SLIP              \n`;
    slip += `========================================================\n`;
    slip += `Business: ${group.name}\n`;
    slip += `Date:     ${tally.date}\n`;
    slip += `Time:     ${new Date(tally.timestamp).toLocaleTimeString()}\n`;
    slip += `Verified: ${tally.verifiedBy.name} (${tally.verifiedBy.role})\n`;
    slip += `--------------------------------------------------------\n`;
    slip += `DENOMINATION           QTY                AMOUNT (${group.currency})\n`;
    slip += `--------------------------------------------------------\n`;

    const d = tally.denominations;
    const addLine = (denom: number, count?: number) => {
      if (count && count > 0) {
        const amt = denom * count;
        slip += `${(group.currency + denom).padEnd(20)} ${count.toString().padEnd(15)} ${group.currency}${amt.toLocaleString()}\n`;
      }
    };

    addLine(2000, d.d2000);
    addLine(500, d.d500);
    addLine(200, d.d200);
    addLine(100, d.d100);
    addLine(50, d.d50);
    addLine(20, d.d20);
    addLine(10, d.d10);
    addLine(5, d.d5);
    addLine(2, d.d2);
    addLine(1, d.d1);
    if (d.coins && d.coins > 0) {
      slip += `Mixed Coins         ${d.coins.toString().padEnd(15)} ${group.currency}${d.coins.toLocaleString()}\n`;
    }

    slip += `--------------------------------------------------------\n`;
    slip += `TOTAL PHYSICAL CASH:            ${group.currency}${tally.totalPhysicalCash.toLocaleString()}\n`;
    slip += `SYSTEM LEDGER BALANCE:          ${group.currency}${tally.systemCashBalance.toLocaleString()}\n`;
    const varText = tally.variance === 0 ? 'EXACT MATCH' : tally.variance > 0 ? `+${group.currency}${tally.variance.toLocaleString()} (SURPLUS)` : `-${group.currency}${Math.abs(tally.variance).toLocaleString()} (DEFICIT)`;
    slip += `VARIANCE:                       ${varText}\n`;
    slip += `--------------------------------------------------------\n`;
    if (tally.notes) {
      slip += `Notes: ${tally.notes}\n`;
      slip += `--------------------------------------------------------\n`;
    }
    slip += `Cashier Signature: __________________\n`;
    slip += `Supervisor Sign:   __________________\n`;
    slip += `========================================================\n`;

    const blob = new Blob([slip], { type: 'text/plain;charset=utf-8;' });
    const filename = `Cash_Tally_Slip_${tally.date}.txt`;
    this.downloadBlob(blob, filename);
  }

  private static downloadBlob(blob: Blob, filename: string): void {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 200);
  }
}
