import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  Smartphone,
  Wifi,
  Copy,
  Check,
  X,
  ExternalLink,
  Laptop,
  HelpCircle,
  Sparkles,
  QrCode,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';

interface MobileConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileConnectModal: React.FC<MobileConnectModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [lanIp, setLanIp] = useState<string>('192.168.29.102');
  const [port, setPort] = useState<string>('3000');
  const [copied, setCopied] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  // Derive mobile URL
  const mobileUrl = `http://${lanIp}:${port}`;

  // Fetch actual network configuration from local server if available, or fall back to window.location
  useEffect(() => {
    if (!isOpen) return;

    let isMounted = true;
    const detectNetwork = async () => {
      try {
        const portToUse = window.location.port || '3000';
        setPort(portToUse);

        // Try querying the local server /api/network endpoint
        const res = await fetch('/api/network');
        if (res.ok) {
          const data = await res.json();
          if (data.ip && isMounted) {
            setLanIp(data.ip);
          }
        } else {
          // If window.location.hostname is already an IP, use that
          if (window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
            if (isMounted) setLanIp(window.location.hostname);
          }
        }
      } catch (err) {
        // Fallback to detected LAN IP
        if (window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
          if (isMounted) setLanIp(window.location.hostname);
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    detectNetwork();

    return () => {
      isMounted = false;
    };
  }, [isOpen]);

  // Generate QR Code whenever mobileUrl changes
  useEffect(() => {
    if (!isOpen) return;

    QRCode.toDataURL(mobileUrl, {
      width: 250,
      margin: 2,
      color: {
        dark: '#0369a1', // sky-700
        light: '#ffffff',
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error('QR code generation failed', err));
  }, [mobileUrl, isOpen]);

  if (!isOpen) return null;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(mobileUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-sky-100 max-w-lg w-full p-6 space-y-5 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-600 to-blue-500 text-white flex items-center justify-center shadow-xs">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Connect Mobile Device
              </h3>
              <div className="text-xs text-slate-500">
                Access CashFlow Ledger from your phone or tablet on local Wi-Fi
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* QR Code and Quick Scan Box */}
        <div className="flex flex-col items-center justify-center p-5 bg-gradient-to-b from-sky-50/70 to-slate-50 rounded-2xl border border-sky-100 space-y-3">
          <div className="bg-white p-2.5 rounded-xl border border-sky-200/80 shadow-md">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt="Scan to open on mobile"
                className="w-48 h-48 rounded-lg"
              />
            ) : (
              <div className="w-48 h-48 flex items-center justify-center text-xs text-slate-400">
                Generating QR Code...
              </div>
            )}
          </div>

          <div className="text-center space-y-1">
            <div className="font-bold text-slate-900 text-xs flex items-center justify-center gap-1.5">
              <QrCode className="w-4 h-4 text-sky-600" />
              <span>Scan QR Code with your smartphone camera</span>
            </div>
            <p className="text-[11px] text-slate-500 max-w-xs">
              Point your iPhone or Android camera at the screen to instantly launch the ledger without typing.
            </p>
          </div>
        </div>

        {/* LAN Mobile URL Bar */}
        <div className="space-y-1.5 text-xs">
          <label className="font-semibold text-slate-700 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Wifi className="w-3.5 h-3.5 text-emerald-600" />
              <span>Mobile / LAN Network Address:</span>
            </span>
            <span className="text-[11px] text-slate-500 font-normal">Same Wi-Fi required</span>
          </label>

          <div className="flex items-center gap-2">
            <div className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-800 text-xs truncate">
              {mobileUrl}
            </div>
            <button
              onClick={handleCopyUrl}
              className="px-3.5 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl font-semibold flex items-center gap-1.5 shadow-xs transition-colors shrink-0"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Link'}</span>
            </button>
          </div>
        </div>

        {/* Custom IP Config in case user is on a different adapter */}
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 text-xs space-y-2">
          <div className="flex items-center justify-between text-slate-600 font-semibold">
            <span>Server IP / Port Configuration:</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-2">
              <span className="text-[10px] text-slate-500">Wi-Fi IPv4:</span>
              <input
                type="text"
                value={lanIp}
                onChange={(e) => setLanIp(e.target.value.trim())}
                placeholder="192.168.X.X"
                className="w-full px-2.5 py-1 text-xs font-mono font-bold bg-white border border-slate-200 rounded-lg text-slate-800"
              />
            </div>
            <div>
              <span className="text-[10px] text-slate-500">Port:</span>
              <input
                type="text"
                value={port}
                onChange={(e) => setPort(e.target.value.trim())}
                placeholder="3000"
                className="w-full px-2.5 py-1 text-xs font-mono font-bold bg-white border border-slate-200 rounded-lg text-slate-800"
              />
            </div>
          </div>
        </div>

        {/* 3 Quick Mobile Steps */}
        <div className="space-y-2 text-xs">
          <div className="font-bold text-slate-800">Mobile Installation Tips (PWA):</div>
          <div className="space-y-1.5 text-slate-600 text-[11px] leading-relaxed">
            <div className="flex items-start gap-2">
              <span className="w-4 h-4 rounded-full bg-sky-100 text-sky-800 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">1</span>
              <span>Ensure your phone is connected to the same Wi-Fi router / hotspot as this computer.</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="w-4 h-4 rounded-full bg-sky-100 text-sky-800 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">2</span>
              <span>Scan QR code or open <b>{mobileUrl}</b> in Safari (iOS) or Chrome (Android).</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="w-4 h-4 rounded-full bg-sky-100 text-sky-800 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">3</span>
              <span>
                <b>Install App:</b> Tap <i>Share</i> &gt; <i>Add to Home Screen</i> (Safari) or tap <i>Install App</i> (Chrome) for full-screen offline-ready cash management!
              </span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
          <div className="text-[10px] text-slate-500 font-mono">
            SUM • Version 2026.v1 • © MG
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-bold text-xs shadow-xs transition-colors"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
