import React, { useState, useMemo } from 'react';
import {
  ShieldCheck,
  History,
  Clock,
  User,
  Search,
  Filter,
  CheckCircle,
  AlertTriangle,
  Trash2,
  Edit3,
  PlusCircle,
  Layers,
} from 'lucide-react';
import { AuditAction, AuditLogEntry, Group, User as UserType } from '../types/ledger';

interface AuditTrailViewProps {
  auditLogs: AuditLogEntry[];
  group: Group;
  currentUser: UserType;
}

export const AuditTrailView: React.FC<AuditTrailViewProps> = ({
  auditLogs,
  group,
  currentUser,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState<'ALL' | AuditAction>('ALL');

  const filteredLogs = useMemo(() => {
    return auditLogs.filter((log) => {
      if (actionFilter !== 'ALL' && log.action !== actionFilter) {
        return false;
      }
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchSummary = log.summary.toLowerCase().includes(q);
        const matchUser = log.performedBy.name.toLowerCase().includes(q);
        const matchReceipt = (log.receiptNumber || '').toLowerCase().includes(q);
        if (!matchSummary && !matchUser && !matchReceipt) return false;
      }
      return true;
    });
  }, [auditLogs, actionFilter, searchTerm]);

  const getActionBadge = (action: AuditAction) => {
    switch (action) {
      case 'CREATE':
        return {
          label: 'Entry Created',
          bg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
          icon: <PlusCircle className="w-3.5 h-3.5 text-emerald-600" />,
        };
      case 'UPDATE':
        return {
          label: 'Entry Modified',
          bg: 'bg-blue-50 text-blue-800 border-blue-200',
          icon: <Edit3 className="w-3.5 h-3.5 text-blue-600" />,
        };
      case 'DELETE':
        return {
          label: 'Entry Deleted',
          bg: 'bg-rose-50 text-rose-800 border-rose-200',
          icon: <Trash2 className="w-3.5 h-3.5 text-rose-600" />,
        };
      case 'RESTORE':
        return {
          label: 'Data Restored',
          bg: 'bg-amber-50 text-amber-800 border-amber-200',
          icon: <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />,
        };
      case 'GROUP_CREATE':
        return {
          label: 'Group Created',
          bg: 'bg-purple-50 text-purple-800 border-purple-200',
          icon: <Layers className="w-3.5 h-3.5 text-purple-600" />,
        };
      default:
        return {
          label: action,
          bg: 'bg-slate-100 text-slate-800 border-slate-200',
          icon: <History className="w-3.5 h-3.5 text-slate-600" />,
        };
    }
  };

  return (
    <div className="space-y-5">
      {/* Overview Banner */}
      <div className="bg-sky-50/80 border border-sky-200/80 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-xs">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Audit Trail & Compliance Log
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">
              Immutable ledger log recording Creator/Changer name, exact date, and timestamp for every cash entry or alteration.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-600 bg-white px-3 py-1.5 rounded-lg border border-sky-200 shrink-0">
          <span>{filteredLogs.length} audit records</span>
        </div>
      </div>

      {/* Audit Log Table & Filters */}
      <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-2xl shadow-xs overflow-hidden">
        
        {/* Filter controls */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Action filters */}
          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs">
            {(['ALL', 'CREATE', 'UPDATE', 'DELETE', 'RESTORE'] as const).map((act) => (
              <button
                key={act}
                onClick={() => setActionFilter(act)}
                className={`px-3 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                  actionFilter === act
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {act === 'ALL' ? 'All Activities' : act === 'CREATE' ? 'Creations' : act === 'UPDATE' ? 'Modifications' : act === 'DELETE' ? 'Deletions' : 'Restores'}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search user, action, details..."
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:bg-white focus:border-sky-500"
            />
          </div>
        </div>

        {/* Logs List */}
        <div className="divide-y divide-slate-100">
          {filteredLogs.length === 0 ? (
            <div className="py-12 text-center text-slate-600 text-xs">
              No audit records found matching your filters.
            </div>
          ) : (
            filteredLogs.map((log) => {
              const badge = getActionBadge(log.action);
              const logDate = new Date(log.timestamp);

              return (
                <div key={log.id} className="p-4 sm:px-6 hover:bg-sky-50/30 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                    
                    {/* User and Action Badge */}
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                        {log.performedBy.name.charAt(0)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-bold text-slate-900">
                            {log.performedBy.name}
                          </span>
                          <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                            {log.performedBy.role}
                          </span>
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium border ${badge.bg}`}>
                            {badge.icon}
                            <span>{badge.label}</span>
                          </span>
                        </div>
                        <div className="text-xs text-slate-800 mt-1 font-medium">
                          {log.summary}
                        </div>

                        {/* If field changes exist */}
                        {log.details && log.details.length > 0 && (
                          <div className="mt-2 bg-slate-50 border border-slate-200 rounded-lg p-2 text-[11px] space-y-1">
                            <span className="font-semibold text-slate-600">Changes:</span>
                            {log.details.map((d, i) => (
                              <div key={i} className="text-slate-600 font-mono">
                                <span className="font-bold text-slate-700">{d.field}:</span>{' '}
                                <span className="line-through text-rose-600">{String(d.oldValue)}</span>
                                {' → '}
                                <span className="text-emerald-700 font-semibold">{String(d.newValue)}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Timestamp */}
                    <div className="text-right sm:shrink-0 text-slate-600 font-mono text-[11px] flex sm:flex-col items-center sm:items-end justify-between gap-1">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{logDate.toLocaleDateString()}</span>
                      </div>
                      <div className="text-slate-600">
                        {logDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </div>
                    </div>

                  </div>
                </div>
              );
            })
          )}
        </div>
        <div className="p-3 border-t border-slate-100 text-center text-[10px] text-slate-500 font-mono">
          SUM • Version 2026.v1 • © MG
        </div>
      </div>
    </div>
  );
};
