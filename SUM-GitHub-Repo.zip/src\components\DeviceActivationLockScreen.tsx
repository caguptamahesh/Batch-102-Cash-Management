import React, { useState } from 'react';
import {
  Lock,
  KeyRound,
  ShieldCheck,
  Smartphone,
  Download,
  AlertCircle,
  CheckCircle2,
  Phone,
  MessageSquare,
  ExternalLink,
  Shield,
  Sparkles,
} from 'lucide-react';
import { User } from '../types/ledger';
import { storageService } from '../services/storageService';
import { validateIndianMobile } from './PartyManagerModal';

interface DeviceActivationLockScreenProps {
  onActivated: (user: User) => void;
}

export const DeviceActivationLockScreen: React.FC<DeviceActivationLockScreenProps> = ({
  onActivated,
}) => {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [showRequestCodeModal, setShowRequestCodeModal] = useState(false);

  // Request Code Form State
  const [reqName, setReqName] = useState('');
  const [reqEmail, setReqEmail] = useState('');
  const [reqMobile, setReqMobile] = useState('');
  const [reqStatus, setReqStatus] = useState<string | null>(null);

  const authorMobile = '+91 9414067123';
  const authorName = 'Mr. MG';

  // Handle 6-digit Code Verification
  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanCode = code.trim();
    if (!cleanCode || cleanCode.length !== 6) {
      setError('Please enter a valid 6-digit download & activation code.');
      return;
    }

    setIsLoading(true);
    try {
      const result = await storageService.verifyDeviceActivationCode(cleanCode);
      if (result.success && result.user) {
        onActivated(result.user);
      } else {
        setError(
          result.message ||
            'Invalid 6-digit activation code. Please contact author Mr. MG (+91 9414067123).'
        );
      }
    } catch (err: any) {
      setError(err.message || 'Error communicating with activation server.');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Master Admin Login
  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (adminPassword.trim() === 'admin123' || adminPassword.trim() === '941406') {
      const adminUser = storageService.getUsers().find((u) => u.role === 'admin') || {
        id: 'usr_admin',
        name: 'MG',
        email: 'ai.caguptamahesh@gmail.com',
        mobile: '+91 94140 67123',
        role: 'admin',
        avatarBg: 'bg-sky-600',
        isVerified: true,
        activationCode: '941406',
        status: 'active',
      };
      storageService.activateDevice(adminUser);
      onActivated(adminUser);
    } else {
      setError('Incorrect Administrator Password. Please try again or use 6-digit code.');
    }
  };

  // Request 6-digit Code from Author via WhatsApp
  const handleRequestCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reqName.trim() || !reqMobile.trim()) {
      setError('Name and mobile number are required.');
      return;
    }

    const check = validateIndianMobile(reqMobile);
    if (!check.valid) {
      setError(check.message || 'Please enter a valid 10-digit Indian mobile number (+91).');
      return;
    }

    // Call server to log request
    storageService.requestUserSignup(reqName.trim(), reqEmail.trim() || 'not_provided@ledger.local', check.formatted);

    const waMsg =
      `*CashFlow Ledger - Download & Activation Code Request*\n\n` +
      `Hello ${authorName},\n` +
      `I have downloaded the CashFlow Ledger app on my device and need a 6-digit activation code.\n\n` +
      `👤 *Name:* ${reqName.trim()}\n` +
      `📱 *Mobile:* ${check.formatted}\n` +
      (reqEmail.trim() ? `📧 *Email:* ${reqEmail.trim()}\n` : '') +
      `\nPlease share my 6-digit download code so I can unlock and use the app.`;

    const waUrl = `https://wa.me/919414067123?text=${encodeURIComponent(waMsg)}`;
    window.open(waUrl, '_blank');

    setReqStatus(`Request sent to ${authorName} (+91 9414067123). Enter the 6-digit code he provides below.`);
    setShowRequestCodeModal(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-br from-slate-950 via-slate-900 to-sky-950 text-white flex flex-col items-center justify-center p-4 sm:p-6 select-none overflow-y-auto">
      {/* Background radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-sky-500/15 rounded-full blur-3xl pointer-events-none" />

      <div className="relative w-full max-w-md bg-slate-900/90 border border-sky-800/60 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl space-y-6 my-auto">
        
        {/* Brand & Security Header */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-tr from-sky-600 to-blue-600 text-white flex items-center justify-center shadow-lg shadow-sky-600/30 font-black text-3xl tracking-wider border border-white/20 select-none">
            M
          </div>
          <div>
            <span className="px-3 py-0.5 rounded-full text-[10px] font-mono font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30 uppercase tracking-widest">
              Password Protected Download Gate
            </span>
            <div className="flex items-center justify-center gap-2 pt-2">
              <h1 className="text-2xl sm:text-3xl font-black text-white">
                SUM
              </h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30 font-mono">
                2026.v1
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Enter the 6-digit download & device activation code provided by Author <b>{authorName}</b> to unlock on this device.
            </p>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="p-3.5 bg-rose-950/60 border border-rose-700/60 rounded-2xl text-xs text-rose-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Status Alert */}
        {reqStatus && (
          <div className="p-3.5 bg-emerald-950/60 border border-emerald-700/60 rounded-2xl text-xs text-emerald-200 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{reqStatus}</span>
          </div>
        )}

        {/* Main 6-Digit Code Entry Form */}
        {!showAdminLogin ? (
          <form onSubmit={handleVerifyCode} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2 uppercase tracking-wider text-center">
                Enter 6-Digit Device Download Code
              </label>
              <div className="relative">
                <input
                  type="text"
                  maxLength={6}
                  value={code}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '');
                    setCode(val);
                    setError('');
                  }}
                  placeholder="• • • • • •"
                  className="w-full text-center tracking-[0.5em] px-4 py-3.5 bg-slate-950 border border-sky-500/50 rounded-2xl font-mono text-2xl font-black text-sky-400 placeholder:text-slate-600 focus:bg-slate-950 focus:border-sky-400 focus:ring-2 focus:ring-sky-500/30 outline-none transition-all"
                  autoFocus
                  required
                />
              </div>
              <p className="text-[11px] text-slate-400 text-center mt-1.5 font-mono">
                Author: {authorName} ({authorMobile})
              </p>
            </div>

            <button
              type="submit"
              disabled={isLoading || code.length !== 6}
              className={`w-full py-3.5 rounded-2xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer ${
                code.length === 6 && !isLoading
                  ? 'bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white shadow-sky-600/30 scale-[1.01]'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              {isLoading ? (
                <span>Validating Device Code...</span>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Download & Activate Ledger</span>
                </>
              )}
            </button>
          </form>
        ) : (
          /* Master Admin Login Form */
          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
                Master Administrator Password
              </label>
              <input
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="Enter admin password (admin123)"
                className="w-full px-4 py-3 bg-slate-950 border border-sky-500/50 rounded-2xl text-xs text-white placeholder:text-slate-500 focus:border-sky-400 outline-none"
                autoFocus
                required
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Master Admin Email: <code className="text-sky-300">ai.caguptamahesh@gmail.com</code>
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-2xl transition-all shadow-md cursor-pointer"
            >
              Unlock as Master Administrator
            </button>
          </form>
        )}

        {/* Action Links & Helpers */}
        <div className="pt-2 border-t border-slate-800/80 space-y-2 text-center text-xs">
          {!showRequestCodeModal ? (
            <button
              type="button"
              onClick={() => setShowRequestCodeModal(true)}
              className="text-sky-400 hover:text-sky-300 font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Don't have a code? Request from Mr. MG</span>
            </button>
          ) : (
            /* Quick Code Request Panel */
            <div className="p-4 bg-slate-950/80 border border-sky-700/50 rounded-2xl text-left space-y-3">
              <div className="text-xs font-bold text-sky-300 flex items-center justify-between">
                <span>Request 6-Digit Download Code</span>
                <button
                  onClick={() => setShowRequestCodeModal(false)}
                  className="text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              </div>

              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Your Full Name *</label>
                <input
                  type="text"
                  value={reqName}
                  onChange={(e) => setReqName(e.target.value)}
                  placeholder="e.g. Ramesh Patel"
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-300 mb-1">Indian Mobile Number (+91) *</label>
                <input
                  type="tel"
                  value={reqMobile}
                  onChange={(e) => setReqMobile(e.target.value)}
                  placeholder="9414067123"
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-mono text-white outline-none"
                  required
                />
              </div>

              <button
                type="button"
                onClick={handleRequestCode}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Send Request to Mr. MG on WhatsApp</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          )}

          <div>
            <button
              type="button"
              onClick={() => {
                setShowAdminLogin(!showAdminLogin);
                setError('');
              }}
              className="text-slate-400 hover:text-slate-200 text-[11px] underline cursor-pointer"
            >
              {showAdminLogin ? '← Back to 6-Digit Code Entry' : 'Administrator Override Login'}
            </button>
          </div>
        </div>

        {/* Security watermark footer */}
        <div className="pt-2 text-center text-[10px] text-slate-500 font-mono">
          <span>SUM • Version 2026.v1 • © MG</span>
        </div>

      </div>
    </div>
  );
};
