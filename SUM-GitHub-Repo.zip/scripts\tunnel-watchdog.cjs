const { spawn } = require('child_process');

function startTunnel() {
  console.log('[Tunnel Watchdog] Launching localtunnel for port 3000...');
  const child = spawn('npx', ['localtunnel', '--port', '3000'], {
    shell: true,
    stdio: 'inherit'
  });

  child.on('close', (code) => {
    console.log(`[Tunnel Watchdog] Process closed with code ${code}. Auto-restarting in 2s...`);
    setTimeout(startTunnel, 2000);
  });

  child.on('error', (err) => {
    console.error('[Tunnel Watchdog] Spawn error:', err.message);
    setTimeout(startTunnel, 2000);
  });
}

startTunnel();
