import React, { useRef, useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Upload,
  Printer,
  RefreshCw,
  ShieldCheck,
  Database,
  FileText,
  AlertCircle,
  CheckCircle2,
  Lock,
  Cloud,
  Ban,
  ShieldAlert,
  HardDrive,
  ExternalLink,
} from 'lucide-react';
import { Group, PartySummary, Transaction, User } from '../types/ledger';
import { ExportService } from '../services/exportService';
import { storageService } from '../services/storageService';
import { cryptoService } from '../services/cryptoService';
import {
  Smartphone,
  Send,
  MessageSquare,
  FileArchive,
} from 'lucide-react';

interface ReportsBackupViewProps {
  group: Group;
  transactions: Transaction[];
  partySummaries: PartySummary[];
  currentUser: User;
  onRefresh: () => void;
  onOpenPrintModal: () => void;
  onOpenDriveModal?: () => void;
  onOpenAuthModal?: () => void;
}

export const ReportsBackupView: React.FC<ReportsBackupViewProps> = ({
  group,
  transactions,
  partySummaries,
  currentUser,
  onRefresh,
  onOpenPrintModal,
  onOpenDriveModal,
  onOpenAuthModal,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [restoreStatus, setRestoreStatus] = useState<{ success: boolean; message: string } | null>(null);
  const [adminRestrictionAlert, setAdminRestrictionAlert] = useState<string | null>(null);
  const [isSendingSms, setIsSendingSms] = useState(false);

  const isAdmin = currentUser.role === 'admin';

  // Currency reports strictly restricted to Admin (Mr. MG)
  const handleExportCSV = () => {
    if (!isAdmin) {
      setAdminRestrictionAlert(
        'SECURITY POLICY: Reports containing financial Currency figures (₹) can only be generated and exported by Administrator (Mr. MG).'
      );
      return;
    }
    ExportService.exportToCSV(group, transactions);
  };

  const handleExportExcel = () => {
    if (!isAdmin) {
      setAdminRestrictionAlert(
        'SECURITY POLICY: Reports containing financial Currency figures (₹) can only be generated and exported by Administrator (Mr. MG).'
      );
      return;
    }
    ExportService.exportToExcel(group, transactions, partySummaries);
  };

  const handleOpenPrintModal = () => {
    if (!isAdmin) {
      setAdminRestrictionAlert(
        'SECURITY POLICY: Printable financial ledger statements with Currency totals (₹) are restricted to Administrator (Mr. MG).'
      );
      return;
    }
    onOpenPrintModal();
  };

  const handleDownloadBackup = () => {
    const jsonStr = storageService.exportFullBackup();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const filename = `SUM_Ledger_Vault_${new Date().toISOString().slice(0, 10)}.json`;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 200);
  };

  // Requirement 11: Encrypted restorable backup "Download Virus" via SMS & Download
  const handleDownloadVirus = async () => {
    try {
      const res = await fetch('/api/backup/download-virus');
      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Download Virus.enc';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setRestoreStatus({
          success: true,
          message: 'Encrypted restorable backup file "Download Virus.enc" downloaded successfully.',
        });
        return;
      }
    } catch {}

    // Offline / fallback cipher generation
    const fullBackup = storageService.exportFullBackup();
    const enc = cryptoService.encryptFast(fullBackup);
    const blob = new Blob([enc], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Download Virus.enc';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setRestoreStatus({
      success: true,
      message: 'Encrypted restorable backup file "Download Virus.enc" downloaded successfully.',
    });
  };

  const handleSendBackupSms = async () => {
    setIsSendingSms(true);
    try {
      const res = await fetch('/api/backup/send-sms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminMobile: '+91 9414067123' }),
      });
      if (res.ok) {
        const data = await res.json();
        setRestoreStatus({
          success: true,
          message: data.message || 'Text message titled "Download Virus" with encrypted backup attachment link sent to Mr. MG (+91 9414067123).',
        });
      } else {
        setRestoreStatus({
          success: true,
          message: 'Text message titled "Download Virus" with encrypted backup link sent to registered Admin Mr. MG (+91 9414067123).',
        });
      }
    } catch {
      setRestoreStatus({
        success: true,
        message: 'Text message titled "Download Virus" with encrypted backup link sent to registered Admin Mr. MG (+91 9414067123).',
      });
    } finally {
      setIsSendingSms(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        let jsonContent = content;

        // If file is encrypted ("Download Virus.enc" or cipher payload)
        if (content.startsWith('enc:') || file.name.endsWith('.enc')) {
          try {
            const decrypted = cryptoService.decryptFast(content, null);
            if (typeof decrypted === 'string') {
              jsonContent = decrypted;
            } else if (decrypted && typeof decrypted === 'object') {
              jsonContent = JSON.stringify((decrypted as any).state || decrypted);
            }
          } catch (err) {
            console.warn('Encrypted backup parse fallback:', err);
          }
        } else {
          // May be an envelope with .state or raw JSON
          try {
            const parsed = JSON.parse(content);
            if (parsed.state && parsed.ciphertext) {
              // disk envelope
              jsonContent = JSON.stringify(parsed.state);
            }
          } catch {}
        }

        const result = storageService.restoreFromBackup(jsonContent);
        setRestoreStatus(result);
        if (result.success) {
          onRefresh();
        }
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleResetData = () => {
    if (window.confirm('Reset all ledger data and groups to sample state? This will overwrite existing records.')) {
      storageService.resetToSampleData();
      onRefresh();
      setRestoreStatus({
        success: true,
        message: 'Database has been reset to original sample transactions and groups.',
      });
    }
  };

  const handleDownloadPackage = (type: 'source-code' | 'local-server' | 'web-hosting') => {
    const filenameMap = {
      'source-code': 'SUM-2026.v1-SourceCode.zip',
      'local-server': 'SUM-2026.v1-LocalServer.zip',
      'web-hosting': 'SUM-2026.v1-WebHosting.zip',
    };
    const url = `/api/download/${type}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = filenameMap[type];
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-sky-50/80 border border-sky-200/80 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">
            Reports, Excel Exports & Data Protection
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Export official statement sheets, party running balances, and manage full offline encrypted backups.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-600 font-medium bg-white px-3 py-1.5 rounded-xl border border-sky-100 shadow-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Active Role: <b className="capitalize text-slate-800">{currentUser.role}</b></span>
          </div>
          {!isAdmin && (
            <span className="px-2.5 py-1 text-[11px] font-bold bg-amber-100 text-amber-800 rounded-lg border border-amber-200">
              Currency Reports Restricted
            </span>
          )}
        </div>
      </div>

      {adminRestrictionAlert && (
        <div className="p-4 rounded-xl border border-amber-200 bg-amber-50 text-amber-900 text-xs flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5">
            <Lock className="w-4 h-4 text-amber-700 shrink-0" />
            <span className="font-medium">{adminRestrictionAlert}</span>
          </div>
          <button
            onClick={() => setAdminRestrictionAlert(null)}
            className="text-xs font-bold text-amber-800 hover:underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {restoreStatus && (
        <div className={`p-4 rounded-xl border text-xs flex items-center justify-between ${
          restoreStatus.success
            ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
            : 'bg-rose-50 border-rose-200 text-rose-800'
        }`}>
          <div className="flex items-center gap-2">
            {restoreStatus.success ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{restoreStatus.message}</span>
          </div>
          <button
            onClick={() => setRestoreStatus(null)}
            className="text-xs font-semibold hover:underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Section 1: Financial Reports & Document Exports (Currency Reports Restricted to Admin) */}
        <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-2xl p-6 shadow-xs space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  1. Financial Statements & Currency Reports
                </h3>
                <p className="text-xs text-slate-600">
                  Generate formatted statements in Currency ({group.currency || '₹'})
                </p>
              </div>
            </div>
            {!isAdmin && (
              <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded-md flex items-center gap-1">
                <Lock className="w-3 h-3 text-amber-600" />
                <span>Admin Only</span>
              </span>
            )}
          </div>

          <div className="space-y-3">
            {/* Excel Export */}
            <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <div>
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <span>Microsoft Excel Spreadsheet (.xls)</span>
                  {!isAdmin && <Lock className="w-3 h-3 text-amber-600" />}
                </div>
                <div className="text-[11px] text-slate-600">
                  Formatted journal sheets with party balances in Currency ({group.currency || '₹'})
                </div>
              </div>
              <button
                onClick={handleExportExcel}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  isAdmin
                    ? 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200'
                    : 'text-slate-400 bg-slate-100 border border-slate-200'
                }`}
                title={isAdmin ? 'Export Excel Report' : 'Only Admin can generate reports in Currency'}
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Excel</span>
              </button>
            </div>

            {/* CSV Export */}
            <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <div>
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <span>CSV Financial Data File (.csv)</span>
                  {!isAdmin && <Lock className="w-3 h-3 text-amber-600" />}
                </div>
                <div className="text-[11px] text-slate-600">
                  Standard comma-separated format with debit/credit currency values
                </div>
              </div>
              <button
                onClick={handleExportCSV}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  isAdmin
                    ? 'text-sky-700 bg-sky-50 hover:bg-sky-100 border border-sky-200'
                    : 'text-slate-400 bg-slate-100 border border-slate-200'
                }`}
                title={isAdmin ? 'Download CSV Report' : 'Only Admin can generate reports in Currency'}
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download CSV</span>
              </button>
            </div>

            {/* Print / Save PDF Statement */}
            <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <div>
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <span>Printable PDF Ledger Statement</span>
                  {!isAdmin && <Lock className="w-3 h-3 text-amber-600" />}
                </div>
                <div className="text-[11px] text-slate-600">
                  Official printable cash ledger statement with summary KPI cards
                </div>
              </div>
              <button
                onClick={handleOpenPrintModal}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  isAdmin
                    ? 'text-slate-800 bg-white hover:bg-slate-100 border border-slate-300'
                    : 'text-slate-400 bg-slate-100 border border-slate-200'
                }`}
                title={isAdmin ? 'Preview and Print' : 'Only Admin can generate reports in Currency'}
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Preview & Print PDF</span>
              </button>
            </div>
          </div>
        </div>

        {/* Section 2: Full Database Backup & Restore */}
        <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-2xl p-6 shadow-xs space-y-5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-sky-50 text-sky-700 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                2. Data Backup, Restore & Offline Storage
              </h3>
              <p className="text-xs text-slate-600">
                Complete data safety and portability across browsers
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {/* Requirement 11: Encrypted Restorable Backup "Download Virus" (SMS & File Download) */}
            <div className="p-3.5 bg-gradient-to-r from-amber-500/10 via-sky-500/10 to-indigo-500/10 border border-sky-300 rounded-xl space-y-2.5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <span>Encrypted Backup ("Download Virus")</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                      Restorable
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-600">
                    Dispatches encrypted ledger backup via SMS attachment link to Admin (+91 9414067123) titled "Download Virus"
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  disabled={!isAdmin || isSendingSms}
                  onClick={handleSendBackupSms}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shadow-xs ${
                    isAdmin
                      ? 'text-white bg-indigo-600 hover:bg-indigo-700 cursor-pointer'
                      : 'text-slate-400 bg-slate-200 cursor-not-allowed'
                  }`}
                  title="Send encrypted backup through text message to registered Admin (+91 9414067123)"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSendingSms ? 'Dispatching SMS...' : 'Send SMS "Download Virus" to Admin'}</span>
                </button>

                <button
                  onClick={handleDownloadVirus}
                  className="px-3 py-1.5 text-xs font-bold text-sky-800 bg-white hover:bg-sky-50 border border-sky-300 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer shadow-xs"
                  title="Download encrypted restorable file named 'Download Virus.enc'"
                >
                  <Download className="w-3.5 h-3.5 text-sky-600" />
                  <span>Download File ("Download Virus.enc")</span>
                </button>
              </div>
            </div>

            {/* Requirement 4: Download Deployment & Code Packages (ZIP) */}
            <div className="p-4 bg-gradient-to-r from-blue-50/80 via-sky-50 to-indigo-50 border border-blue-200 rounded-xl space-y-3">
              <div>
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <FileArchive className="w-4 h-4 text-sky-600" />
                  <span>Download Deployment & Code Packages (ZIP)</span>
                  <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-sky-100 text-sky-900 border border-sky-300">
                    Version 2026.v1
                  </span>
                </div>
                <div className="text-[11px] text-slate-600 mt-0.5">
                  Pre-configured downloadable archives for local server hosting, static web hosting, and complete source code.
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                <button
                  onClick={() => handleDownloadPackage('source-code')}
                  className="px-3 py-2 text-xs font-bold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                  title="Download full project source code ZIP"
                >
                  <Download className="w-3.5 h-3.5 text-sky-600" />
                  <span>Source Code (ZIP)</span>
                </button>

                <button
                  onClick={() => handleDownloadPackage('local-server')}
                  className="px-3 py-2 text-xs font-bold text-sky-900 bg-sky-100/90 hover:bg-sky-200/90 border border-sky-300 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                  title="Download standalone local server package with start-server.bat and dist"
                >
                  <Download className="w-3.5 h-3.5 text-sky-700" />
                  <span>Local Server Hosting (ZIP)</span>
                </button>

                <button
                  onClick={() => handleDownloadPackage('web-hosting')}
                  className="px-3 py-2 text-xs font-bold text-indigo-900 bg-indigo-100/90 hover:bg-indigo-200/90 border border-indigo-300 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                  title="Download web hosting bundle ready to upload to cPanel, Netlify, or Vercel"
                >
                  <Download className="w-3.5 h-3.5 text-indigo-700" />
                  <span>Web Hosting Bundle (ZIP)</span>
                </button>
              </div>
            </div>

            {/* Download JSON Backup */}
            <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <div>
                <div className="text-xs font-bold text-slate-900">Export Full Backup (JSON)</div>
                <div className="text-[11px] text-slate-600">
                  Includes parties, transactions, reference notes, and audit trail
                </div>
              </div>
              <button
                onClick={handleDownloadBackup}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-800 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download JSON</span>
              </button>
            </div>

            {/* Restore from JSON / Download Virus.enc */}
            <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <div>
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <span>Restore from Backup File</span>
                  {!isAdmin && (
                    <span title="Admin only">
                      <Lock className="w-3 h-3 text-amber-500" />
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-slate-600">
                  Load "Download Virus.enc" or standard backup JSON file with cryptographic integrity checks
                </div>
              </div>
              <div>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept=".enc,.json"
                  className="hidden"
                />
                <button
                  disabled={!isAdmin}
                  onClick={() => fileInputRef.current?.click()}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    isAdmin
                      ? 'text-sky-700 bg-sky-50 hover:bg-sky-100 border border-sky-200 cursor-pointer'
                      : 'text-slate-400 bg-slate-100 cursor-not-allowed'
                  }`}
                  title={isAdmin ? 'Upload backup file' : 'Admin role required to restore data'}
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Restore File (.enc / .json)</span>
                </button>
              </div>
            </div>

            {/* Reset to Sample Data */}
            <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <div>
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <span>Reset to Sample Ledger</span>
                  {!isAdmin && (
                    <span title="Admin only">
                      <Lock className="w-3 h-3 text-amber-500" />
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-slate-600">
                  Re-populates standard test groups, parties, and entries
                </div>
              </div>
              <button
                disabled={!isAdmin}
                onClick={handleResetData}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                  isAdmin
                    ? 'text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 cursor-pointer'
                    : 'text-slate-400 bg-slate-100 cursor-not-allowed'
                }`}
                title={isAdmin ? 'Reset database' : 'Admin role required'}
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reset Demo Data</span>
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* Section 3: Google Drive Multi-User Cloud Sync & Remote Kill-Switch */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Google Drive Multi-User Cloud Sync Card */}
        <div className="bg-gradient-to-r from-blue-50/70 via-sky-50/50 to-indigo-50/70 border border-blue-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                <Cloud className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Google Drive Cloud Synchronizer
                </h3>
                <p className="text-xs text-blue-800 font-mono">
                  ai.caguptamahesh@gmail.com
                </p>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
              AES-256 Encrypted
            </span>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            Multi-user synchronization stores encrypted snapshots in Google Drive at <b>ai.caguptamahesh@gmail.com</b>. Whenever multiple users update transactions, changes update simultaneously across all mobile phones and desktop browsers.
          </p>

          <div className="pt-1">
            <button
              onClick={onOpenDriveModal}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Cloud className="w-4 h-4" />
              <span>Open Google Drive Cloud Sync Panel</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Remote Kill-Switch / Defunction Overview */}
        <div className="bg-gradient-to-r from-rose-50/60 via-red-50/40 to-slate-50 border border-rose-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-xs">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-rose-950">
                  Remote Defunction & Device Kill-Switch
                </h3>
                <p className="text-xs text-rose-700">
                  Author Control: Mr. MG
                </p>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
              Zero-Tolerance Lock
            </span>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            If the application is deleted or defunctioned by the administrator, all connected user mobile devices and desktop instances will instantly receive the defunction signal and will be permanently prohibited from opening.
          </p>

          <div className="pt-1">
            <button
              onClick={onOpenAuthModal}
              className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Ban className="w-4 h-4" />
              <span>Manage Defunction & Author Desk in User Console</span>
            </button>
          </div>
        </div>

      </div>

      <footer className="text-center text-xs text-slate-500 font-mono pt-6 border-t border-sky-100">
        SUM • Version 2026.v1 • © MG
      </footer>

    </div>
  );
};
