import React, { useState, useMemo } from 'react';
import {
  Calculator,
  Coins,
  Receipt,
  Scale,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Save,
  Download,
  Calendar,
  Clock,
  Printer,
  History,
  TrendingUp,
  TrendingDown,
  Building2,
  UserCheck,
} from 'lucide-react';
import { CashDenominationCount, CashTallySession, Group, User } from '../types/ledger';
import { storageService } from '../services/storageService';
import { ExportService } from '../services/exportService';

interface CashDenominationsViewProps {
  group: Group;
  currentUser: User;
  systemCashBalance: number;
  onRefresh: () => void;
}

const DENOMINATIONS: { key: keyof CashDenominationCount; label: string; value: number; type: 'note' | 'coin' }[] = [
  { key: 'd2000', label: '2,000 Note', value: 2000, type: 'note' },
  { key: 'd500', label: '500 Note', value: 500, type: 'note' },
  { key: 'd200', label: '200 Note', value: 200, type: 'note' },
  { key: 'd100', label: '100 Note', value: 100, type: 'note' },
  { key: 'd50', label: '50 Note', value: 50, type: 'note' },
  { key: 'd20', label: '20 Note', value: 20, type: 'note' },
  { key: 'd10', label: '10 Note', value: 10, type: 'note' },
  { key: 'd5', label: '5 Note / Coin', value: 5, type: 'coin' },
  { key: 'd2', label: '2 Coin', value: 2, type: 'coin' },
  { key: 'd1', label: '1 Coin', value: 1, type: 'coin' },
];

export const CashDenominationsView: React.FC<CashDenominationsViewProps> = ({
  group,
  currentUser,
  systemCashBalance,
  onRefresh,
}) => {
  const [counts, setCounts] = useState<CashDenominationCount>({});
  const [coinsAmount, setCoinsAmount] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [tallyDate, setTallyDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Load tally sessions
  const tallySessions = storageService.getTallySessions(group.id);

  // Compute total physical cash
  const { totalPhysicalCash, denominationSubtotals } = useMemo(() => {
    let sum = 0;
    const subtotals: Record<string, number> = {};

    DENOMINATIONS.forEach(({ key, value }) => {
      const qty = counts[key] || 0;
      const subtotal = qty * value;
      subtotals[key] = subtotal;
      sum += subtotal;
    });

    const parsedCoins = parseFloat(coinsAmount) || 0;
    sum += parsedCoins;

    return { totalPhysicalCash: sum, denominationSubtotals: subtotals };
  }, [counts, coinsAmount]);

  // Variance
  const variance = totalPhysicalCash - systemCashBalance;
  const isBalanced = variance === 0 && totalPhysicalCash > 0;
  const isSurplus = variance > 0;
  const isShortage = variance < 0;

  // Handle count change
  const handleCountChange = (key: keyof CashDenominationCount, value: string) => {
    const qty = parseInt(value, 10);
    setCounts((prev) => ({
      ...prev,
      [key]: isNaN(qty) || qty < 0 ? undefined : qty,
    }));
  };

  // Reset calculator
  const handleReset = () => {
    setCounts({});
    setCoinsAmount('');
    setNotes('');
  };

  // Save tally session
  const handleSaveTally = () => {
    const coinsVal = parseFloat(coinsAmount) || 0;
    const denominationsWithCoins = {
      ...counts,
      coins: coinsVal > 0 ? coinsVal : undefined,
    };

    storageService.saveTallySession({
      groupId: group.id,
      date: tallyDate,
      denominations: denominationsWithCoins,
      totalPhysicalCash,
      systemCashBalance,
      notes,
    });

    onRefresh();
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 4000);
  };

  // Export current tally slip
  const handleExportSlip = () => {
    const coinsVal = parseFloat(coinsAmount) || 0;
    const currentSession: CashTallySession = {
      id: 'current_preview',
      groupId: group.id,
      date: tallyDate,
      timestamp: new Date().toISOString(),
      denominations: {
        ...counts,
        coins: coinsVal > 0 ? coinsVal : undefined,
      },
      totalPhysicalCash,
      systemCashBalance,
      variance,
      verifiedBy: {
        id: currentUser.id,
        name: currentUser.name,
        role: currentUser.role,
      },
      notes,
    };

    ExportService.exportTallySlip(group, currentSession);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-sky-500/10 border border-emerald-200/80 rounded-2xl p-5 sm:p-6 backdrop-blur-md">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-800 font-semibold text-xs tracking-wider uppercase mb-1">
              <Calculator className="w-4 h-4 text-emerald-600" />
              <span>Cash Management & Drawer Reconciliation · {group.name}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
              Cash Denominations Counter & Tally
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              Count physical notes and coins in your cash counter drawer, verify against the system
              net cash balance, detect shortages or surpluses, and save daily till closing slips.
            </p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleReset}
              className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 font-semibold text-xs transition-colors flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
            <button
              onClick={handleExportSlip}
              disabled={totalPhysicalCash === 0}
              className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs shadow-xs transition-colors flex items-center gap-1.5 disabled:opacity-40"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              <span>Print / Export Slip</span>
            </button>
            <button
              onClick={handleSaveTally}
              disabled={totalPhysicalCash === 0}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white font-bold text-xs shadow-md shadow-emerald-600/20 active:translate-y-0.5 transition-all cursor-pointer whitespace-nowrap"
            >
              <Save className="w-4 h-4" />
              <span>Record & Reconcile Tally</span>
            </button>
          </div>
        </div>

        {/* Live Reconcile Status Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-5 pt-4 border-t border-emerald-200/60 text-xs">
          {/* Card 1: System Net Cash Balance */}
          <div className="bg-white/90 rounded-xl p-4 border border-slate-200/80 shadow-xs">
            <div className="text-slate-500 text-[11px] font-semibold uppercase tracking-wider">
              System Ledger Net Cash
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 mt-1">
              {group.currency}{systemCashBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Calculated from all active cash receipts & payments
            </div>
          </div>

          {/* Card 2: Counted Physical Cash */}
          <div className="bg-white/90 rounded-xl p-4 border border-slate-200/80 shadow-xs">
            <div className="text-slate-500 text-[11px] font-semibold uppercase tracking-wider">
              Counted Physical Cash
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-700 mt-1">
              {group.currency}{totalPhysicalCash.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Actual cash counted in drawer right now
            </div>
          </div>

          {/* Card 3: Difference / Variance */}
          <div
            className={`rounded-xl p-4 border shadow-xs transition-colors ${
              totalPhysicalCash === 0
                ? 'bg-white/90 border-slate-200 text-slate-600'
                : isBalanced
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : isSurplus
                ? 'bg-sky-50 border-sky-200 text-sky-900'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}
          >
            <div className="text-[11px] font-semibold uppercase tracking-wider flex items-center justify-between">
              <span>Till Variance (Diff)</span>
              {totalPhysicalCash > 0 && (
                <span className="font-bold">
                  {isBalanced && '✓ Exact Match'}
                  {isSurplus && '↑ Excess Cash'}
                  {isShortage && '↓ Drawer Deficit'}
                </span>
              )}
            </div>
            <div
              className={`text-xl sm:text-2xl font-bold font-mono mt-1 ${
                totalPhysicalCash === 0
                  ? 'text-slate-600'
                  : isBalanced
                  ? 'text-emerald-700'
                  : isSurplus
                  ? 'text-sky-700'
                  : 'text-rose-700'
              }`}
            >
              {variance > 0 ? '+' : ''}
              {group.currency}{variance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] mt-1 opacity-80">
              {totalPhysicalCash === 0 && 'Enter note counts below to calculate variance'}
              {isBalanced && 'Physical cash matches system ledger perfectly!'}
              {isSurplus && 'Counter has more physical cash than recorded entries.'}
              {isShortage && 'Counter has less cash than recorded entries. Check unrecorded payouts.'}
            </div>
          </div>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-3 text-emerald-900 text-xs font-semibold">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <div>
            Cash Tally session recorded and stored in ledger audit history! Variance: {group.currency}{variance.toLocaleString()}.
          </div>
        </div>
      )}

      {/* Main Two-Column Layout: Denomination Table & Day-End Closing Slip */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Denomination Input Matrix */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-sky-100 shadow-xs overflow-hidden">
          <div className="p-4 sm:px-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Denomination Breakdown Table
              </h2>
              <div className="text-xs text-slate-500">
                Type quantity of each note or coin in drawer
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">Tally Date:</span>
              <input
                type="date"
                value={tallyDate}
                onChange={(e) => setTallyDate(e.target.value)}
                className="px-2.5 py-1 text-xs border border-slate-200 rounded-lg text-slate-700 font-semibold"
              />
            </div>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {DENOMINATIONS.map(({ key, label, value }) => {
              const qty = counts[key] ?? '';
              const subtotal = denominationSubtotals[key] || 0;

              return (
                <div
                  key={key}
                  className="p-3 sm:px-5 flex items-center justify-between hover:bg-slate-50/70 transition-colors"
                >
                  <div className="flex items-center gap-3 w-40 sm:w-48">
                    <div
                      className={`w-9 h-7 rounded-md font-mono font-bold text-xs flex items-center justify-center shrink-0 ${
                        value >= 500
                          ? 'bg-purple-100 text-purple-800 border border-purple-200'
                          : value >= 100
                          ? 'bg-sky-100 text-sky-800 border border-sky-200'
                          : 'bg-amber-100 text-amber-800 border border-amber-200'
                      }`}
                    >
                      {group.currency}{value}
                    </div>
                    <div>
                      <div className="font-bold text-slate-800">{label}</div>
                      <div className="text-[10px] text-slate-400">× {group.currency}{value}</div>
                    </div>
                  </div>

                  {/* Quantity Input */}
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-xs font-mono">×</span>
                    <input
                      type="number"
                      min="0"
                      placeholder="0"
                      value={qty}
                      onChange={(e) => handleCountChange(key, e.target.value)}
                      className="w-24 px-3 py-1.5 text-right font-mono font-bold text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-900"
                    />
                  </div>

                  {/* Subtotal */}
                  <div className="w-28 sm:w-36 text-right font-mono font-bold text-slate-900 text-xs">
                    {group.currency}{subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </div>
                </div>
              );
            })}

            {/* Miscellaneous Loose Coins */}
            <div className="p-3 sm:px-5 flex items-center justify-between hover:bg-slate-50/70 transition-colors bg-slate-50/30">
              <div className="flex items-center gap-3 w-40 sm:w-48">
                <div className="w-9 h-7 rounded-md font-mono font-bold text-xs flex items-center justify-center shrink-0 bg-slate-200 text-slate-700 border border-slate-300">
                  <Coins className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-slate-800">Loose Coins Total</div>
                  <div className="text-[10px] text-slate-400">Direct amount</div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-slate-400 text-xs font-mono">{group.currency}</span>
                <input
                  type="number"
                  min="0"
                  step="any"
                  placeholder="0.00"
                  value={coinsAmount}
                  onChange={(e) => setCoinsAmount(e.target.value)}
                  className="w-24 px-3 py-1.5 text-right font-mono font-bold text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-900"
                />
              </div>

              <div className="w-28 sm:w-36 text-right font-mono font-bold text-slate-900 text-xs">
                {group.currency}{(parseFloat(coinsAmount) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
            </div>

            {/* Total Row */}
            <div className="p-4 sm:px-5 flex items-center justify-between bg-emerald-50/50 font-bold border-t border-emerald-200 text-xs">
              <div className="text-slate-900 font-bold text-sm">
                Total Physical Cash Counted
              </div>
              <div className="font-mono text-base text-emerald-800">
                {group.currency}{totalPhysicalCash.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Day-End Closing & History */}
        <div className="space-y-6">
          
          {/* Notes & Handover Box */}
          <div className="bg-white rounded-2xl border border-sky-100 shadow-xs p-5 space-y-4 text-xs">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
              <UserCheck className="w-4 h-4 text-sky-600" />
              <span>Shift Handover & Reconciliation Notes</span>
            </h3>

            <div>
              <label className="block text-slate-600 font-medium mb-1">
                Cashier / Verifier
              </label>
              <div className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-semibold">
                {currentUser.name} ({currentUser.role})
              </div>
            </div>

            <div>
              <label className="block text-slate-600 font-medium mb-1">
                Reconciliation Notes / Drawer Remarks
              </label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. ₹5,000 kept in drawer float for tomorrow. ₹25,000 deposited in main vault. Exact match verified."
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 text-xs leading-relaxed"
              />
            </div>

            <button
              onClick={handleSaveTally}
              disabled={totalPhysicalCash === 0}
              className="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white rounded-xl font-bold shadow-xs transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>Save & Finalize Day Tally</span>
            </button>
          </div>

          {/* Previous Tally Sessions History */}
          <div className="bg-white rounded-2xl border border-sky-100 shadow-xs p-5 space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h3 className="font-bold text-slate-900 flex items-center gap-1.5">
                <History className="w-4 h-4 text-slate-500" />
                <span>Recent Till Tally History ({tallySessions.length})</span>
              </h3>
            </div>

            <div className="space-y-2 max-h-72 overflow-y-auto">
              {tallySessions.slice(0, 8).map((session) => {
                const varText =
                  session.variance === 0
                    ? 'Balanced'
                    : session.variance > 0
                    ? `+${group.currency}${session.variance.toLocaleString()} Excess`
                    : `-${group.currency}${Math.abs(session.variance).toLocaleString()} Deficit`;

                return (
                  <div
                    key={session.id}
                    className="p-3 bg-slate-50 hover:bg-sky-50 border border-slate-200/70 rounded-xl transition-colors space-y-1"
                  >
                    <div className="flex items-center justify-between font-bold">
                      <span className="text-slate-900">{session.date}</span>
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] ${
                          session.variance === 0
                            ? 'bg-emerald-100 text-emerald-800'
                            : session.variance > 0
                            ? 'bg-sky-100 text-sky-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {varText}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-600">
                      <span>Counted: {group.currency}{session.totalPhysicalCash.toLocaleString()}</span>
                      <span>System: {group.currency}{session.systemCashBalance.toLocaleString()}</span>
                    </div>

                    <div className="text-[10px] text-slate-400 pt-0.5 flex items-center justify-between">
                      <span>by {session.verifiedBy.name}</span>
                      <span>{new Date(session.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>

                    {session.notes && (
                      <div className="text-[10px] text-slate-600 italic bg-white/70 p-1.5 rounded border border-slate-100 mt-1">
                        "{session.notes}"
                      </div>
                    )}
                  </div>
                );
              })}

              {tallySessions.length === 0 && (
                <div className="text-center py-6 text-slate-400">
                  No tally sessions recorded yet. Complete your first physical cash count above.
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

      {/* Requirement 12: Copyright and Version Footer */}
      <footer className="text-center text-xs text-slate-500 font-mono pt-6 border-t border-sky-100">
        SUM • Version 2026.v1 • © MG
      </footer>

    </div>
  );
};
