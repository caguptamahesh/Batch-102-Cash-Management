import {
  AuditLogEntry,
  Group,
  PartySummary,
  Transaction,
  User,
  LedgerDashboardMetrics,
  ReferenceNote,
  CashTallySession,
  CashDenominationCount,
  NoteTag,
  NotePriority,
  NoteColor,
  Party,
  UserSignupRequest,
  DefunctionState,
  DeviceActivationState,
} from '../types/ledger';
import { cryptoService } from './cryptoService';
import { syncService } from './syncService';

const STORAGE_KEYS = {
  USERS: 'cashflow_users_v1',
  CURRENT_USER: 'cashflow_current_user_v1',
  GROUPS: 'cashflow_groups_v1',
  CURRENT_GROUP_ID: 'cashflow_active_group_id_v1',
  TRANSACTIONS: 'cashflow_transactions_v1',
  AUDIT_LOGS: 'cashflow_audit_logs_v1',
  OFFLINE_QUEUE: 'cashflow_offline_queue_v1',
  REFERENCE_NOTES: 'cashflow_reference_notes_v1',
  TALLY_SESSIONS: 'cashflow_tally_sessions_v1',
  QUICK_SCRATCHPAD: 'cashflow_quick_scratchpad_v1',
  PARTIES: 'cashflow_parties_v1',
  SIGNUP_REQUESTS: 'cashflow_signup_requests_v1',
  DEFUNCTION_STATE: 'cashflow_defunction_v1',
  DEVICE_ACTIVATION: 'cashflow_device_activation_v1',
  DELETED_USER_IDS: 'cashflow_deleted_user_ids_v1',
};

// Initial Seed Users
export const DEFAULT_USERS: User[] = [
  {
    id: 'usr_admin',
    name: 'MG',
    email: 'ai.caguptamahesh@gmail.com',
    mobile: '+91 94140 67123',
    role: 'admin',
    avatarBg: 'bg-sky-600',
    isVerified: true,
    activationCode: '941406',
    status: 'active',
    allowedGroupIds: ['grp_retail_counter', 'grp_fleet_logistics'],
  },
  {
    id: 'usr_bob',
    name: 'Bob Miller',
    email: 'bob.accountant@cashflow.local',
    mobile: '+91 98290 44556',
    role: 'user',
    avatarBg: 'bg-emerald-600',
    isVerified: true,
    activationCode: '582914',
    status: 'active',
    allowedGroupIds: ['grp_retail_counter'],
  },
  {
    id: 'usr_sarah',
    name: 'Sarah Jenkins',
    email: 'sarah.cashier@cashflow.local',
    mobile: '+91 94141 22334',
    role: 'user',
    avatarBg: 'bg-indigo-600',
    isVerified: true,
    activationCode: '639201',
    status: 'active',
    allowedGroupIds: ['grp_fleet_logistics'],
  },
];

// Initial Seed Parties
export const DEFAULT_PARTIES: Party[] = [
  {
    id: 'pty_001',
    groupId: 'grp_retail_counter',
    name: 'Sharma & Sons Traders',
    mobile: '+91 98290 12345',
    contactPerson: 'Rajesh Sharma',
    email: 'orders@sharmatraders.in',
    gstin: '08AAAAA1234A1Z5',
    address: 'Shop 12, Main Mandi Road, City Market',
    openingBalance: 0,
    openingBalanceType: 'NONE',
    notes: 'Regular wholesale buyer. 15-day credit settlement.',
    status: 'active',
    createdAt: '2026-10-15T09:00:00.000Z',
    createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
  },
  {
    id: 'pty_002',
    groupId: 'grp_retail_counter',
    name: 'Apex Hardware Supplies',
    mobile: '+91 94140 55678',
    contactPerson: 'Vikram Singh',
    email: 'sales@apexhardware.com',
    gstin: '08BBBCC2222B2Z4',
    address: 'Plot 44, Industrial Area Phase 2',
    openingBalance: 0,
    openingBalanceType: 'NONE',
    notes: 'Primary hardware raw materials vendor.',
    status: 'active',
    createdAt: '2026-10-15T09:30:00.000Z',
    createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
  },
  {
    id: 'pty_003',
    groupId: 'grp_retail_counter',
    name: 'Star Transport Carriers',
    mobile: '+91 98281 99887',
    contactPerson: 'Harish Patel',
    address: 'Transport Nagar Gate 3',
    openingBalance: 0,
    openingBalanceType: 'NONE',
    notes: 'Interstate logistics and cartage partner.',
    status: 'active',
    createdAt: '2026-10-16T10:00:00.000Z',
    createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
  },
  {
    id: 'pty_004',
    groupId: 'grp_retail_counter',
    name: 'Metro Store Network',
    mobile: '+91 94142 33445',
    contactPerson: 'Anita Verma',
    address: 'Central Plaza Mall, Counter 4',
    openingBalance: 0,
    openingBalanceType: 'NONE',
    notes: 'Retail retail chain network client.',
    status: 'active',
    createdAt: '2026-10-17T11:00:00.000Z',
    createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
  },
  {
    id: 'pty_005',
    groupId: 'grp_retail_counter',
    name: 'City Power & Utilities',
    mobile: '+91 98290 99001',
    contactPerson: 'Ajay Mathur',
    openingBalance: 0,
    openingBalanceType: 'NONE',
    notes: 'Utility biller and facility service provider.',
    status: 'active',
    createdAt: '2026-10-18T08:00:00.000Z',
    createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
  },
];

// Initial Seed Groups
export const DEFAULT_GROUPS: Group[] = [
  {
    id: 'grp_retail_counter',
    name: 'Main Business Cash Counter',
    purpose: 'Daily retail receipts, wholesale payments, and operational cash desk',
    currency: '₹',
    createdAt: '2026-10-15T09:00:00.000Z',
    createdBy: {
      id: 'usr_admin',
      name: 'MG',
      role: 'admin',
    },
    members: [
      { userId: 'usr_admin', name: 'MG', email: 'ai.caguptamahesh@gmail.com', role: 'admin', joinedAt: '2026-10-15T09:00:00.000Z' },
      { userId: 'usr_bob', name: 'Bob Miller', email: 'bob.accountant@cashflow.local', role: 'user', joinedAt: '2026-10-16T10:00:00.000Z' },
      { userId: 'usr_sarah', name: 'Sarah Jenkins', email: 'sarah.cashier@cashflow.local', role: 'user', joinedAt: '2026-10-16T11:00:00.000Z' },
    ],
  },
  {
    id: 'grp_fleet_logistics',
    name: 'Logistics & Fleet Operations',
    purpose: 'Vehicle fuel advances, toll expenses, maintenance, and freight settlements',
    currency: '₹',
    createdAt: '2026-10-18T14:30:00.000Z',
    createdBy: {
      id: 'usr_admin',
      name: 'MG',
      role: 'admin',
    },
    members: [
      { userId: 'usr_admin', name: 'MG', email: 'ai.caguptamahesh@gmail.com', role: 'admin', joinedAt: '2026-10-18T14:30:00.000Z' },
      { userId: 'usr_bob', name: 'Bob Miller', email: 'bob.accountant@cashflow.local', role: 'user', joinedAt: '2026-10-19T08:30:00.000Z' },
    ],
  },
];

// Initial Seed Transactions
export const DEFAULT_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx_101',
    groupId: 'grp_retail_counter',
    type: 'RECEIVED_FROM',
    amount: 14500,
    partyName: 'Sharma & Sons Traders',
    date: '2026-10-21',
    narration: 'Settlement for Invoice #INV-8820 via cash counter',
    receiptNumber: 'RCV-2026-101',
    status: 'active',
    createdAt: '2026-10-21T10:15:00.000Z',
    createdBy: { id: 'usr_sarah', name: 'Sarah Jenkins', role: 'user' },
  },
  {
    id: 'tx_102',
    groupId: 'grp_retail_counter',
    type: 'RECEIVABLE_FROM',
    amount: 8200,
    partyName: 'Apex Hardware Supplies',
    date: '2026-10-21',
    narration: 'Bulk delivery dispatched on 15-day credit terms',
    receiptNumber: 'RCV-2026-102',
    status: 'active',
    createdAt: '2026-10-21T11:30:00.000Z',
    createdBy: { id: 'usr_bob', name: 'Bob Miller', role: 'user' },
  },
  {
    id: 'tx_103',
    groupId: 'grp_retail_counter',
    type: 'PAID_TO',
    amount: 4800,
    partyName: 'Apex Hardware Supplies',
    date: '2026-10-21',
    narration: 'Part payment for raw hardware consignment batch B4',
    receiptNumber: 'PAY-2026-103',
    status: 'active',
    createdAt: '2026-10-21T14:45:00.000Z',
    createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
  },
  {
    id: 'tx_104',
    groupId: 'grp_retail_counter',
    type: 'PAYABLE_TO',
    amount: 3200,
    partyName: 'Star Transport Carriers',
    date: '2026-10-22',
    narration: 'Freight and cartage charges pending invoice verification',
    receiptNumber: 'PYB-2026-104',
    status: 'active',
    createdAt: '2026-10-22T08:20:00.000Z',
    createdBy: { id: 'usr_sarah', name: 'Sarah Jenkins', role: 'user' },
  },
  {
    id: 'tx_105',
    groupId: 'grp_retail_counter',
    type: 'RECEIVED_FROM',
    amount: 6750,
    partyName: 'Metro Store Network',
    date: '2026-10-22',
    narration: 'Cash token advance for weekend retail order',
    receiptNumber: 'RCV-2026-105',
    status: 'active',
    createdAt: '2026-10-22T09:10:00.000Z',
    createdBy: { id: 'usr_bob', name: 'Bob Miller', role: 'user' },
  },
  {
    id: 'tx_106',
    groupId: 'grp_retail_counter',
    type: 'PAID_TO',
    amount: 1200,
    partyName: 'City Power & Utilities',
    date: '2026-10-22',
    narration: 'Electricity meter bill and facility maintenance',
    receiptNumber: 'PAY-2026-106',
    status: 'active',
    createdAt: '2026-10-22T09:45:00.000Z',
    createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
  },
];

// Seed Audit Logs
export const DEFAULT_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'log_001',
    groupId: 'grp_retail_counter',
    transactionId: 'tx_101',
    receiptNumber: 'RCV-2026-101',
    action: 'CREATE',
    performedBy: { id: 'usr_sarah', name: 'Sarah Jenkins', role: 'user' },
    timestamp: '2026-10-21T10:15:00.000Z',
    summary: 'Created "Received from" Sharma & Sons Traders of ₹14,500',
  },
  {
    id: 'log_002',
    groupId: 'grp_retail_counter',
    transactionId: 'tx_102',
    receiptNumber: 'RCV-2026-102',
    action: 'CREATE',
    performedBy: { id: 'usr_bob', name: 'Bob Miller', role: 'user' },
    timestamp: '2026-10-21T11:30:00.000Z',
    summary: 'Created "Receivable from" Apex Hardware Supplies of ₹8,200',
  },
  {
    id: 'log_003',
    groupId: 'grp_retail_counter',
    transactionId: 'tx_103',
    receiptNumber: 'PAY-2026-103',
    action: 'CREATE',
    performedBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
    timestamp: '2026-10-21T14:45:00.000Z',
    summary: 'Created "Paid to" Apex Hardware Supplies of ₹4,800',
  },
  {
    id: 'log_004',
    groupId: 'grp_retail_counter',
    transactionId: 'tx_104',
    receiptNumber: 'PYB-2026-104',
    action: 'CREATE',
    performedBy: { id: 'usr_sarah', name: 'Sarah Jenkins', role: 'user' },
    timestamp: '2026-10-22T08:20:00.000Z',
    summary: 'Created "Payable to" Star Transport Carriers of ₹3,200',
  },
];

// Initial Seed Reference Notes for the Text Panel
export const DEFAULT_REFERENCE_NOTES: ReferenceNote[] = [
  {
    id: 'note_101',
    groupId: 'grp_retail_counter',
    title: 'Bank Current A/C & UPI QR for Direct Wire Transfers',
    content: 'Bank: HDFC Bank Ltd.\nAccount Name: CashFlow Enterprise Trading Desk\nA/C No: 50200088921134\nIFSC Code: HDFC0001245\nBranch: Commercial Market Extension\nUPI ID: cashflowdesk@hdfcbank\n*Note: Always verify receipt and confirm with MG before dispatching goods.*',
    tag: 'BANK_DETAILS',
    priority: 'HIGH',
    isPinned: true,
    color: 'blue',
    createdAt: '2026-10-20T09:00:00.000Z',
    updatedAt: '2026-10-20T09:00:00.000Z',
    createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
  },
  {
    id: 'note_102',
    groupId: 'grp_retail_counter',
    title: 'Counter Cash Handover & Day-End Closing Procedure',
    content: '1. Physical Cash Count: Count all notes by denomination at 8:00 PM.\n2. Reconcile with CashFlow Ledger Net Balance. Verify any variance.\n3. Cash Retained in Counter Drawer: Keep ₹5,000 float for morning opening change.\n4. Vault Handover: Deposit excess cash into the primary safe with dual sign-off.\n5. Log daily tally in Cash Tally module with cashier initials.',
    tag: 'CASH_HANDOVER',
    priority: 'HIGH',
    isPinned: true,
    color: 'amber',
    createdAt: '2026-10-20T09:30:00.000Z',
    updatedAt: '2026-10-20T09:30:00.000Z',
    createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
  },
  {
    id: 'note_103',
    groupId: 'grp_retail_counter',
    title: 'Payment Collection Follow-up - Apex Hardware Supplies',
    content: 'Credit terms expire on 25th Oct. Follow up with Accounts Manager Mr. Rajesh regarding the remaining balance on bulk consignment B4.\nPhone: +91 98765 43210.',
    tag: 'REMINDER',
    priority: 'URGENT',
    isPinned: false,
    color: 'rose',
    relatedParty: 'Apex Hardware Supplies',
    createdAt: '2026-10-21T11:45:00.000Z',
    updatedAt: '2026-10-21T11:45:00.000Z',
    createdBy: { id: 'usr_bob', name: 'Bob Miller', role: 'user' },
  },
  {
    id: 'note_104',
    groupId: 'grp_retail_counter',
    title: 'GST & Cash Transaction Regulatory Threshold Compliance',
    content: 'Section 269ST Income Tax Rule: No person shall receive an amount of ₹2,00,000 or more in cash in aggregate from a person in a day, or in respect of a single transaction.\nFor transactions above ₹50,000 in cash, customer PAN is mandatory on receipt voucher.',
    tag: 'TAX_GST',
    priority: 'NORMAL',
    isPinned: false,
    color: 'emerald',
    createdAt: '2026-10-22T08:00:00.000Z',
    updatedAt: '2026-10-22T08:00:00.000Z',
    createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' },
  },
];

// BroadcastChannel for instant zero-latency multi-tab sync
let syncChannel: BroadcastChannel | null = null;
try {
  if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
    syncChannel = new BroadcastChannel('cashflow_ledger_sync');
  }
} catch (e) {
  console.warn('BroadcastChannel not available in this environment', e);
}

class StorageService {
  private listeners: Set<(event: { type: string; payload?: any }) => void> = new Set();

  constructor() {
    this.initStorage();
    if (syncChannel) {
      syncChannel.onmessage = (event) => {
        this.handleRemoteEvent(event.data);
      };
    }
    // Listen to real-time server SSE events from all connected mobile phones and devices
    syncService.subscribe((event) => {
      this.handleRemoteEvent(event);
    });

    // Synchronize latest canonical state from central server on load
    if (typeof window !== 'undefined') {
      this.fetchServerState();
    }
  }

  public async fetchServerState(): Promise<void> {
    try {
      const res = await fetch('/api/ledger/state');
      if (res.ok) {
        const data = await res.json();
        this.hydrateFromServer(data);
      }
    } catch (e) {
      // offline fallback
    }
  }

  public hydrateFromServer(data: any): void {
    if (!data) return;
    if (Array.isArray(data.groups) && data.groups.length > 0) {
      localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(data.groups));
    }
    if (Array.isArray(data.transactions)) {
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(data.transactions));
    }
    if (Array.isArray(data.parties)) {
      localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(data.parties));
    }
    if (Array.isArray(data.referenceNotes)) {
      this.setSecureItem(STORAGE_KEYS.REFERENCE_NOTES, data.referenceNotes);
    }
    if (Array.isArray(data.users) && data.users.length > 0) {
      const deletedIds = this.getDeletedUserIds();
      const activeUsers = data.users.filter((u: any) => u.status !== 'deleted' && !deletedIds.has(u.id));
      this.setSecureItem(STORAGE_KEYS.USERS, activeUsers);
    }
    if (Array.isArray(data.auditLogs)) {
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(data.auditLogs));
    }
    if (Array.isArray(data.tallySessions)) {
      this.setSecureItem(STORAGE_KEYS.TALLY_SESSIONS, data.tallySessions);
    }
    this.notifyListeners({ type: 'SERVER_HYDRATED' });
  }

  // Ingest real-time SSE updates from other devices into local storage immediately
  private handleRemoteEvent(event: { type: string; payload?: any; sourceUser?: string }) {
    if (!event || !event.type) return;

    try {
      switch (event.type) {
        case 'TRANSACTION_CREATED': {
          const tx = event.payload as Transaction;
          if (tx && tx.id) {
            const all = this.getAllTransactionsRaw();
            const idx = all.findIndex((t) => t.id === tx.id);
            if (idx >= 0) all[idx] = tx;
            else all.unshift(tx);
            localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(all));
          }
          break;
        }
        case 'TRANSACTION_UPDATED': {
          const tx = event.payload as Transaction;
          if (tx && tx.id) {
            const all = this.getAllTransactionsRaw();
            const idx = all.findIndex((t) => t.id === tx.id);
            if (idx >= 0) all[idx] = tx;
            else all.unshift(tx);
            localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(all));
          }
          break;
        }
        case 'TRANSACTION_DELETED': {
          const id = typeof event.payload === 'string' ? event.payload : event.payload?.id;
          if (id) {
            const all = this.getAllTransactionsRaw();
            const idx = all.findIndex((t) => t.id === id);
            if (idx >= 0) {
              all[idx].status = 'deleted';
              localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(all));
            }
          }
          break;
        }
        case 'PARTY_CREATED': {
          const party = event.payload as Party;
          if (party && party.id) {
            const all = this.getAllPartiesRaw();
            const idx = all.findIndex((p) => p.id === party.id);
            if (idx >= 0) all[idx] = party;
            else all.push(party);
            localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(all));
          }
          break;
        }
        case 'PARTY_UPDATED': {
          const party = event.payload as Party;
          if (party && party.id) {
            const all = this.getAllPartiesRaw();
            const idx = all.findIndex((p) => p.id === party.id);
            if (idx >= 0) all[idx] = party;
            localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(all));
          }
          break;
        }
        case 'PARTY_DELETED': {
          const id = typeof event.payload === 'string' ? event.payload : event.payload?.id;
          if (id) {
            const all = this.getAllPartiesRaw();
            const idx = all.findIndex((p) => p.id === id);
            if (idx >= 0) {
              all[idx].status = 'archived';
              localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(all));
            }
          }
          break;
        }
        case 'NOTE_CREATED':
        case 'NOTE_UPDATED': {
          const note = event.payload as ReferenceNote;
          if (note && note.id) {
            const all = this.getAllReferenceNotesRaw();
            const idx = all.findIndex((n) => n.id === note.id);
            if (idx >= 0) all[idx] = note;
            else all.unshift(note);
            localStorage.setItem(STORAGE_KEYS.REFERENCE_NOTES, JSON.stringify(all));
          }
          break;
        }
        case 'NOTE_DELETED': {
          const id = typeof event.payload === 'string' ? event.payload : event.payload?.id;
          if (id) {
            const all = this.getAllReferenceNotesRaw().filter((n) => n.id !== id);
            localStorage.setItem(STORAGE_KEYS.REFERENCE_NOTES, JSON.stringify(all));
          }
          break;
        }
        case 'TALLY_RECORDED': {
          const tally = event.payload as CashTallySession;
          if (tally && tally.id) {
            const all = this.getAllTallySessionsRaw();
            all.unshift(tally);
            localStorage.setItem(STORAGE_KEYS.TALLY_SESSIONS, JSON.stringify(all));
          }
          break;
        }
        case 'GROUP_CREATED': {
          const grp = event.payload as Group;
          if (grp && grp.id) {
            const all = this.getGroups();
            if (!all.some((g) => g.id === grp.id)) {
              all.push(grp);
              localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(all));
            }
          }
          break;
        }
        case 'USERS_UPDATED': {
          if (Array.isArray(event.payload)) {
            const deletedIds = this.getDeletedUserIds();
            const activeUsers = event.payload.filter((u: any) => u.status !== 'deleted' && !deletedIds.has(u.id));
            this.setSecureItem(STORAGE_KEYS.USERS, activeUsers);
          }
          break;
        }
        case 'AUDIT_LOG_ADDED': {
          const log = event.payload as AuditLogEntry;
          if (log && log.id) {
            const all = this.getAuditLogs();
            all.unshift(log);
            if (all.length > 500) all.length = 500;
            localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(all));
          }
          break;
        }
        case 'DEFUNCTION_TRIGGERED': {
          const defState = event.payload || { isDefunctioned: true };
          localStorage.setItem(STORAGE_KEYS.DEFUNCTION_STATE, JSON.stringify(defState));
          break;
        }
        case 'LEDGER_FULL_SYNC': {
          this.hydrateFromServer(event.payload);
          break;
        }
      }
    } catch (e) {
      console.error('Error handling remote sync event:', e);
    }

    this.notifyListeners(event);
  }

  // --- AES-256-GCM Zero-Knowledge Storage Helpers ---
  private getSecureItem<T>(key: string, fallback: T): T {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return fallback;
      return cryptoService.decryptFast<T>(raw, fallback);
    } catch {
      return fallback;
    }
  }

  private setSecureItem(key: string, value: any): void {
    try {
      const enc = cryptoService.encryptFast(value);
      localStorage.setItem(key, enc);
    } catch (e) {
      console.error('Secure storage error:', e);
    }
  }

  private initStorage() {
    if (typeof window === 'undefined') return;

    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(DEFAULT_USERS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.CURRENT_USER)) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(DEFAULT_USERS[0]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.GROUPS)) {
      localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(DEFAULT_GROUPS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.CURRENT_GROUP_ID)) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_GROUP_ID, DEFAULT_GROUPS[0].id);
    }
    if (!localStorage.getItem(STORAGE_KEYS.TRANSACTIONS)) {
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(DEFAULT_TRANSACTIONS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS)) {
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(DEFAULT_AUDIT_LOGS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.REFERENCE_NOTES)) {
      localStorage.setItem(STORAGE_KEYS.REFERENCE_NOTES, JSON.stringify(DEFAULT_REFERENCE_NOTES));
    }
    if (!localStorage.getItem(STORAGE_KEYS.TALLY_SESSIONS)) {
      localStorage.setItem(STORAGE_KEYS.TALLY_SESSIONS, JSON.stringify([]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.PARTIES)) {
      localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(DEFAULT_PARTIES));
    }
    if (!localStorage.getItem(STORAGE_KEYS.SIGNUP_REQUESTS)) {
      localStorage.setItem(STORAGE_KEYS.SIGNUP_REQUESTS, JSON.stringify([]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.DEFUNCTION_STATE)) {
      localStorage.setItem(STORAGE_KEYS.DEFUNCTION_STATE, JSON.stringify({ isDefunctioned: false }));
    }
  }

  public subscribe(listener: (event: { type: string; payload?: any }) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners(event: { type: string; payload?: any }) {
    this.listeners.forEach((l) => l(event));
  }

  private broadcast(event: { type: string; payload?: any }) {
    this.notifyListeners(event);
    if (syncChannel) {
      try {
        syncChannel.postMessage(event);
      } catch (err) {
        console.warn('Broadcast error:', err);
      }
    }
    // Push simultaneously across all LAN/Mobile devices via central server
    try {
      const curUser = this.getCurrentUser();
      syncService.pushChange(event.type, event.payload, curUser?.name || 'User');
    } catch (e) {
      // offline fallback
    }
  }

  // --- Users & Authentication ---
  public getDeletedUserIds(): Set<string> {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.DELETED_USER_IDS);
      return new Set(raw ? JSON.parse(raw) : []);
    } catch {
      return new Set();
    }
  }

  public addDeletedUserId(id: string): void {
    try {
      const set = this.getDeletedUserIds();
      set.add(id);
      localStorage.setItem(STORAGE_KEYS.DELETED_USER_IDS, JSON.stringify(Array.from(set)));
    } catch (e) {
      console.warn('Failed to record deleted user ID:', e);
    }
  }

  public removeDeletedUserId(id: string): void {
    try {
      const set = this.getDeletedUserIds();
      set.delete(id);
      localStorage.setItem(STORAGE_KEYS.DELETED_USER_IDS, JSON.stringify(Array.from(set)));
    } catch (e) {
      console.warn('Failed to remove deleted user ID:', e);
    }
  }

  public normalizeMobile(mobile: string): string {
    if (!mobile) return '';
    const digits = mobile.replace(/\D/g, '');
    return digits.length >= 10 ? digits.slice(-10) : digits;
  }

  public checkDuplicateMobile(mobile: string, excludeUserId?: string): { isDuplicate: boolean; existingUser?: User } {
    const norm = this.normalizeMobile(mobile);
    if (!norm) return { isDuplicate: false };
    const users = this.getUsers(); // already filters out deleted users
    const existing = users.find((u) => u.id !== excludeUserId && this.normalizeMobile(u.mobile) === norm);
    return { isDuplicate: !!existing, existingUser: existing };
  }

  public getUsers(): User[] {
    const users = this.getSecureItem<User[]>(STORAGE_KEYS.USERS, DEFAULT_USERS);
    const deletedIds = this.getDeletedUserIds();
    return users.filter((u) => u.status !== 'deleted' && !deletedIds.has(u.id));
  }

  public getCurrentUser(): User {
    return this.getSecureItem<User>(STORAGE_KEYS.CURRENT_USER, DEFAULT_USERS[0]);
  }

  public setCurrentUser(user: User): void {
    this.setSecureItem(STORAGE_KEYS.CURRENT_USER, user);
    this.broadcast({ type: 'USER_CHANGED', payload: user });
  }

  public addUser(user: Omit<User, 'id'>): User {
    const dup = this.checkDuplicateMobile(user.mobile);
    if (dup.isDuplicate) {
      throw new Error(`Mobile number (${user.mobile}) is already registered to user "${dup.existingUser?.name}". Each user must have a unique mobile number.`);
    }

    const users = this.getUsers();
    const newUser: User = {
      ...user,
      id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    };
    this.removeDeletedUserId(newUser.id);
    users.push(newUser);
    this.setSecureItem(STORAGE_KEYS.USERS, users);
    this.broadcast({ type: 'USERS_UPDATED', payload: users });
    return newUser;
  }

  public async updateUser(userId: string, updates: Partial<User>): Promise<User | null> {
    const users = this.getUsers();
    const idx = users.findIndex((u) => u.id === userId);
    if (idx === -1) return null;

    if (updates.mobile) {
      const dup = this.checkDuplicateMobile(updates.mobile, userId);
      if (dup.isDuplicate) {
        throw new Error(`Mobile number (${updates.mobile}) is already in use by user "${dup.existingUser?.name}". Each user must have a unique mobile number.`);
      }
    }

    const updatedUser: User = {
      ...users[idx],
      ...updates,
    };
    users[idx] = updatedUser;
    this.setSecureItem(STORAGE_KEYS.USERS, users);

    const currentUser = this.getCurrentUser();
    if (currentUser.id === userId) {
      this.setCurrentUser(updatedUser);
    }

    try {
      await fetch(`/api/auth/update-user/${userId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    } catch (e) {
      // offline fallback
    }

    this.addAuditLog({
      groupId: this.getActiveGroupId(),
      action: 'USER_UPDATE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Updated profile for team member "${updatedUser.name}" (${updatedUser.role})`,
    });

    this.broadcast({ type: 'USERS_UPDATED', payload: users });
    return updatedUser;
  }

  public async deleteUser(userId: string): Promise<boolean> {
    if (userId === 'usr_admin') {
      throw new Error('Master Administrator MG account cannot be deleted.');
    }

    const users = this.getUsers();
    const userToDelete = users.find((u) => u.id === userId);
    if (!userToDelete) return false;

    // Permanently remember this ID as deleted so it can never resurrect
    this.addDeletedUserId(userId);

    const filtered = users.filter((u) => u.id !== userId);
    this.setSecureItem(STORAGE_KEYS.USERS, filtered);

    // Clean up from all business group member lists
    try {
      const groups = this.getGroups();
      let changed = false;
      groups.forEach((g) => {
        const origLen = g.members.length;
        g.members = g.members.filter((m) => m.userId !== userId);
        if (g.members.length !== origLen) changed = true;
      });
      if (changed) {
        localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(groups));
      }
    } catch (e) {
      console.warn('Failed to remove user from group lists:', e);
    }

    // If current session was deleted user, revert to MG
    const currentUser = this.getCurrentUser();
    if (currentUser.id === userId) {
      this.setCurrentUser(DEFAULT_USERS[0]);
    }

    // Await server database deletion
    try {
      const res = await fetch(`/api/auth/delete-user/${userId}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        await this.fetchServerState();
      }
    } catch (e) {
      console.warn('Network error during server user delete:', e);
    }

    this.addAuditLog({
      groupId: this.getActiveGroupId(),
      action: 'USER_DELETE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Deleted user profile "${userToDelete.name}" (${userToDelete.mobile}, ${userToDelete.email})`,
    });

    this.broadcast({ type: 'USERS_UPDATED', payload: filtered });
    return true;
  }

  public async clearAllData(adminUser?: User): Promise<void> {
    const actor = adminUser || this.getCurrentUser();

    // Wipe local operational ledger records
    this.setSecureItem(STORAGE_KEYS.TRANSACTIONS, []);
    this.setSecureItem(STORAGE_KEYS.PARTIES, []);
    this.setSecureItem(STORAGE_KEYS.REFERENCE_NOTES, []);
    this.setSecureItem(STORAGE_KEYS.TALLY_SESSIONS, []);

    this.addAuditLog({
      groupId: this.getActiveGroupId(),
      action: 'ALL_DATA_CLEARED',
      performedBy: { id: actor.id, name: actor.name, role: actor.role },
      summary: `ADMIN CLEAR ALL: Cleared all transactions, parties, reference notes, and tallies across all groups.`,
    });

    try {
      await fetch('/api/admin/clear-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminUserId: actor.id }),
      });
    } catch (e) {
      // offline fallback
    }

    this.broadcast({
      type: 'ALL_DATA_CLEARED',
      payload: { clearedBy: actor.name, timestamp: new Date().toISOString() },
    });
  }

  // --- Groups (With User Group-Scoped Access) ---
  public getGroups(user?: User): Group[] {
    try {
      const allGroups = this.getSecureItem<Group[]>(STORAGE_KEYS.GROUPS, DEFAULT_GROUPS);
      const targetUser = user || this.getCurrentUser();

      // Master Admin has universal access across all business groups
      if (targetUser.role === 'admin') {
        return allGroups;
      }

      // Non-admin user: strictly scoped to allowedGroupIds
      if (targetUser.allowedGroupIds && targetUser.allowedGroupIds.length > 0) {
        const filtered = allGroups.filter((g) => targetUser.allowedGroupIds!.includes(g.id));
        return filtered.length > 0 ? filtered : allGroups.slice(0, 1);
      }

      return allGroups;
    } catch {
      return DEFAULT_GROUPS;
    }
  }

  public getActiveGroupId(user?: User): string {
    const groups = this.getGroups(user);
    const stored = localStorage.getItem(STORAGE_KEYS.CURRENT_GROUP_ID);
    if (stored && groups.some((g) => g.id === stored)) {
      return stored;
    }
    return groups[0]?.id || 'grp_retail_counter';
  }

  public setActiveGroupId(id: string): void {
    localStorage.setItem(STORAGE_KEYS.CURRENT_GROUP_ID, id);
    this.broadcast({ type: 'ACTIVE_GROUP_CHANGED', payload: id });
  }

  public createGroup(name: string, purpose: string, currency: string = '₹'): Group {
    const groups = this.getGroups();
    const currentUser = this.getCurrentUser();
    const newGroup: Group = {
      id: `grp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      purpose: purpose.trim(),
      currency: currency || '₹',
      createdAt: new Date().toISOString(),
      createdBy: {
        id: currentUser.id,
        name: currentUser.name,
        role: currentUser.role,
      },
      members: [
        {
          userId: currentUser.id,
          name: currentUser.name,
          email: currentUser.email,
          role: currentUser.role,
          joinedAt: new Date().toISOString(),
        },
      ],
    };

    groups.push(newGroup);
    localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(groups));
    this.setActiveGroupId(newGroup.id);

    // Audit log
    this.addAuditLog({
      groupId: newGroup.id,
      action: 'GROUP_CREATE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Created new group: "${newGroup.name}" (${newGroup.purpose})`,
    });

    this.broadcast({ type: 'GROUP_CREATED', payload: newGroup });
    return newGroup;
  }

  public addMemberToGroup(groupId: string, user: User): void {
    const groups = this.getGroups();
    const group = groups.find((g) => g.id === groupId);
    if (!group) return;

    if (!group.members.some((m) => m.userId === user.id)) {
      group.members.push({
        userId: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        joinedAt: new Date().toISOString(),
      });
      localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(groups));
      this.broadcast({ type: 'GROUP_UPDATED', payload: group });
    }
  }

  // --- Transactions ---
  public getTransactions(groupId?: string): Transaction[] {
    try {
      const list = this.getAllTransactionsRaw();
      const targetGroup = groupId || this.getActiveGroupId();
      return list.filter((t) => t.groupId === targetGroup && t.status === 'active');
    } catch {
      return [];
    }
  }

  public getAllTransactionsRaw(): Transaction[] {
    return this.getSecureItem<Transaction[]>(STORAGE_KEYS.TRANSACTIONS, DEFAULT_TRANSACTIONS);
  }

  public createTransaction(entry: {
    groupId?: string;
    type: Transaction['type'];
    amount: number;
    partyName: string;
    date: string;
    narration: string;
  }): Transaction {
    const targetGroupId = entry.groupId || this.getActiveGroupId();
    const all = this.getAllTransactionsRaw();
    const currentUser = this.getCurrentUser();
    const groupTransactions = all.filter((t) => t.groupId === targetGroupId);

    // Generate readable receipt number
    const prefix = entry.type === 'RECEIVED_FROM' ? 'RCV' :
                   entry.type === 'RECEIVABLE_FROM' ? 'REC' :
                   entry.type === 'PAID_TO' ? 'PAY' : 'PYB';
    const seq = (groupTransactions.length + 101).toString();
    const receiptNumber = `${prefix}-${new Date().getFullYear()}-${seq}`;

    const newTx: Transaction = {
      id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      groupId: targetGroupId,
      type: entry.type,
      amount: Number(entry.amount),
      partyName: entry.partyName.trim(),
      date: entry.date,
      narration: entry.narration.trim(),
      receiptNumber,
      status: 'active',
      createdAt: new Date().toISOString(),
      createdBy: {
        id: currentUser.id,
        name: currentUser.name,
        role: currentUser.role,
      },
    };

    all.unshift(newTx);
    this.setSecureItem(STORAGE_KEYS.TRANSACTIONS, all);

    // Audit Log
    const typeLabel = this.formatTypeLabel(newTx.type);
    const activeGroup = this.getGroups().find(g => g.id === targetGroupId);
    const curr = activeGroup?.currency || '₹';
    this.addAuditLog({
      groupId: targetGroupId,
      transactionId: newTx.id,
      receiptNumber: newTx.receiptNumber,
      action: 'CREATE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Created "${typeLabel}" ${newTx.partyName}: ${curr}${newTx.amount.toLocaleString()} on ${newTx.date}`,
    });

    this.broadcast({ type: 'TRANSACTION_CREATED', payload: { ...newTx, actor: currentUser } });
    return newTx;
  }

  public updateTransaction(
    id: string,
    updates: {
      type?: Transaction['type'];
      amount?: number;
      partyName?: string;
      date?: string;
      narration?: string;
    }
  ): Transaction | null {
    const all = this.getAllTransactionsRaw();
    const idx = all.findIndex((t) => t.id === id);
    if (idx === -1) return null;

    const oldTx = all[idx];
    const currentUser = this.getCurrentUser();

    const changedFields: { field: string; oldValue: any; newValue: any }[] = [];
    if (updates.type && updates.type !== oldTx.type) {
      changedFields.push({ field: 'Type', oldValue: this.formatTypeLabel(oldTx.type), newValue: this.formatTypeLabel(updates.type) });
    }
    if (updates.amount !== undefined && updates.amount !== oldTx.amount) {
      changedFields.push({ field: 'Amount', oldValue: oldTx.amount, newValue: updates.amount });
    }
    if (updates.partyName && updates.partyName !== oldTx.partyName) {
      changedFields.push({ field: 'Party', oldValue: oldTx.partyName, newValue: updates.partyName });
    }
    if (updates.date && updates.date !== oldTx.date) {
      changedFields.push({ field: 'Date', oldValue: oldTx.date, newValue: updates.date });
    }
    if (updates.narration !== undefined && updates.narration !== oldTx.narration) {
      changedFields.push({ field: 'Narration', oldValue: oldTx.narration, newValue: updates.narration });
    }

    const updatedTx: Transaction = {
      ...oldTx,
      ...updates,
      updatedAt: new Date().toISOString(),
      updatedBy: {
        id: currentUser.id,
        name: currentUser.name,
        role: currentUser.role,
      },
    };

    all[idx] = updatedTx;
    this.setSecureItem(STORAGE_KEYS.TRANSACTIONS, all);

    // Audit Log
    this.addAuditLog({
      groupId: oldTx.groupId,
      transactionId: oldTx.id,
      receiptNumber: oldTx.receiptNumber,
      action: 'UPDATE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Modified entry (${oldTx.receiptNumber} - ${oldTx.partyName}). Changed: ${changedFields.map(f => `${f.field} (${f.oldValue} -> ${f.newValue})`).join(', ') || 'details'}`,
      details: changedFields,
    });

    this.broadcast({ type: 'TRANSACTION_UPDATED', payload: { ...updatedTx, actor: currentUser, changedFields } });
    return updatedTx;
  }

  public deleteTransaction(id: string): boolean {
    const all = this.getAllTransactionsRaw();
    const idx = all.findIndex((t) => t.id === id);
    if (idx === -1) return false;

    const oldTx = all[idx];
    const currentUser = this.getCurrentUser();

    // Soft delete
    all[idx] = {
      ...oldTx,
      status: 'deleted',
      updatedAt: new Date().toISOString(),
      updatedBy: {
        id: currentUser.id,
        name: currentUser.name,
        role: currentUser.role,
      },
    };

    this.setSecureItem(STORAGE_KEYS.TRANSACTIONS, all);

    // Audit log
    this.addAuditLog({
      groupId: oldTx.groupId,
      transactionId: oldTx.id,
      receiptNumber: oldTx.receiptNumber,
      action: 'DELETE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Deleted transaction #${oldTx.receiptNumber} (${this.formatTypeLabel(oldTx.type)} ${oldTx.partyName} of ₹${oldTx.amount})`,
    });

    this.broadcast({
      type: 'TRANSACTION_DELETED',
      payload: { id, receiptNumber: oldTx.receiptNumber, partyName: oldTx.partyName, amount: oldTx.amount, actor: currentUser },
    });
    return true;
  }

  // --- Audit Logs ---
  public getAuditLogs(groupId?: string): AuditLogEntry[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
      const list: AuditLogEntry[] = data ? JSON.parse(data) : DEFAULT_AUDIT_LOGS;
      const targetGroup = groupId || this.getActiveGroupId();
      return list.filter((l) => l.groupId === targetGroup).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    } catch {
      return [];
    }
  }

  private addAuditLog(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
      const list: AuditLogEntry[] = data ? JSON.parse(data) : DEFAULT_AUDIT_LOGS;
      const newEntry: AuditLogEntry = {
        ...entry,
        id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        timestamp: new Date().toISOString(),
      };
      list.unshift(newEntry);
      // Keep recent 500 audit logs
      if (list.length > 500) list.length = 500;
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(list));
      this.broadcast({ type: 'AUDIT_LOG_ADDED', payload: newEntry });
    } catch (e) {
      console.error('Failed to write audit log', e);
    }
  }

  // ==========================================
  // Party Directory & Management Services
  // ==========================================
  public getParties(groupId?: string): Party[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PARTIES);
      const list: Party[] = data ? JSON.parse(data) : DEFAULT_PARTIES;
      const targetGroup = groupId || this.getActiveGroupId();
      return list.filter((p) => p.groupId === targetGroup && p.status === 'active');
    } catch {
      return DEFAULT_PARTIES;
    }
  }

  public getAllPartiesRaw(): Party[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PARTIES);
      return data ? JSON.parse(data) : DEFAULT_PARTIES;
    } catch {
      return DEFAULT_PARTIES;
    }
  }

  public createParty(party: Omit<Party, 'id' | 'createdAt' | 'createdBy'>): Party {
    const all = this.getAllPartiesRaw();
    const currentUser = this.getCurrentUser();
    const targetGroup = party.groupId || this.getActiveGroupId();

    const newParty: Party = {
      ...party,
      groupId: targetGroup,
      id: `pty_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
      createdBy: {
        id: currentUser.id,
        name: currentUser.name,
        role: currentUser.role,
      },
    };

    all.push(newParty);
    localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(all));

    this.addAuditLog({
      groupId: targetGroup,
      action: 'PARTY_CREATE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Created party directory entry for "${newParty.name}" (Mobile: ${newParty.mobile || 'N/A'})`,
    });

    this.broadcast({ type: 'PARTY_CREATED', payload: newParty });
    return newParty;
  }

  public updateParty(id: string, updates: Partial<Party>): Party | null {
    const all = this.getAllPartiesRaw();
    const idx = all.findIndex((p) => p.id === id);
    if (idx === -1) return null;

    const currentUser = this.getCurrentUser();
    const updated = { ...all[idx], ...updates };
    all[idx] = updated;
    localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(all));

    this.addAuditLog({
      groupId: updated.groupId,
      action: 'PARTY_UPDATE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Updated party profile for "${updated.name}"`,
    });

    this.broadcast({ type: 'PARTY_UPDATED', payload: updated });
    return updated;
  }

  public deleteParty(id: string): boolean {
    const all = this.getAllPartiesRaw();
    const target = all.find((p) => p.id === id);
    if (!target) return false;

    target.status = 'archived';
    localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(all));

    const currentUser = this.getCurrentUser();
    this.addAuditLog({
      groupId: target.groupId,
      action: 'PARTY_DELETE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Archived party directory entry for "${target.name}"`,
    });

    this.broadcast({ type: 'PARTY_DELETED', payload: { id } });
    return true;
  }

  // --- Party Calculations & Summaries ---
  public getPartySummaries(groupId?: string): PartySummary[] {
    const transactions = this.getTransactions(groupId);
    const registeredParties = this.getParties(groupId);
    const map = new Map<
      string,
      {
        received: number;
        receivable: number;
        paid: number;
        payable: number;
        lastDate: string;
        count: number;
        mobile?: string;
        contactPerson?: string;
      }
    >();

    // 1. Seed with registered parties
    registeredParties.forEach((p) => {
      map.set(p.name.trim(), {
        received: 0,
        receivable: 0,
        paid: 0,
        payable: 0,
        lastDate: p.createdAt.slice(0, 10),
        count: 0,
        mobile: p.mobile,
        contactPerson: p.contactPerson,
      });
    });

    // 2. Aggregate all active transactions
    transactions.forEach((tx) => {
      const name = tx.partyName.trim();
      if (!name) return;
      const current = map.get(name) || {
        received: 0,
        receivable: 0,
        paid: 0,
        payable: 0,
        lastDate: tx.date,
        count: 0,
      };

      current.count += 1;
      if (!current.lastDate || new Date(tx.date) > new Date(current.lastDate)) {
        current.lastDate = tx.date;
      }

      switch (tx.type) {
        case 'RECEIVED_FROM':
          current.received += tx.amount;
          break;
        case 'RECEIVABLE_FROM':
          current.receivable += tx.amount;
          break;
        case 'PAID_TO':
          current.paid += tx.amount;
          break;
        case 'PAYABLE_TO':
          current.payable += tx.amount;
          break;
      }

      map.set(name, current);
    });

    const summaries: PartySummary[] = [];
    map.forEach((data, partyName) => {
      // Net Receivable = (Receivable from + Paid to) - (Received from + Payable to)
      const netBalance = data.receivable + data.paid - (data.received + data.payable);
      summaries.push({
        partyName,
        mobile: data.mobile,
        contactPerson: data.contactPerson,
        totalReceived: data.received,
        totalReceivable: data.receivable,
        totalPaid: data.paid,
        totalPayable: data.payable,
        netBalance,
        lastTransactionDate: data.lastDate,
        transactionCount: data.count,
      });
    });

    return summaries.sort((a, b) => Math.abs(b.netBalance) - Math.abs(a.netBalance));
  }

  // --- Calculate Dashboard Overview Metrics ---
  public getDashboardMetrics(groupId?: string): LedgerDashboardMetrics {
    const transactions = this.getTransactions(groupId);
    let totalCashReceived = 0;
    let totalReceivable = 0;
    let totalCashPaid = 0;
    let totalPayable = 0;

    transactions.forEach((tx) => {
      switch (tx.type) {
        case 'RECEIVED_FROM':
          totalCashReceived += tx.amount;
          break;
        case 'RECEIVABLE_FROM':
          totalReceivable += tx.amount;
          break;
        case 'PAID_TO':
          totalCashPaid += tx.amount;
          break;
        case 'PAYABLE_TO':
          totalPayable += tx.amount;
          break;
      }
    });

    const netCashBalance = totalCashReceived - totalCashPaid;
    const netOverallPosition = (totalCashReceived + totalReceivable) - (totalCashPaid + totalPayable);
    const parties = this.getPartySummaries(groupId);

    return {
      totalCashReceived,
      totalReceivable,
      totalCashPaid,
      totalPayable,
      netCashBalance,
      netOverallPosition,
      activePartiesCount: parties.length,
      totalTransactionsCount: transactions.length,
    };
  }

  // --- Unique Parties list for quick select in transaction entries ---
  public getExistingPartyNames(groupId?: string): string[] {
    const txs = this.getTransactions(groupId);
    const parties = this.getParties(groupId);
    const set = new Set<string>();
    parties.forEach((p) => set.add(p.name.trim()));
    txs.forEach((t) => set.add(t.partyName.trim()));
    return Array.from(set).filter(Boolean);
  }

  // ==========================================
  // Text Panel & Reference Notes Services
  // ==========================================
  public getReferenceNotes(groupId?: string): ReferenceNote[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.REFERENCE_NOTES);
      const list: ReferenceNote[] = data ? JSON.parse(data) : DEFAULT_REFERENCE_NOTES;
      const targetGroup = groupId || this.getActiveGroupId();
      return list.filter((n) => n.groupId === targetGroup);
    } catch {
      return [];
    }
  }

  public getAllReferenceNotesRaw(): ReferenceNote[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.REFERENCE_NOTES);
      return data ? JSON.parse(data) : DEFAULT_REFERENCE_NOTES;
    } catch {
      return DEFAULT_REFERENCE_NOTES;
    }
  }

  public createReferenceNote(entry: {
    groupId?: string;
    title: string;
    content: string;
    tag: NoteTag;
    priority: NotePriority;
    isPinned?: boolean;
    color?: NoteColor;
    relatedParty?: string;
  }): ReferenceNote {
    const targetGroupId = entry.groupId || this.getActiveGroupId();
    const all = this.getAllReferenceNotesRaw();
    const currentUser = this.getCurrentUser();
    const now = new Date().toISOString();

    const newNote: ReferenceNote = {
      id: `note_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      groupId: targetGroupId,
      title: entry.title.trim() || 'Untitled Reference Note',
      content: entry.content.trim(),
      tag: entry.tag || 'GENERAL',
      priority: entry.priority || 'NORMAL',
      isPinned: entry.isPinned ?? false,
      color: entry.color || 'amber',
      relatedParty: entry.relatedParty?.trim() || undefined,
      createdAt: now,
      updatedAt: now,
      createdBy: {
        id: currentUser.id,
        name: currentUser.name,
        role: currentUser.role,
      },
    };

    all.unshift(newNote);
    localStorage.setItem(STORAGE_KEYS.REFERENCE_NOTES, JSON.stringify(all));

    this.addAuditLog({
      groupId: targetGroupId,
      action: 'NOTE_CREATE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Created reference memo: "${newNote.title}" [${newNote.tag}]`,
    });

    this.broadcast({ type: 'NOTE_CREATED', payload: newNote });
    return newNote;
  }

  public updateReferenceNote(
    id: string,
    updates: Partial<Omit<ReferenceNote, 'id' | 'groupId' | 'createdAt' | 'createdBy'>>
  ): ReferenceNote | null {
    const all = this.getAllReferenceNotesRaw();
    const idx = all.findIndex((n) => n.id === id);
    if (idx === -1) return null;

    const currentUser = this.getCurrentUser();
    const updatedNote: ReferenceNote = {
      ...all[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    all[idx] = updatedNote;
    localStorage.setItem(STORAGE_KEYS.REFERENCE_NOTES, JSON.stringify(all));

    this.addAuditLog({
      groupId: updatedNote.groupId,
      action: 'NOTE_UPDATE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Updated reference memo: "${updatedNote.title}"`,
    });

    this.broadcast({ type: 'NOTE_UPDATED', payload: updatedNote });
    return updatedNote;
  }

  public deleteReferenceNote(id: string): boolean {
    const all = this.getAllReferenceNotesRaw();
    const target = all.find((n) => n.id === id);
    if (!target) return false;

    const remaining = all.filter((n) => n.id !== id);
    localStorage.setItem(STORAGE_KEYS.REFERENCE_NOTES, JSON.stringify(remaining));

    const currentUser = this.getCurrentUser();
    this.addAuditLog({
      groupId: target.groupId,
      action: 'NOTE_DELETE',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Deleted reference memo: "${target.title}"`,
    });

    this.broadcast({ type: 'NOTE_DELETED', payload: { id } });
    return true;
  }

  public togglePinReferenceNote(id: string): ReferenceNote | null {
    const all = this.getAllReferenceNotesRaw();
    const idx = all.findIndex((n) => n.id === id);
    if (idx === -1) return null;

    all[idx].isPinned = !all[idx].isPinned;
    all[idx].updatedAt = new Date().toISOString();
    localStorage.setItem(STORAGE_KEYS.REFERENCE_NOTES, JSON.stringify(all));
    this.broadcast({ type: 'NOTE_UPDATED', payload: all[idx] });
    return all[idx];
  }

  public getQuickScratchpad(): string {
    return localStorage.getItem(STORAGE_KEYS.QUICK_SCRATCHPAD) || '';
  }

  public setQuickScratchpad(text: string): void {
    localStorage.setItem(STORAGE_KEYS.QUICK_SCRATCHPAD, text);
    this.broadcast({ type: 'SCRATCHPAD_UPDATED', payload: text });
  }

  // ==========================================
  // Cash Denominations & Tally Services
  // ==========================================
  public getTallySessions(groupId?: string): CashTallySession[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.TALLY_SESSIONS);
      const list: CashTallySession[] = data ? JSON.parse(data) : [];
      const targetGroup = groupId || this.getActiveGroupId();
      return list.filter((s) => s.groupId === targetGroup);
    } catch {
      return [];
    }
  }

  public getAllTallySessionsRaw(): CashTallySession[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.TALLY_SESSIONS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  public saveTallySession(session: {
    groupId?: string;
    date: string;
    denominations: CashDenominationCount;
    totalPhysicalCash: number;
    systemCashBalance: number;
    notes?: string;
  }): CashTallySession {
    const targetGroupId = session.groupId || this.getActiveGroupId();
    const all = this.getAllTallySessionsRaw();
    const currentUser = this.getCurrentUser();
    const variance = session.totalPhysicalCash - session.systemCashBalance;

    const newSession: CashTallySession = {
      id: `tally_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      groupId: targetGroupId,
      date: session.date,
      timestamp: new Date().toISOString(),
      denominations: session.denominations,
      totalPhysicalCash: session.totalPhysicalCash,
      systemCashBalance: session.systemCashBalance,
      variance,
      verifiedBy: {
        id: currentUser.id,
        name: currentUser.name,
        role: currentUser.role,
      },
      notes: session.notes?.trim() || undefined,
    };

    all.unshift(newSession);
    localStorage.setItem(STORAGE_KEYS.TALLY_SESSIONS, JSON.stringify(all));

    const statusText =
      variance === 0
        ? 'Exact Match (Balanced)'
        : variance > 0
        ? `Surplus of ₹${variance.toLocaleString()}`
        : `Shortage of ₹${Math.abs(variance).toLocaleString()}`;

    this.addAuditLog({
      groupId: targetGroupId,
      action: 'TALLY_RECORD',
      performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
      summary: `Cash Drawer Tally recorded for ${session.date}: Counted Physical ₹${session.totalPhysicalCash.toLocaleString()} vs System ₹${session.systemCashBalance.toLocaleString()} (${statusText})`,
    });

    this.broadcast({ type: 'TALLY_RECORDED', payload: newSession });
    return newSession;
  }

  // ==========================================
  // Indian Mobile User Signup & Mr. MG OTP Authorization Gate
  // ==========================================
  public requestUserSignup(name: string, email: string, mobile: string): UserSignupRequest {
    const dup = this.checkDuplicateMobile(mobile);
    if (dup.isDuplicate) {
      throw new Error(`Mobile number (${mobile}) is already registered to user "${dup.existingUser?.name}". Each user must have a unique mobile number.`);
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const data = localStorage.getItem(STORAGE_KEYS.SIGNUP_REQUESTS);
    const requests: UserSignupRequest[] = data ? JSON.parse(data) : [];

    const newRequest: UserSignupRequest = {
      id: `req_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      email: email.trim(),
      mobile: mobile.trim(),
      otp,
      status: 'pending',
      requestedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
      targetAdminMobile: '+91 9414067123',
      targetAdminName: 'Mr. MG',
    };

    requests.unshift(newRequest);
    localStorage.setItem(STORAGE_KEYS.SIGNUP_REQUESTS, JSON.stringify(requests));

    this.addAuditLog({
      groupId: this.getActiveGroupId(),
      action: 'OTP_DISPATCHED',
      performedBy: { id: 'sys_auth', name: newRequest.name, role: 'user' },
      summary: `User access requested by ${newRequest.name} (${newRequest.mobile}). OTP sent to author Mr. MG (+91 9414067123)`,
    });

    this.broadcast({ type: 'SIGNUP_REQUESTED', payload: newRequest });

    // Also dispatch to local server
    try {
      fetch('/api/auth/otp/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRequest),
      });
    } catch (e) {
      // offline
    }

    return newRequest;
  }

  public getPendingSignups(): UserSignupRequest[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SIGNUP_REQUESTS);
      const list: UserSignupRequest[] = data ? JSON.parse(data) : [];
      return list.filter((r) => r.status === 'pending');
    } catch {
      return [];
    }
  }

  public verifyUserOtp(mobile: string, enteredOtp: string): { success: boolean; user?: User; message: string } {
    const data = localStorage.getItem(STORAGE_KEYS.SIGNUP_REQUESTS);
    const requests: UserSignupRequest[] = data ? JSON.parse(data) : [];

    const cleanInputMobile = mobile.replace(/[\s\-\(\)\+]/g, '');
    const cleanEnteredOtp = enteredOtp.trim();

    const req = requests.find(
      (r) => r.mobile.replace(/[\s\-\(\)\+]/g, '') === cleanInputMobile && r.status === 'pending'
    );

    if (!req) {
      return { success: false, message: 'No pending access request found for this mobile number. Please click "Generate OTP" first.' };
    }

    if (req.otp !== cleanEnteredOtp) {
      return { success: false, message: 'Incorrect OTP. Please enter the verification OTP received from Mr. MG (+91 9414067123).' };
    }

    // Mark request approved
    req.status = 'approved';
    localStorage.setItem(STORAGE_KEYS.SIGNUP_REQUESTS, JSON.stringify(requests));

    // Create or activate User
    const users = this.getUsers();
    let existingUser = users.find((u) => u.mobile.replace(/[\s\-\(\)\+]/g, '') === cleanInputMobile);

    if (!existingUser) {
      existingUser = {
        id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        name: req.name,
        email: req.email,
        mobile: req.mobile,
        role: 'user',
        avatarBg: 'bg-emerald-600',
        isVerified: true,
        status: 'active',
        createdAt: new Date().toISOString(),
      };
      users.push(existingUser);
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    } else {
      existingUser.isVerified = true;
      existingUser.status = 'active';
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    }

    this.setCurrentUser(existingUser);

    this.addAuditLog({
      groupId: this.getActiveGroupId(),
      action: 'USER_VERIFIED',
      performedBy: { id: existingUser.id, name: existingUser.name, role: existingUser.role },
      summary: `User ${existingUser.name} (${existingUser.mobile}) verified and activated via Mr. MG authorization OTP`,
    });

    this.broadcast({ type: 'USER_VERIFIED', payload: existingUser });
    return { success: true, user: existingUser, message: 'OTP verified successfully! Welcome to CashFlow Ledger.' };
  }

  public approveSignupByAdmin(requestId: string): User | null {
    const data = localStorage.getItem(STORAGE_KEYS.SIGNUP_REQUESTS);
    const requests: UserSignupRequest[] = data ? JSON.parse(data) : [];
    const req = requests.find((r) => r.id === requestId);
    if (!req) return null;

    req.status = 'approved';
    localStorage.setItem(STORAGE_KEYS.SIGNUP_REQUESTS, JSON.stringify(requests));

    const users = this.getUsers();
    let user = users.find((u) => u.mobile.replace(/[\s\-\(\)\+]/g, '') === req.mobile.replace(/[\s\-\(\)\+]/g, ''));
    if (!user) {
      user = {
        id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        name: req.name,
        email: req.email,
        mobile: req.mobile,
        role: 'user',
        avatarBg: 'bg-sky-600',
        isVerified: true,
        status: 'active',
        createdAt: new Date().toISOString(),
      };
      users.push(user);
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    } else {
      user.isVerified = true;
      user.status = 'active';
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    }

    this.broadcast({ type: 'USER_APPROVED', payload: user });
    return user;
  }

  // ==========================================
  // Password Protected Device Activation & 6-Digit Download Code
  // ==========================================
  public isDeviceActivated(): boolean {
    try {
      const val = localStorage.getItem(STORAGE_KEYS.DEVICE_ACTIVATION);
      if (!val) return false;
      const data = JSON.parse(val);
      return data.isActivated === true;
    } catch {
      return false;
    }
  }

  public getDeviceActivationState(): DeviceActivationState {
    try {
      const val = localStorage.getItem(STORAGE_KEYS.DEVICE_ACTIVATION);
      return val ? JSON.parse(val) : { isActivated: false };
    } catch {
      return { isActivated: false };
    }
  }

  public activateDevice(user: User): void {
    const state: DeviceActivationState = {
      isActivated: true,
      activatedUserId: user.id,
      activatedUserName: user.name,
      activatedAt: new Date().toISOString(),
    };
    localStorage.setItem(STORAGE_KEYS.DEVICE_ACTIVATION, JSON.stringify(state));
    this.setCurrentUser(user);
    this.broadcast({ type: 'DEVICE_ACTIVATED', payload: state });
  }

  public lockDevice(): void {
    localStorage.removeItem(STORAGE_KEYS.DEVICE_ACTIVATION);
    this.broadcast({ type: 'DEVICE_LOCKED' });
  }

  public async verifyDeviceActivationCode(code: string): Promise<{ success: boolean; user?: User; message: string }> {
    const cleanCode = code.trim();

    // 1. Check central server verification endpoint
    try {
      const res = await fetch('/api/auth/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: cleanCode }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.user) {
          this.activateDevice(data.user);
          await this.fetchServerState();
          return { success: true, user: data.user, message: data.message };
        }
      } else {
        const errData = await res.json().catch(() => ({}));
        if (errData.message) {
          return { success: false, message: errData.message };
        }
      }
    } catch (e) {
      console.warn('Network verify failed, falling back to local validation:', e);
    }

    // 2. Local fallback verification
    if (cleanCode === 'admin123' || cleanCode === '941406') {
      const admin = this.getUsers().find((u) => u.role === 'admin') || DEFAULT_USERS[0];
      this.activateDevice(admin);
      return { success: true, user: admin, message: 'Welcome Master Administrator Mr. MG!' };
    }

    const users = this.getUsers();
    const matched = users.find((u) => u.activationCode && u.activationCode.trim() === cleanCode);
    if (matched) {
      this.activateDevice(matched);
      return { success: true, user: matched, message: `Welcome ${matched.name}! Device activated.` };
    }

    return {
      success: false,
      message: 'Invalid 6-digit download code. Please enter the code shared by Mr. MG (+91 9414067123).',
    };
  }

  public async addUserWithActivationCode(user: {
    name: string;
    email: string;
    mobile: string;
    role: 'admin' | 'user';
    allowedGroupIds?: string[];
  }): Promise<{ user: User; activationCode: string }> {
    // Check duplicate mobile
    const dup = this.checkDuplicateMobile(user.mobile);
    if (dup.isDuplicate) {
      throw new Error(`Mobile number (${user.mobile}) is already registered to user "${dup.existingUser?.name}". Each user must have a unique mobile number.`);
    }

    const assignedGroups = user.allowedGroupIds && user.allowedGroupIds.length > 0
      ? user.allowedGroupIds
      : [this.getActiveGroupId()];

    try {
      const res = await fetch('/api/auth/add-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...user, allowedGroupIds: assignedGroups }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || errData.message || 'Server rejected user creation.');
      }

      const data = await res.json();
      if (data.success && data.user) {
        this.removeDeletedUserId(data.user.id);
        const users = this.getUsers().filter((u) => u.id !== data.user.id);
        users.push(data.user);
        this.setSecureItem(STORAGE_KEYS.USERS, users);
        this.addMemberToGroup(assignedGroups[0], data.user);
        this.broadcast({ type: 'USERS_UPDATED', payload: users });
        return { user: data.user, activationCode: data.activationCode };
      }
    } catch (e: any) {
      // Re-throw validation or duplicate errors immediately!
      throw e;
    }

    throw new Error('Could not create user on server.');
  }

  // ==========================================
  // Defunction / Remote Kill-Switch Services
  // ==========================================
  public isDefunctioned(): boolean {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.DEFUNCTION_STATE);
      if (!data) return false;
      const state: DefunctionState = JSON.parse(data);
      return state.isDefunctioned === true;
    } catch {
      return false;
    }
  }

  public getDefunctionState(): DefunctionState {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.DEFUNCTION_STATE);
      return data ? JSON.parse(data) : { isDefunctioned: false };
    } catch {
      return { isDefunctioned: false };
    }
  }

  public triggerDefunction(adminUser: User, reason?: string): void {
    const state: DefunctionState = {
      isDefunctioned: true,
      defunctionedAt: new Date().toISOString(),
      defunctionedBy: adminUser.name,
      reason: reason || 'Application permanently deleted & defunctioned by Administrator.',
    };

    localStorage.setItem(STORAGE_KEYS.DEFUNCTION_STATE, JSON.stringify(state));

    this.addAuditLog({
      groupId: this.getActiveGroupId(),
      action: 'DEFUNCTION_TRIGGERED',
      performedBy: { id: adminUser.id, name: adminUser.name, role: adminUser.role },
      summary: `REMOTE KILL-SWITCH ACTIVATED: Application defunctioned by ${adminUser.name}. All device sessions terminated.`,
    });

    this.broadcast({ type: 'DEFUNCTION_TRIGGERED', payload: state });

    try {
      fetch('/api/system/defunction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(state),
      });
    } catch (e) {
      // offline
    }
  }

  // --- Backup & Restore ---
  public exportFullBackup(): string {
    const backup = {
      version: '3.0',
      exportedAt: new Date().toISOString(),
      exportedBy: this.getCurrentUser(),
      groups: this.getGroups(),
      transactions: this.getAllTransactionsRaw(),
      auditLogs: this.getAuditLogs(),
      users: this.getUsers(),
      parties: this.getAllPartiesRaw(),
      referenceNotes: this.getAllReferenceNotesRaw(),
      tallySessions: this.getAllTallySessionsRaw(),
      scratchpad: this.getQuickScratchpad(),
      signupRequests: this.getPendingSignups(),
      defunctionState: this.getDefunctionState(),
    };
    return JSON.stringify(backup, null, 2);
  }

  public restoreFromBackup(jsonString: string): { success: boolean; message: string } {
    try {
      const data = JSON.parse(jsonString);
      if (!data.groups || !data.transactions) {
        return { success: false, message: 'Invalid backup file schema: missing groups or transactions.' };
      }

      localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(data.groups));
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(data.transactions));
      if (data.users) localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(data.users));
      if (data.auditLogs) localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(data.auditLogs));
      if (data.parties) localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(data.parties));
      if (data.referenceNotes) localStorage.setItem(STORAGE_KEYS.REFERENCE_NOTES, JSON.stringify(data.referenceNotes));
      if (data.tallySessions) localStorage.setItem(STORAGE_KEYS.TALLY_SESSIONS, JSON.stringify(data.tallySessions));
      if (data.scratchpad) localStorage.setItem(STORAGE_KEYS.QUICK_SCRATCHPAD, data.scratchpad);
      if (data.defunctionState) localStorage.setItem(STORAGE_KEYS.DEFUNCTION_STATE, JSON.stringify(data.defunctionState));

      const currentUser = this.getCurrentUser();
      this.addAuditLog({
        groupId: this.getActiveGroupId(),
        action: 'RESTORE',
        performedBy: { id: currentUser.id, name: currentUser.name, role: currentUser.role },
        summary: `Restored ledger database from backup file (${data.transactions.length} transactions, ${data.parties?.length || 0} parties, ${data.groups.length} groups)`,
      });

      this.broadcast({ type: 'DATABASE_RESTORED' });
      return { success: true, message: `Successfully restored ${data.transactions.length} transactions, ${data.parties?.length || 0} parties, ${data.groups.length} groups, and ${data.referenceNotes?.length || 0} reference notes.` };
    } catch (e: any) {
      return { success: false, message: `Error parsing backup JSON: ${e.message}` };
    }
  }

  public resetToSampleData(): void {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(DEFAULT_USERS));
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(DEFAULT_USERS[0]));
    localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(DEFAULT_GROUPS));
    localStorage.setItem(STORAGE_KEYS.CURRENT_GROUP_ID, DEFAULT_GROUPS[0].id);
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(DEFAULT_TRANSACTIONS));
    localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(DEFAULT_AUDIT_LOGS));
    localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(DEFAULT_PARTIES));
    localStorage.setItem(STORAGE_KEYS.REFERENCE_NOTES, JSON.stringify(DEFAULT_REFERENCE_NOTES));
    localStorage.setItem(STORAGE_KEYS.TALLY_SESSIONS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.SIGNUP_REQUESTS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.DEFUNCTION_STATE, JSON.stringify({ isDefunctioned: false }));
    localStorage.removeItem(STORAGE_KEYS.QUICK_SCRATCHPAD);
    this.broadcast({ type: 'DATA_RESET' });
  }

  public formatTypeLabel(type: Transaction['type']): string {
    switch (type) {
      case 'RECEIVED_FROM':
        return 'Received from';
      case 'RECEIVABLE_FROM':
        return 'Receivable from';
      case 'PAID_TO':
        return 'Paid to';
      case 'PAYABLE_TO':
        return 'Payable to';
      default:
        return type;
    }
  }
}

export const storageService = new StorageService();
