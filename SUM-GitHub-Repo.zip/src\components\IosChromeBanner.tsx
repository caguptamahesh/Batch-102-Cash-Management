import React, { useState, useEffect } from 'react';
import { ExternalLink, X, Smartphone, Mic } from 'lucide-react';
import { isIosSafari, openInGoogleChrome } from '../utils/iosChromeHelper';

export const IosChromeBanner: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Check if running on iOS Safari and user hasn't dismissed it in this session
    if (isIosSafari()) {
      const dismissed = sessionStorage.getItem('sum_dismiss_ios_chrome_banner');
      if (!dismissed) {
        setIsVisible(true);
      }
    }
  }, []);

  if (!isVisible) return null;

  const handleOpenChrome = () => {
    openInGoogleChrome();
  };

  const handleDismiss = () => {
    setIsVisible(false);
    sessionStorage.setItem('sum_dismiss_ios_chrome_banner', 'true');
  };

  return (
    <div className="bg-gradient-to-r from-sky-700 via-blue-700 to-indigo-800 text-white px-4 py-2.5 shadow-md flex items-center justify-between text-xs border-b border-sky-400/30 z-50 sticky top-0">
      <div className="flex items-center gap-2 overflow-hidden mr-2">
        <div className="w-6 h-6 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
          <Mic className="w-3.5 h-3.5 text-amber-300" />
        </div>
        <div className="truncate">
          <span className="font-bold text-amber-300">iOS Safari detected: </span>
          <span className="text-sky-100">Voice recognition requires Google Chrome on iPhone/iPad.</span>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={handleOpenChrome}
          className="px-3 py-1 bg-amber-400 hover:bg-amber-300 text-slate-900 rounded-lg font-bold text-[11px] shadow-sm flex items-center gap-1 transition-all"
        >
          <span>Open in Chrome</span>
          <ExternalLink className="w-3 h-3" />
        </button>
        <button
          onClick={handleDismiss}
          className="p-1 text-sky-200 hover:text-white rounded-md hover:bg-white/10"
          title="Continue in Safari"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
