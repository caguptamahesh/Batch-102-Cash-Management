/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  AuditLogEntry,
  Group,
  PartySummary,
  Transaction,
  TransactionType,
  User,
  LedgerDashboardMetrics,
  ReferenceNote,
} from './types/ledger';
import { storageService } from './services/storageService';
import { Header, LedgerTab } from './components/Header';
import { DashboardMetrics } from './components/DashboardMetrics';
import { TransactionTable } from './components/TransactionTable';
import { PartyLedgerView } from './components/PartyLedgerView';
import { AuditTrailView } from './components/AuditTrailView';
import { ReportsBackupView } from './components/ReportsBackupView';
import { CashNotesView } from './components/CashNotesView';
import { QuickNotesDrawer } from './components/QuickNotesDrawer';
import { CashDenominationsView } from './components/CashDenominationsView';
import { MobileConnectModal } from './components/MobileConnectModal';
import { TransactionModal } from './components/TransactionModal';
import { UserAuthModal } from './components/UserAuthModal';
import { GroupManagerModal } from './components/GroupManagerModal';
import { PrintReportModal } from './components/PrintReportModal';
import { AuditInspectionModal } from './components/AuditInspectionModal';
import { PartyManagerModal } from './components/PartyManagerModal';
import { GoogleDriveSyncModal } from './components/GoogleDriveSyncModal';
import { DefunctionLockScreen } from './components/DefunctionLockScreen';
import { DeviceActivationLockScreen } from './components/DeviceActivationLockScreen';
import { NotificationToast, ToastNotification } from './components/NotificationToast';
import { IosChromeBanner } from './components/IosChromeBanner';
import { isIosSafari, openInGoogleChrome } from './utils/iosChromeHelper';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Plus,
  Users,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  Layers,
  Building,
  LayoutDashboard,
  Receipt,
  BookOpen,
  Calculator,
  Smartphone,
  StickyNote,
  Mic,
} from 'lucide-react';

export default function App() {
  // Core State
  const [groups, setGroups] = useState<Group[]>([]);
  const [activeGroupId, setActiveGroupId] = useState<string>('');
  const [currentUser, setCurrentUser] = useState<User>(storageService.getCurrentUser());
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [partySummaries, setPartySummaries] = useState<PartySummary[]>([]);
  const [referenceNotes, setReferenceNotes] = useState<ReferenceNote[]>([]);
  const [metrics, setMetrics] = useState<LedgerDashboardMetrics>({
    totalCashReceived: 0,
    totalReceivable: 0,
    totalCashPaid: 0,
    totalPayable: 0,
    netCashBalance: 0,
    netOverallPosition: 0,
    activePartiesCount: 0,
    totalTransactionsCount: 0,
  });
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);

  // Navigation & Drilldown State
  const [activeTab, setActiveTab] = useState<LedgerTab>('dashboard');
  const [selectedPartyName, setSelectedPartyName] = useState<string | null>(null);

  // Modals & Panels
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [transactionModalAutoVoice, setTransactionModalAutoVoice] = useState(false);
  const [transactionModalFlow, setTransactionModalFlow] = useState<'INCOME' | 'EXPENDITURE'>('INCOME');
  const [transactionModalInitialType, setTransactionModalInitialType] = useState<TransactionType | undefined>();
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [isGroupModalOpen, setIsGroupModalOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [isMobileConnectOpen, setIsMobileConnectOpen] = useState(false);
  const [isQuickNotesOpen, setIsQuickNotesOpen] = useState(false);
  const [isPartyModalOpen, setIsPartyModalOpen] = useState(false);
  const [isDriveModalOpen, setIsDriveModalOpen] = useState(false);
  const [defunctionState, setDefunctionState] = useState(storageService.getDefunctionState());
  const [isDeviceActivated, setIsDeviceActivated] = useState<boolean>(storageService.isDeviceActivated());
  const [inspectingTransaction, setInspectingTransaction] = useState<Transaction | null>(null);

  // Real-time synchronization & notifications
  const [syncTimestamp, setSyncTimestamp] = useState<string>('Just now');
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [notifications, setNotifications] = useState<ToastNotification[]>([]);

  const addNotification = useCallback((title: string, message: string) => {
    const newNotice: ToastNotification = {
      id: `toast_${Date.now()}_${Math.random()}`,
      title,
      message,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setNotifications((prev) => [newNotice, ...prev.slice(0, 4)]);

    // Auto dismiss after 5s
    setTimeout(() => {
      setNotifications((prev) => prev.filter((n) => n.id !== newNotice.id));
    }, 5000);
  }, []);

  // Reload state from local/sync storage
  const reloadData = useCallback(() => {
    const allGroups = storageService.getGroups();
    const activeId = storageService.getActiveGroupId();
    const allUsers = storageService.getUsers();
    const activeUser = storageService.getCurrentUser();
    const txs = storageService.getTransactions(activeId);
    const pSummaries = storageService.getPartySummaries(activeId);
    const currentMetrics = storageService.getDashboardMetrics(activeId);
    const logs = storageService.getAuditLogs(activeId);
    const notes = storageService.getReferenceNotes(activeId);

    setGroups(allGroups);
    setActiveGroupId(activeId);
    setUsers(allUsers);
    setCurrentUser(activeUser);
    setTransactions(txs);
    setPartySummaries(pSummaries);
    setMetrics(currentMetrics);
    setAuditLogs(logs);
    setReferenceNotes(notes);
    setSyncTimestamp(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
  }, []);

  // Initial load and storage subscriptions
  useEffect(() => {
    reloadData();

    // Listen for real-time BroadcastChannel sync across tabs and local events
    const unsubscribe = storageService.subscribe((event) => {
      reloadData();
      const activeUser = storageService.getCurrentUser();

      if (event.type === 'TRANSACTION_CREATED') {
        const payload = event.payload;
        const actorId = payload?.actor?.id || payload?.createdBy?.id;
        const actorName = payload?.actor?.name || payload?.createdBy?.name || 'A team member';
        // Notify admin and other users (not the one who made the entry)
        if (actorId !== activeUser.id) {
          addNotification(
            `New Transaction by ${actorName}`,
            `${storageService.formatTypeLabel(payload.type)}: ${payload.partyName} (₹${payload.amount?.toLocaleString()})`
          );
        }
      } else if (event.type === 'TRANSACTION_UPDATED') {
        const payload = event.payload;
        const actorId = payload?.actor?.id || payload?.updatedBy?.id;
        const actorName = payload?.actor?.name || payload?.updatedBy?.name || 'A team member';
        // Notify admin and other users (not the one who modified the entry)
        if (actorId !== activeUser.id) {
          addNotification(
            `Transaction Modified by ${actorName}`,
            `Updated entry #${payload.receiptNumber} (${payload.partyName})`
          );
        }
      } else if (event.type === 'TRANSACTION_DELETED') {
        const payload = event.payload;
        const actorId = payload?.actor?.id;
        const actorName = payload?.actor?.name || 'A team member';
        // Notify admin and other users (not the one who deleted the entry)
        if (actorId !== activeUser.id) {
          addNotification(
            `Transaction Deleted by ${actorName}`,
            `Entry #${payload.receiptNumber || ''} (${payload.partyName || ''}) was deleted from ledger.`
          );
        }
      } else if (event.type === 'ALL_DATA_CLEARED') {
        reloadData();
        addNotification('Ledger Reset', 'All ledger data has been cleared by Admin MG.');
      } else if (event.type === 'NOTE_CREATED') {
        const note = event.payload as ReferenceNote;
        addNotification('Reference Memo Added', `Saved note: "${note.title}"`);
      } else if (event.type === 'NOTE_UPDATED') {
        const note = event.payload as ReferenceNote;
        addNotification('Reference Memo Updated', `Updated: "${note.title}"`);
      } else if (event.type === 'TALLY_RECORDED') {
        addNotification('Cash Tally Recorded', 'Till reconciliation count stored successfully.');
      } else if (event.type === 'DATABASE_RESTORED') {
        addNotification('Database Restored', 'The ledger has been re-synchronized from backup.');
      } else if (event.type === 'DEFUNCTION_TRIGGERED') {
        const state = event.payload || storageService.getDefunctionState();
        setDefunctionState(state);
      } else if (event.type === 'DEVICE_ACTIVATED') {
        setIsDeviceActivated(true);
        reloadData();
      } else if (event.type === 'DEVICE_LOCKED') {
        setIsDeviceActivated(false);
      } else if (event.type === 'GDRIVE_SYNC_COMPLETED') {
        addNotification('Google Drive Synced', 'Encrypted cloud backup updated for ai.caguptamahesh@gmail.com');
      } else if (event.type === 'SIGNUP_REQUESTED') {
        if (activeUser.role === 'admin') {
          addNotification('New User Authorization Request', `${event.payload?.name} requested access via Mr. MG OTP.`);
        }
      }
    });

    // Check central server for defunction state
    fetch('/api/system/defunction')
      .then((res) => res.json())
      .then((data) => {
        if (data.isDefunctioned) {
          setDefunctionState(data);
        }
      })
      .catch(() => {});

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      unsubscribe();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [reloadData, addNotification]);

  // Requirement 7: Auto-refresh ledger state from server whenever app becomes visible or focused
  useEffect(() => {
    const handleAutoRefresh = async () => {
      try {
        await storageService.fetchServerState();
        reloadData();
      } catch {}
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        handleAutoRefresh();
      }
    };

    window.addEventListener('focus', handleAutoRefresh);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('pageshow', handleAutoRefresh);

    return () => {
      window.removeEventListener('focus', handleAutoRefresh);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('pageshow', handleAutoRefresh);
    };
  }, [reloadData]);

  // Current Group Object
  const currentGroup = groups.find((g) => g.id === activeGroupId) || groups[0] || {
    id: 'grp_default',
    name: 'Main Business Cash Counter',
    purpose: 'Daily operations & cash book',
    currency: '₹',
    createdAt: new Date().toISOString(),
    createdBy: { id: 'usr_admin', name: 'MG', role: 'admin' as const },
    members: [],
  };

  // Requirement 10: Admin Clear All data across all devices and database
  const handleClearAllData = async () => {
    await storageService.clearAllData(currentUser);
    reloadData();
    addNotification('Ledger Reset', 'All ledger data wiped from all devices and database by Admin MG.');
  };

  // Quick Action Handlers
  const handleOpenIncomeModal = (initialParty?: string) => {
    setEditingTransaction(null);
    setTransactionModalFlow('INCOME');
    setTransactionModalInitialType('RECEIVED_FROM');
    setTransactionModalAutoVoice(false);
    setIsTransactionModalOpen(true);
  };

  const handleOpenExpenseModal = (initialParty?: string) => {
    setEditingTransaction(null);
    setTransactionModalFlow('EXPENDITURE');
    setTransactionModalInitialType('PAID_TO');
    setTransactionModalAutoVoice(false);
    setIsTransactionModalOpen(true);
  };

  // Requirement 5: Open transaction modal and trigger voice recognition immediately
  const handleOpenAddByVoice = () => {
    // Requirement 1: If on iOS Safari, attempt to open in Google Chrome if installed
    if (isIosSafari()) {
      openInGoogleChrome();
    }
    setEditingTransaction(null);
    setTransactionModalFlow('INCOME');
    setTransactionModalInitialType('RECEIVED_FROM');
    setTransactionModalAutoVoice(true);
    setIsTransactionModalOpen(true);
  };

  const handleRecordForParty = (partyName: string, flow: 'INCOME' | 'EXPENDITURE') => {
    setEditingTransaction(null);
    setTransactionModalFlow(flow);
    setTransactionModalInitialType(flow === 'INCOME' ? 'RECEIVED_FROM' : 'PAID_TO');
    setIsTransactionModalOpen(true);
  };

  const handleSaveTransaction = (data: {
    type: TransactionType;
    amount: number;
    partyName: string;
    date: string;
    narration: string;
  }) => {
    if (editingTransaction) {
      storageService.updateTransaction(editingTransaction.id, data);
    } else {
      storageService.createTransaction({
        groupId: activeGroupId,
        ...data,
      });
    }
    reloadData();
  };

  const handleDeleteTransaction = (id: string) => {
    storageService.deleteTransaction(id);
    reloadData();
  };

  const handleEditTransaction = (tx: Transaction) => {
    setEditingTransaction(tx);
    setTransactionModalFlow(
      tx.type === 'RECEIVED_FROM' || tx.type === 'RECEIVABLE_FROM' ? 'INCOME' : 'EXPENDITURE'
    );
    setTransactionModalInitialType(tx.type);
    setIsTransactionModalOpen(true);
  };

  const handleSelectGroup = (id: string) => {
    storageService.setActiveGroupId(id);
    setActiveGroupId(id);
    setSelectedPartyName(null);
    reloadData();
  };

  const handleCreateGroup = (name: string, purpose: string, currency: string) => {
    const newGrp = storageService.createGroup(name, purpose, currency);
    reloadData();
    addNotification('Group Created', `New business group "${newGrp.name}" is now active.`);
  };

  const handleSwitchUser = (user: User) => {
    storageService.setCurrentUser(user);
    setCurrentUser(user);
    addNotification('User Switched', `Active session changed to ${user.name} (${user.role}).`);
  };

  const handleAddUser = (user: Omit<User, 'id'>) => {
    const created = storageService.addUser(user);
    storageService.addMemberToGroup(activeGroupId, created);
    reloadData();
    addNotification('Team Member Added', `${created.name} added with ${created.role} role.`);
  };

  const existingParties = storageService.getExistingPartyNames(activeGroupId);

  // If application has been remotely defunctioned by Admin, lock out all devices permanently
  if (defunctionState.isDefunctioned || storageService.isDefunctioned()) {
    return (
      <DefunctionLockScreen
        defunctionedAt={defunctionState.defunctionedAt}
        defunctionedBy={defunctionState.defunctionedBy}
        reason={defunctionState.reason}
      />
    );
  }

  // Password-Protected App Download & Device Activation Gate (6-digit code / Master Admin)
  if (!isDeviceActivated) {
    return (
      <DeviceActivationLockScreen
        onActivated={(activatedUser) => {
          setIsDeviceActivated(true);
          setCurrentUser(activatedUser);
          reloadData();
          addNotification(
            'Ledger Downloaded & Activated',
            `Welcome ${activatedUser.name}! Group cash books loaded.`
          );
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50/70 via-slate-50 to-blue-50/60 text-slate-800 flex flex-col antialiased">
      
      {/* Requirement 1: iOS Safari Google Chrome Redirect Banner */}
      <IosChromeBanner />

      {/* Top Header Navigation */}
      <Header
        currentGroup={currentGroup}
        groups={groups}
        currentUser={currentUser}
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          if (tab !== 'parties') setSelectedPartyName(null);
        }}
        onSelectGroup={handleSelectGroup}
        onOpenCreateGroup={() => setIsGroupModalOpen(true)}
        onOpenUserModal={() => setIsUserModalOpen(true)}
        onOpenIncomeModal={() => handleOpenIncomeModal()}
        onOpenExpenseModal={() => handleOpenExpenseModal()}
        onOpenMobileConnect={() => setIsMobileConnectOpen(true)}
        onOpenQuickNotes={() => setIsQuickNotesOpen(true)}
        onOpenDriveModal={() => setIsDriveModalOpen(true)}
        onLockDevice={() => {
          storageService.lockDevice();
          setIsDeviceActivated(false);
        }}
        notesCount={referenceNotes.length}
        isOnline={isOnline}
        syncTimestamp={syncTimestamp}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-28 md:pb-8 space-y-6">
        
        {/* Tab 1: Dashboard */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            <DashboardMetrics
              metrics={metrics}
              group={currentGroup}
              onOpenIncomeModal={() => handleOpenIncomeModal()}
              onOpenExpenseModal={() => handleOpenExpenseModal()}
              onViewAllTransactions={() => setActiveTab('transactions')}
              onViewParties={() => setActiveTab('parties')}
              isAdmin={currentUser.role === 'admin'}
              onClearAllData={handleClearAllData}
            />

            {/* Split Grid: Recent Journal Activity & Party Balances Preview */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Left 2 Cols: Recent Journal Entries */}
              <div className="lg:col-span-2 bg-white/90 backdrop-blur-sm border border-sky-100 rounded-2xl shadow-xs overflow-hidden">
                <div className="p-4 sm:px-5 border-b border-slate-100 flex items-center justify-between">
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">
                      Recent Cash Transactions
                    </h2>
                    <div className="text-xs text-slate-600">
                      Latest directional entries recorded in {currentGroup.name}
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('transactions')}
                    className="text-xs font-semibold text-sky-700 hover:text-sky-800 hover:underline"
                  >
                    View All Journal Entries →
                  </button>
                </div>

                <div className="divide-y divide-slate-100 text-xs">
                  {transactions.slice(0, 5).map((tx) => {
                    const isInflow = tx.type === 'RECEIVED_FROM' || tx.type === 'RECEIVABLE_FROM';
                    return (
                      <div
                        key={tx.id}
                        className="p-3.5 sm:px-5 flex items-center justify-between hover:bg-sky-50/40 transition-colors"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                            isInflow ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
                          }`}>
                            {isInflow ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-900 truncate">{tx.partyName}</span>
                              <span className={`px-1.5 py-0.2 rounded text-[10px] font-semibold ${
                                tx.type === 'RECEIVED_FROM' ? 'bg-emerald-100 text-emerald-800' :
                                tx.type === 'RECEIVABLE_FROM' ? 'bg-sky-100 text-sky-800' :
                                tx.type === 'PAID_TO' ? 'bg-rose-100 text-rose-800' :
                                'bg-amber-100 text-amber-800'
                              }`}>
                                {storageService.formatTypeLabel(tx.type)}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-600 truncate mt-0.5">
                              {tx.narration || tx.receiptNumber} · {tx.date}
                            </div>
                          </div>
                        </div>

                        <div className="text-right shrink-0 ml-3">
                          <div className={`font-mono font-bold text-sm tabular-nums ${
                            isInflow ? 'text-emerald-700' : 'text-rose-700'
                          }`}>
                            {isInflow ? '+' : '-'}{currentGroup.currency}{tx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                          </div>
                          <div className="text-[10px] text-slate-600">
                            by {tx.createdBy.name}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  {transactions.length === 0 && (
                    <div className="p-8 text-center text-slate-600">
                      No transactions recorded yet in this group.
                    </div>
                  )}
                </div>
              </div>

              {/* Right 1 Col: Key Party Outstanding Balances */}
              <div className="bg-white/90 backdrop-blur-sm border border-sky-100 rounded-2xl shadow-xs overflow-hidden flex flex-col">
                <div className="p-4 sm:px-5 border-b border-slate-100 flex items-center justify-between">
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">
                      Party Balances
                    </h2>
                    <div className="text-xs text-slate-600">
                      Net receivable / payable status
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('parties')}
                    className="text-xs font-semibold text-sky-700 hover:text-sky-800 hover:underline"
                  >
                    View All ({partySummaries.length}) →
                  </button>
                </div>

                <div className="p-4 space-y-3 flex-1 overflow-y-auto max-h-96">
                  {partySummaries.slice(0, 5).map((party) => {
                    const isReceivable = party.netBalance > 0;
                    const isPayable = party.netBalance < 0;
                    const isSettled = party.netBalance === 0;

                    return (
                      <div
                        key={party.partyName}
                        onClick={() => {
                          setSelectedPartyName(party.partyName);
                          setActiveTab('parties');
                        }}
                        className="p-3 bg-slate-50 hover:bg-sky-50 border border-slate-200/80 hover:border-sky-200 rounded-xl transition-all cursor-pointer flex items-center justify-between"
                      >
                        <div className="min-w-0 pr-2">
                          <div className="text-xs font-bold text-slate-900 truncate">
                            {party.partyName}
                          </div>
                          <div className="text-[10px] text-slate-600 mt-0.5">
                            {party.transactionCount} transactions · {party.lastTransactionDate}
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <div className={`text-xs font-mono font-bold tabular-nums ${
                            isReceivable ? 'text-sky-700' : isPayable ? 'text-rose-700' : 'text-slate-600'
                          }`}>
                            {isReceivable && `Receivable: ${currentGroup.currency}${party.netBalance.toLocaleString()}`}
                            {isPayable && `Payable: ${currentGroup.currency}${Math.abs(party.netBalance).toLocaleString()}`}
                            {isSettled && `Settled (₹0)`}
                          </div>
                          <span className="text-[10px] text-sky-600 hover:underline">
                            Statement →
                          </span>
                        </div>
                      </div>
                    );
                  })}
                  {partySummaries.length === 0 && (
                    <div className="text-center py-8 text-xs text-slate-600">
                      No party balances computed yet.
                    </div>
                  )}
                </div>

                <div className="p-3 bg-sky-50/60 border-t border-sky-100 text-center">
                  <button
                    onClick={() => setActiveTab('parties')}
                    className="text-xs font-bold text-sky-800 hover:text-sky-900"
                  >
                    Manage All Party Ledgers & Statements
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Tab 2: Full Transactions Journal */}
        {activeTab === 'transactions' && (
          <TransactionTable
            transactions={transactions}
            group={currentGroup}
            currentUser={currentUser}
            onEdit={handleEditTransaction}
            onDelete={handleDeleteTransaction}
            onViewAudit={(tx) => setInspectingTransaction(tx)}
            onSelectParty={(partyName) => {
              setSelectedPartyName(partyName);
              setActiveTab('parties');
            }}
            onOpenIncomeModal={() => handleOpenIncomeModal()}
            onOpenExpenseModal={() => handleOpenExpenseModal()}
          />
        )}

        {/* Tab 3: Party Ledgers & Running Statements */}
        {activeTab === 'parties' && (
          <PartyLedgerView
            partySummaries={partySummaries}
            transactions={transactions}
            group={currentGroup}
            currentUser={currentUser}
            selectedPartyName={selectedPartyName}
            onSelectParty={(name) => setSelectedPartyName(name)}
            onRecordForParty={handleRecordForParty}
            onOpenPartyModal={() => setIsPartyModalOpen(true)}
          />
        )}

        {/* Tab 4: Cash Denominations Counter & Till Reconciliation */}
        {activeTab === 'tally' && (
          <CashDenominationsView
            group={currentGroup}
            currentUser={currentUser}
            systemCashBalance={metrics.netCashBalance}
            onRefresh={reloadData}
          />
        )}

        {/* Tab 5: Text Panel & Reference Notes */}
        {activeTab === 'notes' && (
          <CashNotesView
            notes={referenceNotes}
            group={currentGroup}
            currentUser={currentUser}
            onRefresh={reloadData}
            existingParties={existingParties}
          />
        )}

        {/* Tab 6: Audit Trail Log */}
        {activeTab === 'audit' && (
          <AuditTrailView
            auditLogs={auditLogs}
            group={currentGroup}
            currentUser={currentUser}
          />
        )}

        {/* Tab 7: Reports, Excel & Backup */}
        {activeTab === 'reports' && (
          <ReportsBackupView
            group={currentGroup}
            transactions={transactions}
            partySummaries={partySummaries}
            currentUser={currentUser}
            onRefresh={reloadData}
            onOpenPrintModal={() => setIsPrintModalOpen(true)}
            onOpenDriveModal={() => setIsDriveModalOpen(true)}
            onOpenAuthModal={() => setIsUserModalOpen(true)}
          />
        )}

      </main>

      {/* Requirement 12: Copyright and Version Footer */}
      <footer className="w-full py-6 pb-24 md:pb-6 text-center text-xs text-slate-500 font-mono border-t border-sky-100 bg-white/40 backdrop-blur-xs">
        SUM • Version 2026.v1 • © MG
      </footer>

      {/* Requirement 5: Floating "Add by Voice" Action Button (Neatly elevated above mobile bottom nav) */}
      <div className="fixed bottom-20 right-4 sm:bottom-24 sm:right-6 md:bottom-8 md:right-8 z-40">
        <button
          onClick={handleOpenAddByVoice}
          className="flex items-center gap-2.5 px-4 sm:px-5 py-3 bg-gradient-to-r from-sky-600 via-blue-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm rounded-full shadow-xl shadow-sky-600/35 active:scale-95 transition-all cursor-pointer border-2 border-white/40"
          title="1-Click Voice Transaction Recording (English & Hindi) - Speak 'Stop' or 'Over' when finished"
        >
          <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center animate-pulse">
            <Mic className="w-4 h-4 text-white" />
          </div>
          <span className="tracking-wide">Add by Voice</span>
        </button>
      </div>

      {/* Mobile Fixed Bottom Navigation Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-sky-100 flex items-center justify-around py-2 px-1 shadow-lg">
        <button
          onClick={() => {
            setActiveTab('dashboard');
            setSelectedPartyName(null);
          }}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            activeTab === 'dashboard' ? 'text-sky-700 font-bold' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Overview</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('transactions');
            setSelectedPartyName(null);
          }}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            activeTab === 'transactions' ? 'text-sky-700 font-bold' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Journal</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('tally');
            setSelectedPartyName(null);
          }}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            activeTab === 'tally' ? 'text-emerald-700 font-bold' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <Calculator className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Tally</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('notes');
            setSelectedPartyName(null);
          }}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors relative ${
            activeTab === 'notes' ? 'text-amber-800 font-bold' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Notes</span>
          {referenceNotes.length > 0 && (
            <span className="absolute top-1 right-4 w-2 h-2 rounded-full bg-amber-500" />
          )}
        </button>

        <button
          onClick={() => {
            setActiveTab('parties');
          }}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            activeTab === 'parties' ? 'text-sky-700 font-bold' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <Users className="w-4 h-4" />
          <span className="text-[10px] mt-0.5">Parties</span>
        </button>
      </nav>

      {/* Modal: Transaction Entry & Edit */}
      <TransactionModal
        isOpen={isTransactionModalOpen}
        onClose={() => {
          setIsTransactionModalOpen(false);
          setEditingTransaction(null);
          setTransactionModalAutoVoice(false);
        }}
        onSave={handleSaveTransaction}
        initialFlow={transactionModalFlow}
        initialType={transactionModalInitialType}
        existingTransaction={editingTransaction}
        existingParties={existingParties}
        parties={storageService.getParties(activeGroupId)}
        partySummaries={partySummaries}
        currentUser={currentUser}
        group={currentGroup}
        onOpenPartyModal={() => setIsPartyModalOpen(true)}
        autoStartVoice={transactionModalAutoVoice}
      />

      {/* Modal: User Management & Role Switcher */}
      <UserAuthModal
        isOpen={isUserModalOpen}
        onClose={() => setIsUserModalOpen(false)}
        users={users}
        currentUser={currentUser}
        groups={groups}
        onSwitchUser={handleSwitchUser}
        onAddUser={handleAddUser}
        onRefresh={reloadData}
        onLockDevice={() => {
          storageService.lockDevice();
          setIsDeviceActivated(false);
        }}
      />

      {/* Modal: Party Directory & Contact Tool */}
      <PartyManagerModal
        isOpen={isPartyModalOpen}
        onClose={() => setIsPartyModalOpen(false)}
        onSuccess={(party) => {
          reloadData();
          addNotification('Party Registered', `Party "${party.name}" added to directory.`);
        }}
        group={currentGroup}
        currentUser={currentUser}
      />

      {/* Modal: Google Drive Multi-User Cloud Sync (ai.caguptamahesh@gmail.com) */}
      <GoogleDriveSyncModal
        isOpen={isDriveModalOpen}
        onClose={() => setIsDriveModalOpen(false)}
        group={currentGroup}
        currentUser={currentUser}
      />

      {/* Modal: Group Manager (Create / Switch Business Groups) */}
      <GroupManagerModal
        isOpen={isGroupModalOpen}
        onClose={() => setIsGroupModalOpen(false)}
        groups={groups}
        activeGroupId={activeGroupId}
        onSelectGroup={handleSelectGroup}
        onCreateGroup={handleCreateGroup}
        currentUser={currentUser}
      />

      {/* Modal: Print / PDF Report Preview */}
      <PrintReportModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        group={currentGroup}
        transactions={transactions}
        partySummaries={partySummaries}
        currentUser={currentUser}
      />

      {/* Modal: Transaction Audit Inspection */}
      <AuditInspectionModal
        isOpen={!!inspectingTransaction}
        onClose={() => setInspectingTransaction(null)}
        transaction={inspectingTransaction}
        auditLogs={auditLogs}
        group={currentGroup}
      />

      {/* Modal: Connect Mobile Device & Local Server QR */}
      <MobileConnectModal
        isOpen={isMobileConnectOpen}
        onClose={() => setIsMobileConnectOpen(false)}
      />

      {/* Slide-over Drawer: Quick Text Panel / Scratchpad */}
      <QuickNotesDrawer
        isOpen={isQuickNotesOpen}
        onClose={() => setIsQuickNotesOpen(false)}
        notes={referenceNotes}
        group={currentGroup}
        currentUser={currentUser}
        onNavigateToNotesTab={() => setActiveTab('notes')}
        onRefresh={reloadData}
      />

      {/* Real-time Toast Notifications */}
      <NotificationToast
        notifications={notifications}
        onDismiss={(id) => setNotifications((prev) => prev.filter((n) => n.id !== id))}
      />

    </div>
  );
}
