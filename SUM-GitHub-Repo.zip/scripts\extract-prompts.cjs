const fs = require('fs');
const readline = require('readline');
const path = require('path');

async function extractPrompts() {
  const transcriptPath = 'C:\\Users\\91941\\.gemini\\antigravity\\brain\\47fd3e0e-c7fb-4b37-9c15-17ca382b6b48\\.system_generated\\logs\\transcript.jsonl';
  const fileStream = fs.createReadStream(transcriptPath);
  const rl = readline.createInterface({ input: fileStream, crlfDelay: Infinity });

  let prompts = [];
  for await (const line of rl) {
    if (!line.trim()) continue;
    try {
      const obj = JSON.parse(line);
      // Look for user inputs
      if (obj.source === 'USER_EXPLICIT' && obj.type === 'USER_INPUT') {
        prompts.push({
          step_index: obj.step_index,
          created_at: obj.created_at,
          content: obj.content
        });
      }
    } catch (e) {}
  }

  console.log(`Total user prompts found: ${prompts.length}`);
  fs.writeFileSync('scripts/extracted-prompts.json', JSON.stringify(prompts, null, 2));
}

extractPrompts().catch(console.error);
