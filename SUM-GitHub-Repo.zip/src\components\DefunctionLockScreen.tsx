import React from 'react';
import { ShieldAlert, Lock, AlertOctagon, Ban, XCircle } from 'lucide-react';

interface DefunctionLockScreenProps {
  defunctionedAt?: string;
  defunctionedBy?: string;
  reason?: string;
}

export const DefunctionLockScreen: React.FC<DefunctionLockScreenProps> = ({
  defunctionedAt,
  defunctionedBy = 'Mr. MG (Admin)',
  reason = 'Application permanently decommissioned and defunctioned by Administrator.',
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white flex flex-col items-center justify-center p-6 text-center select-none">
      <div className="max-w-md w-full bg-slate-900 border border-rose-900/60 rounded-3xl p-8 shadow-2xl space-y-6 relative overflow-hidden">
        
        {/* Glow backdrop */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-rose-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-rose-600/20 rounded-full blur-3xl pointer-events-none" />

        <div className="w-20 h-20 mx-auto rounded-3xl bg-rose-950/80 border border-rose-600/40 text-rose-500 flex items-center justify-center shadow-lg shadow-rose-950/50">
          <Ban className="w-10 h-10 animate-pulse" />
        </div>

        <div className="space-y-2">
          <span className="px-3 py-1 rounded-full text-[11px] font-mono font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30 uppercase tracking-widest">
            Remote Kill-Switch Activated
          </span>
          <h1 className="text-2xl font-black tracking-tight text-white pt-1">
            Application Defunctioned
          </h1>
          <p className="text-xs text-rose-300 font-medium leading-relaxed">
            {reason}
          </p>
        </div>

        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 text-left text-xs space-y-2 font-mono">
          <div className="flex items-center justify-between text-slate-400">
            <span>Enforced By:</span>
            <span className="text-rose-400 font-bold">{defunctionedBy}</span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span>Decommission Time:</span>
            <span className="text-slate-200">{defunctionedAt || new Date().toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span>Terminal Lock:</span>
            <span className="text-rose-400 font-bold">ALL DEVICES DEACTIVATED</span>
          </div>
        </div>

        <div className="p-3 bg-rose-950/30 border border-rose-800/40 rounded-xl text-[11px] text-slate-400 leading-normal">
          This system instance has been remotely defunctioned and locked across all connected desktop and mobile sessions. Local encrypted caches have been purged. Contact administrator Mr. MG for authorization queries.
        </div>

        <div className="pt-2 text-center text-[10px] text-slate-500 font-mono">
          SUM • Version 2026.v1 • © MG
        </div>

      </div>
    </div>
  );
};
