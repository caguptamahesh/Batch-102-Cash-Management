import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  X,
  ArrowDownLeft,
  ArrowUpRight,
  Calendar,
  User,
  FileText,
  DollarSign,
  ShieldAlert,
  Clock,
  Sparkles,
  Check,
  Plus,
  ChevronDown,
  Building,
  Phone,
  Mic,
  MicOff,
  Volume2,
  Languages,
} from 'lucide-react';
import { Group, Transaction, TransactionType, User as UserType, Party, PartySummary } from '../types/ledger';
import { useSpeechRecognition, SpeechLanguage } from '../hooks/useSpeechRecognition';
import { VoiceService, ParsedVoiceTransaction } from '../services/voiceService';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: {
    type: TransactionType;
    amount: number;
    partyName: string;
    date: string;
    narration: string;
  }) => void;
  initialType?: TransactionType;
  initialFlow?: 'INCOME' | 'EXPENDITURE';
  existingTransaction?: Transaction | null;
  existingParties: string[];
  parties?: Party[];
  partySummaries?: PartySummary[];
  currentUser: UserType;
  group: Group;
  onOpenPartyModal?: () => void;
  autoStartVoice?: boolean;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialType,
  initialFlow = 'INCOME',
  existingTransaction,
  existingParties,
  parties = [],
  partySummaries = [],
  currentUser,
  group,
  onOpenPartyModal,
  autoStartVoice = false,
}) => {
  const [flow, setFlow] = useState<'INCOME' | 'EXPENDITURE'>(initialFlow);
  const [type, setType] = useState<TransactionType>(
    initialType || (initialFlow === 'INCOME' ? 'RECEIVED_FROM' : 'PAID_TO')
  );
  // Amount unit: RUPEES (auto-converts to Lacs) or LACS (entered directly)
  const [amountUnit, setAmountUnit] = useState<'RUPEES' | 'LACS'>('RUPEES');
  const [amount, setAmount] = useState<string>('');
  const [partyName, setPartyName] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [narration, setNarration] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [partyFilter, setPartyFilter] = useState<'ALL' | 'RECEIVABLE' | 'PAYABLE'>('ALL');
  const [isCustomParty, setIsCustomParty] = useState(false);

  useEffect(() => {
    if (existingTransaction) {
      setType(existingTransaction.type);
      setFlow(
        existingTransaction.type === 'RECEIVED_FROM' || existingTransaction.type === 'RECEIVABLE_FROM'
          ? 'INCOME'
          : 'EXPENDITURE'
      );
      // Existing transaction amount is recorded in Lacs
      setAmountUnit('LACS');
      setAmount(existingTransaction.amount.toString());
      setPartyName(existingTransaction.partyName);
      setDate(existingTransaction.date);
      setNarration(existingTransaction.narration || '');
    } else {
      const defaultType: TransactionType = initialFlow === 'INCOME' ? 'RECEIVED_FROM' : 'PAID_TO';
      setFlow(initialFlow);
      setType(initialType || defaultType);
      setAmountUnit('RUPEES');
      setAmount('');
      setPartyName('');
      setDate(new Date().toISOString().slice(0, 10));
      setNarration('');
    }
    setError('');
  }, [existingTransaction, initialFlow, initialType, isOpen]);

  // Find party metadata for selected party
  const selectedPartyObj = useMemo(() => {
    if (!partyName.trim()) return null;
    return (parties || []).find((p) => p.name.trim().toLowerCase() === partyName.trim().toLowerCase()) || null;
  }, [partyName, parties]);

  const selectedPartySummary = useMemo(() => {
    if (!partyName.trim()) return null;
    return (partySummaries || []).find((s) => s.partyName.trim().toLowerCase() === partyName.trim().toLowerCase()) || null;
  }, [partyName, partySummaries]);

  // Filter parties by selected filter tab (ALL, RECEIVABLE, PAYABLE)
  const filteredDropdownParties = useMemo(() => {
    const all = parties || [];
    if (partyFilter === 'ALL') return all;

    return all.filter((p) => {
      const summary = (partySummaries || []).find((s) => s.partyName.trim().toLowerCase() === p.name.trim().toLowerCase());
      if (partyFilter === 'RECEIVABLE') {
        return (summary && summary.netBalance > 0) || p.openingBalanceType === 'RECEIVABLE';
      }
      if (partyFilter === 'PAYABLE') {
        return (summary && summary.netBalance < 0) || p.openingBalanceType === 'PAYABLE';
      }
      return true;
    });
  }, [parties, partySummaries, partyFilter]);

  const currency = group?.currency || '₹ in Lacs';

  // Speech Recognition integration for transaction recording/addition (English & Hindi)
  const [activeVoiceTarget, setActiveVoiceTarget] = useState<'all' | 'amount' | 'narration' | null>(null);
  const [voiceSuccessMsg, setVoiceSuccessMsg] = useState<string>('');

  const knownPartyNames = useMemo(() => {
    const list = (parties || []).map((p) => p.name);
    (existingParties || []).forEach((name) => {
      if (name && !list.includes(name)) list.push(name);
    });
    return list;
  }, [parties, existingParties]);

  const calculatedLacs = useMemo(() => {
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) return 0;
    if (amountUnit === 'LACS') return num;
    return parseFloat((num / 100000).toString());
  }, [amount, amountUnit]);

  const handleVoiceFinal = useCallback((finalText: string) => {
    if (!finalText.trim()) return;

    if (activeVoiceTarget === 'amount') {
      const amtInLacs = VoiceService.extractAmountInLacs(finalText);
      if (amtInLacs !== undefined) {
        setAmountUnit('LACS');
        setAmount(amtInLacs.toString());
        setVoiceSuccessMsg(`Amount recognized: ${amtInLacs}`);
      } else {
        setVoiceSuccessMsg(`Captured: "${finalText}"`);
      }
    } else if (activeVoiceTarget === 'narration') {
      setNarration(finalText.trim());
      setVoiceSuccessMsg(`Remarks recognized: "${finalText.trim()}"`);
    } else {
      // Complete transaction voice input (English / Hindi)
      const parsed = VoiceService.parseSpokenTransaction(finalText, knownPartyNames);
      const filledParts: string[] = [];

      if (parsed.type) {
        if (parsed.type === 'RECEIVED_FROM') {
          setFlow('INCOME');
          setType('RECEIVED_FROM');
          filledParts.push('Type: Received from');
        } else if (parsed.type === 'RECEIVABLE_FROM') {
          setFlow('INCOME');
          setType('RECEIVABLE_FROM');
          filledParts.push('Type: Receivable from');
        } else if (parsed.type === 'PAID_TO') {
          setFlow('EXPENDITURE');
          setType('PAID_TO');
          filledParts.push('Type: Paid to');
        } else if (parsed.type === 'PAYABLE_TO') {
          setFlow('EXPENDITURE');
          setType('PAYABLE_TO');
          filledParts.push('Type: Payable to');
        }
      }

      if (parsed.amount !== undefined) {
        setAmountUnit('LACS');
        setAmount(parsed.amount.toString());
        filledParts.push(`Amount: ${parsed.amount}`);
      }

      if (parsed.partyName) {
        setPartyName(parsed.partyName);
        const match = (parties || []).find(
          (p) => p.name.toLowerCase() === parsed.partyName!.toLowerCase()
        );
        if (!match) {
          setIsCustomParty(true);
        }
        filledParts.push(`Party: ${parsed.partyName}`);
      }

      if (parsed.narration) {
        setNarration(parsed.narration);
        filledParts.push(`Narration: ${parsed.narration}`);
      }

      if (filledParts.length > 0) {
        setVoiceSuccessMsg(`Auto-filled: ${filledParts.join(' • ')}`);
      } else {
        setVoiceSuccessMsg(`Heard: "${finalText}"`);
      }

      // Requirement 9: Both Party Name and Amount are mandatory
      if (!parsed.partyName || parsed.amount === undefined) {
        setError('Voice note: Both Party Name * and Amount * are mandatory. Please specify any missing field.');
      } else {
        setError('');
      }
    }

    setTimeout(() => {
      setVoiceSuccessMsg('');
    }, 6000);
  }, [activeVoiceTarget, knownPartyNames, parties]);

  const speech = useSpeechRecognition({
    onFinalResult: handleVoiceFinal,
    language: 'en-IN',
  });

  const handleStartVoice = (target: 'all' | 'amount' | 'narration', targetLang?: SpeechLanguage) => {
    setActiveVoiceTarget(target);
    setVoiceSuccessMsg('');
    speech.startListening(targetLang);
  };

  const handleStopVoice = () => {
    speech.stopListening();
    setActiveVoiceTarget(null);
  };

  const handleCloseModal = () => {
    speech.stopListening();
    onClose();
  };

  // Auto start voice if requested via "Add by Voice" button
  useEffect(() => {
    if (isOpen && autoStartVoice) {
      const timer = setTimeout(() => {
        handleStartVoice('all');
      }, 350);
      return () => clearTimeout(timer);
    }
  }, [isOpen, autoStartVoice]);

  if (!isOpen) return null;

  const handleFlowSwitch = (newFlow: 'INCOME' | 'EXPENDITURE') => {
    setFlow(newFlow);
    if (newFlow === 'INCOME') {
      setType('RECEIVED_FROM');
    } else {
      setType('PAID_TO');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) {
      setError('Amount * is mandatory. Please enter a valid positive transaction amount.');
      return;
    }
    if (!partyName.trim()) {
      setError('Party Name * is mandatory. Please enter or select a Party Name.');
      return;
    }
    if (!date) {
      setError('Please select a valid transaction date.');
      return;
    }

    // Convert amount to Lacs per SUM ledger requirements (recording amount in Lacs only)
    const finalAmountInLacs = amountUnit === 'LACS' ? num : parseFloat((num / 100000).toString());

    onSave({
      type,
      amount: finalAmountInLacs,
      partyName: partyName.trim(),
      date,
      narration: narration.trim(),
    });
    handleCloseModal();
  };

  const commonNarrations = flow === 'INCOME'
    ? [
        'Cash settlement of pending balance',
        'Invoice advance payment',
        'Counter sales cash receipt',
        'Goods supplied on credit terms',
        'Customer deposit',
        'Refund received',
      ]
    : [
        'Payment to supplier / vendor',
        'Freight & transport charges',
        'Office electricity & utilities',
        'Staff conveyance & tea expenses',
        'Consignment purchase bill due',
        'Equipment & shop maintenance',
      ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-sky-100 w-full max-w-xl max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-sky-50/50">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-sky-800">
              {existingTransaction ? 'Edit Journal Entry' : 'Record Transaction'}
            </div>
            <h2 className="text-lg font-bold text-slate-900">
              {group.name}
            </h2>
          </div>
          <button
            onClick={handleCloseModal}
            className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* SPEECH RECOGNITION TOOLBAR (Transaction Addition/Recording Only) */}
        <div className="bg-gradient-to-r from-sky-50 via-indigo-50/60 to-purple-50/70 border-b border-sky-100 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                  speech.isListening && activeVoiceTarget === 'all'
                    ? 'bg-rose-500 text-white shadow-md shadow-rose-500/40 animate-pulse'
                    : 'bg-gradient-to-tr from-sky-600 to-indigo-600 text-white shadow-sm'
                }`}
              >
                <Mic className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <span>Voice Transaction Input</span>
                  <span className="text-[10px] font-semibold px-1.5 py-0.5 bg-sky-100 text-sky-800 rounded">
                    English & हिंदी
                  </span>
                </div>
                <div className="text-[11px] text-slate-500">
                  Speak to auto-fill Category, Amount, Party & Narration
                </div>
              </div>
            </div>

            {/* Language Switcher & Main Voice Button */}
            <div className="flex items-center gap-2">
              <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 shadow-2xs">
                <button
                  type="button"
                  onClick={() => speech.setLanguage('en-IN')}
                  className={`px-2 py-1 text-[11px] font-bold rounded cursor-pointer transition-all ${
                    speech.language === 'en-IN'
                      ? 'bg-sky-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  English
                </button>
                <button
                  type="button"
                  onClick={() => speech.setLanguage('hi-IN')}
                  className={`px-2 py-1 text-[11px] font-bold rounded cursor-pointer transition-all ${
                    speech.language === 'hi-IN'
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  हिंदी
                </button>
              </div>

              {speech.isListening && activeVoiceTarget === 'all' ? (
                <button
                  type="button"
                  onClick={handleStopVoice}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm animate-pulse cursor-pointer"
                >
                  <MicOff className="w-3.5 h-3.5" />
                  <span>Stop Listening</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => handleStartVoice('all')}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm shadow-sky-600/30 transition-all cursor-pointer"
                >
                  <Mic className="w-3.5 h-3.5" />
                  <span>{speech.language === 'hi-IN' ? 'बोलकर लिखें' : 'Speak Transaction'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Active Listening / Interim Transcript Banner */}
          {speech.isListening && activeVoiceTarget === 'all' && (
            <div className="mt-3 p-3 bg-white/95 border border-indigo-200 rounded-xl shadow-xs">
              <div className="flex items-center gap-2 text-xs font-semibold text-indigo-700 mb-1">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                <span>Listening in {speech.language === 'hi-IN' ? 'हिंदी (Hindi)' : 'English (India)'}... Speak now:</span>
              </div>
              <div className="font-mono text-xs sm:text-sm text-slate-800 italic min-h-[20px]">
                "{speech.transcript || 'Listening for speech...'}"
              </div>
            </div>
          )}

          {/* Auto-filled Success Banner */}
          {voiceSuccessMsg && (
            <div className="mt-2.5 p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span className="font-medium">{voiceSuccessMsg}</span>
            </div>
          )}

          {/* Speech Recognition Error Banner */}
          {speech.error && (
            <div className="mt-2.5 p-2 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                <span>{speech.error}</span>
              </div>
              {speech.isIosSafari && (
                <button
                  type="button"
                  onClick={() => speech.openInGoogleChrome()}
                  className="px-2.5 py-1 bg-sky-600 hover:bg-sky-700 text-white rounded-md text-[11px] font-bold shrink-0 shadow-xs self-start sm:self-auto"
                >
                  Open in Chrome
                </button>
              )}
            </div>
          )}

          {/* Speech Spoken Syntax Hints */}
          <div className="mt-2 text-[10px] text-slate-500 flex flex-wrap items-center gap-1">
            <span className="font-semibold text-slate-600">Spoken Example:</span>
            {speech.language === 'hi-IN' ? (
              <span className="italic text-slate-600">
                "रमेश पटेल से 15000 रुपये मिले" या "सुरेश को 5000 दिए ऑफिस खर्च के लिए"
              </span>
            ) : (
              <span className="italic text-slate-600">
                "Received 15000 from Rajesh Kumar for bill payment" or "Paid 5000 to Suresh for tea expenses"
              </span>
            )}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="p-3 text-xs bg-rose-50 border border-rose-200 text-rose-700 rounded-lg flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* TWO MAIN FLOW BUTTONS: Income vs Expenditure */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 uppercase tracking-wider">
              1. Select Flow Direction
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100/80 rounded-xl">
              <button
                type="button"
                onClick={() => handleFlowSwitch('INCOME')}
                className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  flow === 'INCOME'
                    ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/30'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                <ArrowDownLeft className="w-4 h-4" />
                <span>+ Income (Inflow)</span>
              </button>

              <button
                type="button"
                onClick={() => handleFlowSwitch('EXPENDITURE')}
                className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  flow === 'EXPENDITURE'
                    ? 'bg-rose-600 text-white shadow-sm shadow-rose-600/30'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                <ArrowUpRight className="w-4 h-4" />
                <span>- Expenditure (Outflow)</span>
              </button>
            </div>
          </div>

          {/* STANDARDIZED BUTTON-DRIVEN SELECTION (No Dr/Cr) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 uppercase tracking-wider">
              2. Transaction Category (Replacing Dr/Cr)
            </label>
            {flow === 'INCOME' ? (
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setType('RECEIVED_FROM')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    type === 'RECEIVED_FROM'
                      ? 'border-emerald-500 bg-emerald-50/80 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-800">Received from</span>
                    {type === 'RECEIVED_FROM' && <Check className="w-4 h-4 text-emerald-600" />}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Cash received into counter / settled by party
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setType('RECEIVABLE_FROM')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    type === 'RECEIVABLE_FROM'
                      ? 'border-sky-500 bg-sky-50/80 ring-2 ring-sky-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-sky-800">Receivable from</span>
                    {type === 'RECEIVABLE_FROM' && <Check className="w-4 h-4 text-sky-600" />}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Credit sales or advance loan party owes us
                  </div>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setType('PAID_TO')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    type === 'PAID_TO'
                      ? 'border-rose-500 bg-rose-50/80 ring-2 ring-rose-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-rose-800">Paid to</span>
                    {type === 'PAID_TO' && <Check className="w-4 h-4 text-rose-600" />}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Cash paid out from counter to party/supplier
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setType('PAYABLE_TO')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    type === 'PAYABLE_TO'
                      ? 'border-amber-500 bg-amber-50/80 ring-2 ring-amber-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-800">Payable to</span>
                    {type === 'PAYABLE_TO' && <Check className="w-4 h-4 text-amber-600" />}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Bill/liability incurred that we owe to party
                  </div>
                </button>
              </div>
            )}
          </div>

          {/* Amount Field (Mandatory *, Recorded in Lacs only) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1">
                <span>3. Amount</span>
                <span className="text-rose-600 font-bold text-sm">*</span>
              </label>

              {/* Unit Toggle: Full Amount (auto-converted) OR Direct Value Entry */}
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setAmountUnit('RUPEES')}
                    className={`px-2 py-0.5 rounded-md font-bold transition-all cursor-pointer ${
                      amountUnit === 'RUPEES' ? 'bg-white text-sky-800 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Full Value
                  </button>
                  <button
                    type="button"
                    onClick={() => setAmountUnit('LACS')}
                    className={`px-2 py-0.5 rounded-md font-bold transition-all cursor-pointer ${
                      amountUnit === 'LACS' ? 'bg-white text-indigo-800 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Direct Value
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    if (speech.isListening && activeVoiceTarget === 'amount') handleStopVoice();
                    else handleStartVoice('amount');
                  }}
                  className={`text-[11px] font-bold flex items-center gap-1 px-2 py-0.5 rounded-md border transition-all cursor-pointer ${
                    speech.isListening && activeVoiceTarget === 'amount'
                      ? 'bg-rose-500 text-white border-rose-600 animate-pulse'
                      : 'bg-sky-50 text-sky-700 hover:bg-sky-100 border-sky-200'
                  }`}
                  title={speech.language === 'hi-IN' ? 'रकम बोलें' : 'Speak Amount'}
                >
                  <Mic className="w-3 h-3" />
                  <span>{speech.language === 'hi-IN' ? 'रकम बोलें' : 'Speak'}</span>
                </button>
              </div>
            </div>

            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-xs font-bold uppercase tracking-wider">
                {amountUnit === 'RUPEES' ? 'Full' : 'Direct'}
              </span>
              <input
                type="number"
                step="any"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
                    e.preventDefault();
                  }
                }}
                placeholder={amountUnit === 'RUPEES' ? 'e.g. 50000' : 'e.g. 0.50'}
                className="w-full pl-14 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-lg font-bold text-slate-900 focus:bg-white focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none tabular-nums [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                required
              />
            </div>

            {/* Live Amount Feedback Badge */}
            <div className="mt-2 p-2.5 bg-gradient-to-r from-sky-50 via-indigo-50/50 to-blue-50 border border-sky-200/80 rounded-xl text-xs flex items-center justify-between">
              <div className="text-slate-600 flex items-center gap-1">
                <span className="font-semibold text-slate-700">Recorded as:</span>
              </div>
              <div className="font-mono font-bold text-sky-900 text-sm bg-white px-2.5 py-0.5 rounded-lg border border-sky-200 shadow-2xs">
                {calculatedLacs > 0 ? calculatedLacs.toString() : '0.00'}
              </div>
            </div>
          </div>

          {/* Party Dropdown Selection Tool (Mandatory *) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1">
                <span>4. Select Party (Customer / Vendor)</span>
                <span className="text-rose-600 font-bold text-sm">*</span>
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsCustomParty(!isCustomParty)}
                  className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 underline cursor-pointer"
                >
                  {isCustomParty ? '← Choose from Dropdown' : '✏️ Type Manual Name'}
                </button>
                {onOpenPartyModal && (
                  <button
                    type="button"
                    onClick={onOpenPartyModal}
                    className="text-[11px] font-bold text-sky-700 hover:text-sky-800 flex items-center gap-1 cursor-pointer bg-sky-50 px-2 py-0.5 rounded-md border border-sky-200"
                  >
                    <Plus className="w-3 h-3" />
                    <span>+ Add New Party</span>
                  </button>
                )}
              </div>
            </div>

            {!isCustomParty ? (
              <div className="space-y-2">
                {/* Filter Pills for Dropdown: All / Receivable / Payable */}
                <div className="flex items-center gap-1 text-[11px] font-semibold">
                  <span className="text-slate-400 mr-1">Filter list:</span>
                  <button
                    type="button"
                    onClick={() => setPartyFilter('ALL')}
                    className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                      partyFilter === 'ALL'
                        ? 'bg-slate-800 text-white font-bold'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    All Parties ({parties?.length || 0})
                  </button>
                  <button
                    type="button"
                    onClick={() => setPartyFilter('RECEIVABLE')}
                    className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                      partyFilter === 'RECEIVABLE'
                        ? 'bg-sky-700 text-white font-bold'
                        : 'bg-sky-50 text-sky-700 hover:bg-sky-100'
                    }`}
                  >
                    Receivable (Inflow)
                  </button>
                  <button
                    type="button"
                    onClick={() => setPartyFilter('PAYABLE')}
                    className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                      partyFilter === 'PAYABLE'
                        ? 'bg-rose-700 text-white font-bold'
                        : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                    }`}
                  >
                    Payable (Outflow)
                  </button>
                </div>

                {/* Dropdown Select Element */}
                <div className="relative">
                  <select
                    value={partyName}
                    onChange={(e) => setPartyName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none appearance-none cursor-pointer"
                    required
                  >
                    <option value="">
                      -- Select Party from Created List ({filteredDropdownParties.length} available) --
                    </option>
                    {filteredDropdownParties.map((p) => {
                      const summary = (partySummaries || []).find((s) => s.partyName === p.name);
                      let balanceLabel = '';
                      if (summary) {
                        if (summary.netBalance > 0) balanceLabel = ` [Receivable: ${summary.netBalance.toLocaleString()}]`;
                        else if (summary.netBalance < 0) balanceLabel = ` [Payable: ${Math.abs(summary.netBalance).toLocaleString()}]`;
                        else balanceLabel = ' [Settled]';
                      }
                      return (
                        <option key={p.id} value={p.name}>
                          {p.name}{balanceLabel}
                        </option>
                      );
                    })}
                  </select>
                  <div className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500">
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </div>

                {/* Selected Party Summary Card (Mobile number hidden for privacy) */}
                {selectedPartyObj && (
                  <div className="p-3 bg-gradient-to-r from-sky-50/80 to-blue-50/80 border border-sky-200 rounded-xl text-xs flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900 flex items-center gap-2">
                        <span>{selectedPartyObj.name}</span>
                        {selectedPartyObj.contactPerson && (
                          <span className="text-[10px] text-slate-500 font-normal">
                            ({selectedPartyObj.contactPerson})
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-600 mt-0.5 font-mono">
                        {selectedPartyObj.gstin ? `GST: ${selectedPartyObj.gstin}` : 'Registered Party'}
                      </div>
                    </div>
                    {selectedPartySummary && (
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block">Current Ledger Position</span>
                        <span className={`font-mono font-bold text-xs ${
                          selectedPartySummary.netBalance > 0
                            ? 'text-sky-700'
                            : selectedPartySummary.netBalance < 0
                            ? 'text-rose-700'
                            : 'text-emerald-700'
                        }`}>
                          {selectedPartySummary.netBalance > 0
                            ? `${selectedPartySummary.netBalance.toLocaleString()} (Receivable)`
                            : selectedPartySummary.netBalance < 0
                            ? `${Math.abs(selectedPartySummary.netBalance).toLocaleString()} (Payable)`
                            : 'Settled (0.00)'}
                        </span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              /* Manual / Custom Input fallback */
              <div className="space-y-1.5">
                <input
                  type="text"
                  value={partyName}
                  onChange={(e) => setPartyName(e.target.value)}
                  placeholder="Type party name (e.g. Ramesh Patel, Star Logistics)"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:border-sky-500 outline-none"
                  required
                  autoFocus
                />
                <span className="text-[10px] text-slate-500 block">
                  Typing custom party. Or click "Choose from Dropdown" to select an existing registered party.
                </span>
              </div>
            )}
          </div>

          {/* Date Picker with Today / Yesterday buttons */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                5. Date
              </label>
              <div className="flex items-center gap-1.5 text-xs">
                <button
                  type="button"
                  onClick={() => setDate(new Date().toISOString().slice(0, 10))}
                  className="text-sky-700 hover:underline font-medium text-[11px]"
                >
                  Today
                </button>
                <span className="text-slate-300">·</span>
                <button
                  type="button"
                  onClick={() => {
                    const y = new Date();
                    y.setDate(y.getDate() - 1);
                    setDate(y.toISOString().slice(0, 10));
                  }}
                  className="text-slate-600 hover:underline font-medium text-[11px]"
                >
                  Yesterday
                </button>
              </div>
            </div>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none"
              required
            />
          </div>

          {/* Narration with Quick Presets & Voice Mic */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                6. Narration / Remarks
              </label>
              <button
                type="button"
                onClick={() => {
                  if (speech.isListening && activeVoiceTarget === 'narration') handleStopVoice();
                  else handleStartVoice('narration');
                }}
                className={`text-[11px] font-bold flex items-center gap-1 px-2 py-0.5 rounded-md border transition-all cursor-pointer ${
                  speech.isListening && activeVoiceTarget === 'narration'
                    ? 'bg-rose-500 text-white border-rose-600 animate-pulse'
                    : 'bg-sky-50 text-sky-700 hover:bg-sky-100 border-sky-200'
                }`}
                title={speech.language === 'hi-IN' ? 'विवरण बोलें' : 'Speak Narration'}
              >
                <Mic className="w-3 h-3" />
                <span>{speech.language === 'hi-IN' ? 'विवरण बोलें' : 'Speak Remarks'}</span>
              </button>
            </div>
            <div className="relative">
              <input
                type="text"
                value={narration}
                onChange={(e) => setNarration(e.target.value)}
                placeholder="e.g. Bill #441 payment via counter, advance cash token"
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none"
              />
            </div>
            <div className="flex flex-wrap items-center gap-1.5 mt-2">
              <span className="text-[11px] text-slate-600 mr-1">Presets:</span>
              {commonNarrations.slice(0, 3).map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setNarration(item)}
                  className="px-2 py-0.5 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          {/* Audit Trail Preview Box */}
          <div className="bg-sky-50/60 border border-sky-100 rounded-xl p-3 flex items-start gap-2.5 text-xs text-slate-600">
            <Clock className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-slate-800">Audit Trail Notice: </span>
              {existingTransaction
                ? `Modification will be recorded under ${currentUser.name} (${currentUser.role}) with exact timestamp.`
                : `Entry will be logged as created by ${currentUser.name} (${currentUser.role}) on current timestamp.`}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={handleCloseModal}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`px-5 py-2.5 text-xs font-bold text-white rounded-xl shadow-sm transition-all cursor-pointer ${
                flow === 'INCOME'
                  ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/30'
                  : 'bg-rose-600 hover:bg-rose-700 shadow-rose-600/30'
              }`}
            >
              {existingTransaction ? 'Update Entry' : 'Record Transaction'}
            </button>
          </div>
        </form>

        {/* Footer with App Version and Copyright */}
        <div className="text-center text-[11px] text-slate-500 py-2.5 bg-slate-50/80 border-t border-slate-100 rounded-b-2xl">
          SUM • Version 2026.v1 • © MG
        </div>
      </div>
    </div>
  );
};
