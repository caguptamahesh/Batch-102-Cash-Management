const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const rootDir = path.resolve(__dirname, '..');
const downloadsDir = path.join(rootDir, 'downloads');
const userDownloadsDir = path.resolve(rootDir, '..'); // c:\Users\91941\Downloads
const tempAppDir = path.join(rootDir, 'temp_app_build');

if (!fs.existsSync(downloadsDir)) fs.mkdirSync(downloadsDir, { recursive: true });
if (fs.existsSync(tempAppDir)) fs.rmSync(tempAppDir, { recursive: true, force: true });
fs.mkdirSync(tempAppDir, { recursive: true });

console.log('--- Step 1: Preparing Standalone SUM App Package ---');
const appFolder = path.join(tempAppDir, 'SUM-App');
fs.mkdirSync(appFolder, { recursive: true });

// Copy server.js
fs.copyFileSync(path.join(rootDir, 'server.js'), path.join(appFolder, 'server.js'));

// Copy package.json
const rootPkg = JSON.parse(fs.readFileSync(path.join(rootDir, 'package.json'), 'utf8'));
const appPkg = {
  name: "sum-app",
  version: "2026.v1",
  description: "SUM Cash Management Ledger (Version 2026.v1) © MG",
  main: "server.js",
  scripts: {
    "start": "node server.js"
  },
  dependencies: {
    "cors": rootPkg.dependencies?.cors || "^2.8.5",
    "dotenv": rootPkg.dependencies?.dotenv || "^17.2.3",
    "express": rootPkg.dependencies?.express || "^4.21.2",
    "ws": rootPkg.dependencies?.ws || "^8.18.0"
  }
};
fs.writeFileSync(path.join(appFolder, 'package.json'), JSON.stringify(appPkg, null, 2));

// Copy dist/
copyFolderRecursiveSync(path.join(rootDir, 'dist'), path.join(appFolder, 'dist'));

// Copy .env.example as .env
fs.copyFileSync(path.join(rootDir, '.env.example'), path.join(appFolder, '.env'));

// 1. One-Click Windows Launcher: Launch-SUM.bat
fs.writeFileSync(path.join(appFolder, 'Launch-SUM.bat'), `@echo off
title SUM - Cash Management (Version 2026.v1)
color 0B
echo ========================================================
echo   SUM - CASH MANAGEMENT LEDGER (Version 2026.v1)
echo   Copyright (c) MG - All Rights Reserved
echo ========================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Node.js is required to run the local server.
  echo Please download and install Node.js from https://nodejs.org
  pause
  exit /b 1
)

if not exist node_modules (
  echo [1/2] Setting up local app components...
  call npm install --omit=dev
  echo.
)

echo [2/2] Opening SUM Application...
start "" http://localhost:3000
node server.js
pause
`);

// 2. Silent Windows Launcher (Runs in background without command prompt window)
fs.writeFileSync(path.join(appFolder, 'Launch-SUM-Silent.vbs'), `' SUM Cash Management Silent Launcher
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)

' Check if node_modules exists, otherwise run normal batch
If Not fso.FolderExists(currentDir & "\\node_modules") Then
  WshShell.Run "cmd /c cd /d """ & currentDir & """ && npm install --omit=dev && node server.js", 1, False
Else
  WshShell.Run "cmd /c cd /d """ & currentDir & """ && node server.js", 0, False
End If

WScript.Sleep 1500
WshShell.Run "http://localhost:3000"
`);

// 3. Mac / Linux Launcher: Launch-SUM.sh
fs.writeFileSync(path.join(appFolder, 'Launch-SUM.sh'), `#!/bin/bash
echo "========================================================"
echo "  SUM - CASH MANAGEMENT LEDGER (Version 2026.v1)"
echo "  Copyright (c) MG - All Rights Reserved"
echo "========================================================"

if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js is not installed. Please install from https://nodejs.org"
    exit 1
fi

if [ ! -d "node_modules" ]; then
    echo "[1/2] Installing dependencies..."
    npm install --omit=dev
fi

echo "[2/2] Opening SUM at http://localhost:3000..."
if command -v xdg-open &> /dev/null; then
    xdg-open http://localhost:3000 &
elif command -v open &> /dev/null; then
    open http://localhost:3000 &
fi

node server.js
`);

try { fs.chmodSync(path.join(appFolder, 'Launch-SUM.sh'), '755'); } catch {}

// 4. Instructions Readme
fs.writeFileSync(path.join(appFolder, 'README-INSTALLATION.txt'), `========================================================================
SUM - CASH MANAGEMENT LEDGER (Version 2026.v1)
Author & Copyright: Mr. MG (+91 9414067123)
========================================================================

HOW TO RUN ON WINDOWS:
1. Double-click "Launch-SUM.bat" (or "Launch-SUM-Silent.vbs" for silent background mode).
2. The application will start and open automatically in your default browser at:
   http://localhost:3000

HOW TO INSTALL ON MOBILE (iPhone / iPad / Android):
1. Connect your phone to the same Wi-Fi as your PC.
2. In the console when the server starts, note your local Wi-Fi IP (e.g. http://192.168.1.100:3000).
3. Open that URL on your phone's browser:
   - On iPhone (iOS): Open in Google Chrome (for voice recognition).
   - Tap Share / Options -> "Add to Home Screen".
4. The "M" SUM icon will appear on your phone home screen just like a native app!

FEATURES INCLUDED:
- Clean numerical display without "Lacs" suffix or absolute rupee numbers
- Voice recognition with multilingual stop commands ("Stop", "Over", "End", "बस")
- Real-time synchronization across paired phones and PCs
- 2-digit confirmation ("13") for instant remote data wipe
- Encrypted backup system ("Download Virus.enc") with SMS alert to Mr. MG
- Full offline encryption (AES-256-GCM)
========================================================================
`);

console.log('--- Step 2: Compressing SUM-App.zip ---');
const zipOutputInProject = path.join(downloadsDir, 'SUM-App.zip');
const zipOutputInUserDownloads = path.join(userDownloadsDir, 'SUM-App.zip');
const publicZipOutput = path.join(rootDir, 'public', 'downloads', 'SUM-App.zip');
const distZipOutput = path.join(rootDir, 'dist', 'downloads', 'SUM-App.zip');

if (fs.existsSync(zipOutputInProject)) fs.unlinkSync(zipOutputInProject);

execSync(`powershell -NoProfile -Command "Compress-Archive -Path '${appFolder}\\*' -DestinationPath '${zipOutputInProject}' -Force"`, { stdio: 'inherit' });

console.log('--- Step 3: Copying SUM-App.zip to User Downloads Folder & Static Assets ---');
fs.copyFileSync(zipOutputInProject, zipOutputInUserDownloads);
fs.copyFileSync(zipOutputInProject, publicZipOutput);
fs.copyFileSync(zipOutputInProject, distZipOutput);

// Cleanup
try { fs.rmSync(tempAppDir, { recursive: true, force: true }); } catch {}

console.log('\n======================================================');
console.log('SUCCESS! SUM-App.zip is ready:');
console.log('1. Direct User Downloads: ', zipOutputInUserDownloads, `(${fs.statSync(zipOutputInUserDownloads).size} bytes)`);
console.log('2. Project Downloads:     ', zipOutputInProject);
console.log('======================================================\n');

function copyFolderRecursiveSync(source, target) {
  if (!fs.existsSync(target)) fs.mkdirSync(target, { recursive: true });

  const files = fs.readdirSync(source);
  for (const file of files) {
    const curSource = path.join(source, file);
    const curTarget = path.join(target, file);

    if (fs.lstatSync(curSource).isDirectory()) {
      copyFolderRecursiveSync(curSource, curTarget);
    } else {
      fs.copyFileSync(curSource, curTarget);
    }
  }
}
