import React from 'react';
import { Bell, CheckCircle2, X } from 'lucide-react';

export interface ToastNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type?: 'success' | 'info' | 'warning';
}

interface NotificationToastProps {
  notifications: ToastNotification[];
  onDismiss: (id: string) => void;
}

export const NotificationToast: React.FC<NotificationToastProps> = ({
  notifications,
  onDismiss,
}) => {
  if (notifications.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {notifications.map((n) => (
        <div
          key={n.id}
          className="pointer-events-auto bg-white/95 backdrop-blur-md border border-sky-200 rounded-xl p-3.5 shadow-xl shadow-sky-900/10 flex items-start gap-3 transition-all animate-in fade-in slide-in-from-bottom-2 duration-200"
        >
          <div className="w-7 h-7 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center shrink-0 mt-0.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-bold text-slate-900 leading-tight">
              {n.title}
            </div>
            <div className="text-[11px] text-slate-600 mt-0.5 truncate">
              {n.message}
            </div>
            <div className="text-[10px] text-slate-400 font-mono mt-1">
              {n.timestamp}
            </div>
          </div>
          <button
            onClick={() => onDismiss(n.id)}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};
