/**
 * Multilingual Speech Recognition & Transaction Parsing Service (English & Hindi)
 * Enables voice-driven transaction addition and field dictation in CashFlow Ledger.
 */

export interface ParsedVoiceTransaction {
  type?: 'RECEIVED_FROM' | 'PAID_TO' | 'RECEIVABLE_FROM' | 'PAYABLE_TO';
  amount?: number; // In Lacs as required by SUM ledger
  amountInRupees?: number; // Raw Rupees for display/conversion
  partyName?: string;
  narration?: string;
  rawText: string;
}

export class VoiceService {
  /**
   * Check if SpeechRecognition is supported in the current browser
   */
  public static isSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return !!(
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition
    );
  }

  /**
   * Parse spoken Hindi numerals (०-९) to standard digits
   */
  public static normalizeHindiDigits(text: string): string {
    const hindiDigits = ['०', '१', '२', '३', '४', '५', '६', '७', '८', '९'];
    let result = text;
    for (let i = 0; i < 10; i++) {
      result = result.replace(new RegExp(hindiDigits[i], 'g'), i.toString());
    }
    return result;
  }

  /**
   * Check if user spoken text includes end/stop commands (English or Hindi)
   * User requested: "end the voice recognition when user says 'Stop' or 'End' or 'Over'"
   */
  public static hasStopCommand(text: string): boolean {
    if (!text) return false;
    const lower = text.toLowerCase();
    // English: stop, end, over, finish, done
    // Hindi: स्टॉप, बंद करो, खत्म, रुको, समाप्त, बस
    const stopPattern = /\b(?:stop|end|over|finish|done)\b|(?:स्टॉप|बंद\s*करो|खत्म|रुको|समाप्त|बस)/i;
    return stopPattern.test(lower);
  }

  /**
   * Strip stop command words from transcript so they do not pollute transaction fields
   */
  public static stripStopCommand(text: string): string {
    if (!text) return '';
    return text
      .replace(/\b(?:stop|end|over|finish|done)\b/gi, ' ')
      .replace(/(?:स्टॉप|बंद\s*करो|खत्म|रुको|समाप्त|बस)/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Parse amounts in English and Hindi directly into Lacs
   * Requirement 13: "Convert the amount of transaction entered into Lacs and record the amount in lacs only."
   * Preserves exact decimal precision as required by input.
   */
  public static extractAmountInLacs(raw: string): number | undefined {
    const text = this.normalizeHindiDigits(raw.toLowerCase());

    // 1. Check if spoken explicitly with Lakh / Lac multiplier
    // e.g. "1.5 लाख", "2.75 lakh", "50 lac"
    const lakhMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:लाख|lakh|lac|lacs)(?:[\s.,;!₹]|$)/i);
    if (lakhMatch) {
      const val = parseFloat(lakhMatch[1]);
      if (!isNaN(val) && val > 0) {
        return parseFloat(val.toFixed(6));
      }
    }

    // 2. Check if spoken in Crores
    const croreMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:करोड़|करोड|crore|cr)(?:[\s.,;!₹]|$)/i);
    if (croreMatch) {
      const val = parseFloat(croreMatch[1]) * 100; // 1 crore = 100 lacs
      if (!isNaN(val) && val > 0) {
        return parseFloat(val.toFixed(6));
      }
    }

    // 3. Spoken in thousands (e.g. "15 हजार", "50 thousand") -> convert to Lacs (50,000 / 100,000 = 0.5 Lacs)
    const thousandMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:हज़ार|हजार|thousand|k)(?:[\s.,;!₹]|$)/i);
    if (thousandMatch) {
      const rupees = parseFloat(thousandMatch[1]) * 1000;
      return parseFloat((rupees / 100000).toFixed(6));
    }

    // 4. Raw rupees amount -> convert to Lacs
    const rawRupees = this.extractAmount(raw);
    if (rawRupees !== undefined && rawRupees > 0) {
      // If entered number is > 100, it's virtually always in Rupees, so convert to Lacs
      // e.g. 50000 -> 0.50 Lacs; 15000 -> 0.15 Lacs; 5000 -> 0.05 Lacs; 123456 -> 1.23456 Lacs
      return parseFloat((rawRupees / 100000).toFixed(6));
    }

    return undefined;
  }

  /**
   * Parse amounts in English and Hindi in raw Rupees (e.g. 5000, 15 हजार, 2.5 lakh, etc.)
   */
  public static extractAmount(raw: string): number | undefined {
    const text = this.normalizeHindiDigits(raw.toLowerCase());

    // 1. Check for multiplier patterns like "15 हजार", "20 thousand", "2 lakh", "50 सौ"
    const thousandMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:हज़ार|हजार|thousand|k)(?:[\s.,;!₹]|$)/i);
    if (thousandMatch) {
      return Math.round(parseFloat(thousandMatch[1]) * 1000);
    }

    const lakhMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:लाख|lakh|lac)(?:[\s.,;!₹]|$)/i);
    if (lakhMatch) {
      return Math.round(parseFloat(lakhMatch[1]) * 100000);
    }

    const croreMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:करोड़|करोड|crore|cr)(?:[\s.,;!₹]|$)/i);
    if (croreMatch) {
      return Math.round(parseFloat(croreMatch[1]) * 10000000);
    }

    const hundredMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:सौ|hundred)(?:[\s.,;!₹]|$)/i);
    if (hundredMatch) {
      return Math.round(parseFloat(hundredMatch[1]) * 100);
    }

    // 2. Hindi word number combinations
    const wordNumbers: { [key: string]: number } = {
      'एक': 1, 'दो': 2, 'तीन': 3, 'चार': 4, 'पांच': 5, 'पाँच': 5,
      'छह': 6, 'सात': 7, 'आठ': 8, 'नौ': 9, 'दस': 10,
      'ग्यारह': 11, 'बारह': 12, 'तेरह': 13, 'चौदह': 14, 'पंद्रह': 15,
      'बीस': 20, 'पच्चीस': 25, 'तीस': 30, 'चालीस': 40, 'पचास': 50,
      'सौ': 100, 'हजार': 1000, 'हज़ार': 1000, 'लाख': 100000,
    };

    for (const [word, val] of Object.entries(wordNumbers)) {
      if (val >= 100) {
        const regex = new RegExp(`(\\S+)\\s+${word}`, 'i');
        const match = text.match(regex);
        if (match && wordNumbers[match[1]]) {
          return wordNumbers[match[1]] * val;
        }
      }
    }

    // 3. Standard numeric digits (e.g. "15000", "4,500.50", "₹5000")
    const cleanNumbers = text.replace(/,/g, '');
    const numMatch = cleanNumbers.match(/(?:rs\.?|inr|₹|रुपये|रूपए|रुपया)?\s*(\d+(?:\.\d+)?)/i);
    if (numMatch && numMatch[1]) {
      const parsed = parseFloat(numMatch[1]);
      if (!isNaN(parsed) && parsed > 0) {
        return parsed;
      }
    }

    return undefined;
  }

  /**
   * Detect transaction direction and category in English or Hindi
   */
  public static detectType(
    text: string
  ): 'RECEIVED_FROM' | 'PAID_TO' | 'RECEIVABLE_FROM' | 'PAYABLE_TO' | undefined {
    const lower = text.toLowerCase();

    // Hindi Keywords
    if (
      lower.includes('लेने हैं') ||
      lower.includes('लेना है') ||
      lower.includes('बाकी है') ||
      lower.includes('लेना बनता है') ||
      lower.includes('उधार दिया')
    ) {
      return 'RECEIVABLE_FROM';
    }

    if (
      lower.includes('देने हैं') ||
      lower.includes('देना है') ||
      lower.includes('बकाया है') ||
      lower.includes('देना बाकी') ||
      lower.includes('उधार लिया')
    ) {
      return 'PAYABLE_TO';
    }

    if (
      lower.includes('मिले') ||
      lower.includes('मिला') ||
      lower.includes('मिली') ||
      lower.includes('प्राप्त') ||
      lower.includes('आए') ||
      lower.includes('जमा हुए') ||
      lower.includes('वसूल')
    ) {
      return 'RECEIVED_FROM';
    }

    if (
      lower.includes('दिए') ||
      lower.includes('दिया') ||
      lower.includes('दी') ||
      lower.includes('भुगतान') ||
      lower.includes('चुकाया') ||
      lower.includes('खर्च')
    ) {
      return 'PAID_TO';
    }

    // English Keywords
    if (
      lower.includes('receivable') ||
      lower.includes('due from') ||
      lower.includes('owes us') ||
      lower.includes('to receive')
    ) {
      return 'RECEIVABLE_FROM';
    }

    if (
      lower.includes('payable') ||
      lower.includes('due to') ||
      lower.includes('we owe') ||
      lower.includes('to pay')
    ) {
      return 'PAYABLE_TO';
    }

    if (
      lower.includes('received') ||
      lower.includes('receive') ||
      lower.includes('got') ||
      lower.includes('collected') ||
      lower.includes('inflow')
    ) {
      return 'RECEIVED_FROM';
    }

    if (
      lower.includes('paid') ||
      lower.includes('pay') ||
      lower.includes('payment') ||
      lower.includes('gave') ||
      lower.includes('given') ||
      lower.includes('spent')
    ) {
      return 'PAID_TO';
    }

    return undefined;
  }

  /**
   * Extract Party Name by matching known parties or parsing speech grammar
   */
  public static extractPartyName(text: string, knownParties: string[] = []): string | undefined {
    const clean = text.trim();
    if (!clean) return undefined;

    // 1. Check if any known party name is spoken directly
    for (const p of knownParties) {
      if (!p) continue;
      const regex = new RegExp(`\\b${p.trim()}\\b`, 'i');
      if (regex.test(clean)) {
        return p;
      }
    }

    // Also check case-insensitive substring
    for (const p of knownParties) {
      if (p.length > 2 && clean.toLowerCase().includes(p.toLowerCase())) {
        return p;
      }
    }

    // 2. Hindi sentence structure: "[Party Name] से [Amount] मिले" OR "[Party Name] को [Amount] दिए"
    const hindiFromMatch = clean.match(/(?:से\s+)?([^,]+?)\s+से\s+/i);
    if (hindiFromMatch && hindiFromMatch[1]) {
      const candidate = hindiFromMatch[1]
        .replace(/^(?:received|paid|मिले|दिए|आज|कल)\s+/i, '')
        .trim();
      if (candidate.length > 1 && !this.isStopWord(candidate)) {
        return candidate;
      }
    }

    const hindiToMatch = clean.match(/([^,]+?)\s+को\s+/i);
    if (hindiToMatch && hindiToMatch[1]) {
      const candidate = hindiToMatch[1]
        .replace(/^(?:received|paid|मिले|दिए|आज|कल)\s+/i, '')
        .trim();
      if (candidate.length > 1 && !this.isStopWord(candidate)) {
        return candidate;
      }
    }

    // 3. English sentence structure: "from [Party Name]" OR "to [Party Name]"
    const engFromMatch = clean.match(/\bfrom\s+([A-Za-z0-9\s&]+?)(?:\s+for|\s+towards|\s+on|\s+dated|\s+amount|\s+rs|\s+₹|\s+\d|$)/i);
    if (engFromMatch && engFromMatch[1]) {
      const candidate = engFromMatch[1].trim();
      if (candidate.length > 1 && !this.isStopWord(candidate)) {
        return candidate;
      }
    }

    const engToMatch = clean.match(/\bto\s+([A-Za-z0-9\s&]+?)(?:\s+for|\s+towards|\s+on|\s+dated|\s+amount|\s+rs|\s+₹|\s+\d|$)/i);
    if (engToMatch && engToMatch[1]) {
      const candidate = engToMatch[1].trim();
      if (candidate.length > 1 && !this.isStopWord(candidate)) {
        return candidate;
      }
    }

    return undefined;
  }

  private static isStopWord(word: string): boolean {
    const stops = ['रुपये', 'rupees', 'rs', 'amount', 'cash', 'कैश', 'नकद', 'आज', 'कल', 'received', 'paid'];
    return stops.includes(word.toLowerCase().trim());
  }

  /**
   * Extract Narration from spoken text
   */
  public static extractNarration(text: string): string | undefined {
    // 1. Hindi postposition style: "... [narration] के लिए" or "... [narration] बाबत" or "... [narration] हेतु"
    const hindiPostMatch = text.match(/(?:मिले|मिला|मिली|दिए|दिया|दी|चुकाया|भुगतान)?\s*([^,]+?)\s*(?:के लिए|बाबत|हेतु)(?:$|[.,])/i);
    if (hindiPostMatch && hindiPostMatch[1]) {
      const candidate = hindiPostMatch[1].trim();
      if (candidate.length > 1 && !this.isStopWord(candidate)) {
        return candidate;
      }
    }

    // 2. Hindi preposition style: "के लिए [narration]"
    const hindiPreMatch = text.match(/(?:के लिए|बाबत|हेतु)\s+([^,.]+)$/i);
    if (hindiPreMatch && hindiPreMatch[1]) {
      const candidate = hindiPreMatch[1].trim();
      if (candidate.length > 1 && !this.isStopWord(candidate)) {
        return candidate;
      }
    }

    // 3. English narration keywords: "for", "towards", "against"
    const engForMatch = text.match(/\b(?:for|towards|against)\s+(.+)$/i);
    if (engForMatch && engForMatch[1]) {
      return engForMatch[1].trim();
    }

    return undefined;
  }

  /**
   * Parse full spoken sentence into transaction fields
   * Strips any stop words and converts amount to Lacs per SUM ledger requirements.
   */
  public static parseSpokenTransaction(
    text: string,
    knownParties: string[] = []
  ): ParsedVoiceTransaction {
    const cleanText = this.stripStopCommand(text);
    return {
      type: this.detectType(cleanText),
      amount: this.extractAmountInLacs(cleanText),
      amountInRupees: this.extractAmount(cleanText),
      partyName: this.extractPartyName(cleanText, knownParties),
      narration: this.extractNarration(cleanText),
      rawText: text,
    };
  }
}
