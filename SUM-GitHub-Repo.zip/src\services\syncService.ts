/**
 * Real-Time Multi-Device Synchronization Service
 * Keeps all devices (phones, tablets, PCs) in sync simultaneously using Server-Sent Events (SSE).
 */

type SyncEventListener = (event: { type: string; payload?: any; sourceUser?: string }) => void;

class SyncService {
  private eventSource: EventSource | null = null;
  private listeners: Set<SyncEventListener> = new Set();
  private isConnecting: boolean = false;
  private reconnectTimeout: any = null;

  constructor() {
    this.initSSE();
  }

  public subscribe(listener: SyncEventListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(event: { type: string; payload?: any; sourceUser?: string }) {
    this.listeners.forEach((l) => {
      try {
        l(event);
      } catch (err) {
        console.error('Sync listener error:', err);
      }
    });
  }

  private initSSE() {
    if (typeof window === 'undefined' || !window.EventSource) return;
    if (this.isConnecting) return;

    this.isConnecting = true;
    try {
      this.eventSource = new EventSource('/api/sync/events');

      this.eventSource.onopen = () => {
        this.isConnecting = false;
      };

      this.eventSource.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          this.notify(data);
        } catch (err) {
          console.warn('Sync parse error:', err);
        }
      };

      this.eventSource.onerror = () => {
        this.isConnecting = false;
        if (this.eventSource) {
          this.eventSource.close();
          this.eventSource = null;
        }

        // Reconnect after 3 seconds
        clearTimeout(this.reconnectTimeout);
        this.reconnectTimeout = setTimeout(() => {
          this.initSSE();
        }, 3000);
      };
    } catch (e) {
      this.isConnecting = false;
    }
  }

  /**
   * Broadcast a state change to the server so all other devices update simultaneously
   */
  public async pushChange(type: string, payload: any, userName: string): Promise<boolean> {
    try {
      const res = await fetch('/api/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type,
          payload,
          sourceUser: userName,
          timestamp: new Date().toISOString(),
        }),
      });
      return res.ok;
    } catch (err) {
      // Local network fallback
      return false;
    }
  }
}

export const syncService = new SyncService();
