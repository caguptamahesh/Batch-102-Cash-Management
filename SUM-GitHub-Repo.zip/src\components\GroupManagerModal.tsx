import React, { useState } from 'react';
import {
  X,
  Building2,
  Plus,
  Users,
  Check,
  Globe,
  Briefcase,
  Layers,
} from 'lucide-react';
import { Group, User } from '../types/ledger';

interface GroupManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  groups: Group[];
  activeGroupId: string;
  onSelectGroup: (id: string) => void;
  onCreateGroup: (name: string, purpose: string, currency: string) => void;
  currentUser: User;
}

export const GroupManagerModal: React.FC<GroupManagerModalProps> = ({
  isOpen,
  onClose,
  groups,
  activeGroupId,
  onSelectGroup,
  onCreateGroup,
  currentUser,
}) => {
  const [mode, setMode] = useState<'list' | 'create'>('create');
  const [name, setName] = useState('');
  const [purpose, setPurpose] = useState('');
  const [currency, setCurrency] = useState('₹');

  if (!isOpen) return null;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onCreateGroup(name.trim(), purpose.trim(), currency);
    setName('');
    setPurpose('');
    onClose();
  };

  const presetCurrencies = ['₹', '$', '€', '£', 'AED', '¥'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-sky-100 w-full max-w-lg overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-sky-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-600 text-white flex items-center justify-center">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Business & Purpose Groups
              </h2>
              <div className="text-[11px] text-slate-500">
                Data is strictly isolated per group ledger
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-slate-100 text-xs font-semibold">
          <button
            onClick={() => setMode('create')}
            className={`flex-1 py-3 text-center transition-colors cursor-pointer ${
              mode === 'create'
                ? 'text-sky-700 border-b-2 border-sky-600 bg-sky-50/40'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            + Create New Group
          </button>
          <button
            onClick={() => setMode('list')}
            className={`flex-1 py-3 text-center transition-colors cursor-pointer ${
              mode === 'list'
                ? 'text-sky-700 border-b-2 border-sky-600 bg-sky-50/40'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Groups ({groups.length})
          </button>
        </div>

        <div className="p-6">
          {mode === 'create' ? (
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Group / Business Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Warehouse Branch 2, Construction Site B, Retail Counter"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-sky-500 outline-none font-medium"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Purpose / Object Description
                </label>
                <textarea
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="e.g. Daily cash flow for wholesale distribution, materials dispatch, and driver expenses."
                  rows={2}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-sky-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Accounting Currency
                </label>
                <div className="flex flex-wrap gap-2">
                  {presetCurrencies.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setCurrency(c)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono transition-colors cursor-pointer ${
                        currency === c
                          ? 'bg-sky-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                  <input
                    type="text"
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-16 px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono text-center font-bold"
                    maxLength={4}
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Create Isolated Cash Group
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-3 max-h-72 overflow-y-auto">
              {groups.map((grp) => {
                const isActive = grp.id === activeGroupId;
                return (
                  <div
                    key={grp.id}
                    onClick={() => {
                      onSelectGroup(grp.id);
                      onClose();
                    }}
                    className={`p-3.5 rounded-xl border text-left flex items-start justify-between transition-all cursor-pointer ${
                      isActive
                        ? 'border-sky-500 bg-sky-50/80 ring-2 ring-sky-500/20'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900">{grp.name}</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.2 bg-slate-100 rounded text-slate-600">
                          {grp.currency}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 line-clamp-2">
                        {grp.purpose}
                      </p>
                      <div className="text-[10px] text-slate-600 flex items-center gap-1.5">
                        <Users className="w-3 h-3 text-slate-400" />
                        <span>{grp.members?.length || 1} members joined</span>
                        <span>·</span>
                        <span>Created {new Date(grp.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>

                    {isActive && (
                      <span className="shrink-0 text-xs font-semibold text-sky-700 bg-white px-2 py-0.5 rounded border border-sky-200 shadow-xs">
                        Active
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="p-3 border-t border-slate-100 text-center text-[10px] text-slate-500 font-mono">
          SUM • Version 2026.v1 • © MG
        </div>

      </div>
    </div>
  );
};
