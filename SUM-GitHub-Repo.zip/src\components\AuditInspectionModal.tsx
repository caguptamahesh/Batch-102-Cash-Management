import React from 'react';
import { X, History, Clock, User, ShieldCheck, FileText } from 'lucide-react';
import { AuditLogEntry, Group, Transaction } from '../types/ledger';
import { storageService } from '../services/storageService';

interface AuditInspectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
  auditLogs: AuditLogEntry[];
  group: Group;
}

export const AuditInspectionModal: React.FC<AuditInspectionModalProps> = ({
  isOpen,
  onClose,
  transaction,
  auditLogs,
  group,
}) => {
  if (!isOpen || !transaction) return null;

  const relevantLogs = auditLogs.filter(
    (l) => l.transactionId === transaction.id || l.receiptNumber === transaction.receiptNumber
  );

  const currency = group?.currency || '₹';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-sky-100 w-full max-w-lg overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-sky-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-600 text-white flex items-center justify-center">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Transaction Audit Lifecycle
              </h2>
              <div className="text-[11px] text-slate-500 font-mono">
                Receipt #{transaction.receiptNumber} · {group.name}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Current Transaction Overview */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-500">Party:</span>
              <span className="font-bold text-slate-900">{transaction.partyName}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-500">Direction:</span>
              <span className="font-bold text-sky-800">{storageService.formatTypeLabel(transaction.type)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-500">Amount:</span>
              <span className="font-bold font-mono tabular-nums text-slate-900">
                {currency}{transaction.amount.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-500">Journal Date:</span>
              <span className="font-mono text-slate-700">{transaction.date}</span>
            </div>
            {transaction.narration && (
              <div className="pt-1 border-t border-slate-200/60">
                <span className="font-semibold text-slate-500 block mb-0.5">Narration:</span>
                <span className="text-slate-700">{transaction.narration}</span>
              </div>
            )}
          </div>

          {/* Audit Chain Timeline */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3">
              Immutable Audit Events ({relevantLogs.length})
            </h3>

            <div className="space-y-3 max-h-60 overflow-y-auto">
              {relevantLogs.length === 0 ? (
                <div className="text-xs text-slate-500 italic p-3 bg-slate-50 rounded-lg">
                  Created by {transaction.createdBy.name} on {new Date(transaction.createdAt).toLocaleString()}.
                </div>
              ) : (
                relevantLogs.map((log) => {
                  const date = new Date(log.timestamp);
                  return (
                    <div key={log.id} className="p-3 rounded-xl border border-slate-200 bg-white text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-slate-500" />
                          <span>{log.performedBy.name}</span>
                          <span className="text-[10px] text-slate-500 uppercase font-normal">
                            ({log.performedBy.role})
                          </span>
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">
                          {date.toLocaleDateString()} {date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <div className="text-slate-700 font-medium">{log.summary}</div>
                      {log.details && log.details.length > 0 && (
                        <div className="bg-slate-50 p-2 rounded text-[11px] font-mono text-slate-600 mt-1">
                          {log.details.map((d, i) => (
                            <div key={i}>
                              <b className="text-slate-800">{d.field}:</b> {String(d.oldValue)} → <span className="text-sky-700 font-bold">{String(d.newValue)}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={onClose}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
            >
              Close Audit Details
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
