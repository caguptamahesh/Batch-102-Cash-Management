import React, { useState } from 'react';
import {
  Wallet,
  Building,
  UserCheck,
  RefreshCw,
  Plus,
  Shield,
  FileSpreadsheet,
  History,
  Users,
  ChevronDown,
  Layers,
  Sparkles,
  Smartphone,
  BookOpen,
  Calculator,
  QrCode,
  FileText,
  Cloud,
  LockKeyhole,
} from 'lucide-react';
import { Group, User } from '../types/ledger';

export type LedgerTab = 'dashboard' | 'transactions' | 'parties' | 'tally' | 'notes' | 'audit' | 'reports';

interface HeaderProps {
  currentGroup: Group;
  groups: Group[];
  currentUser: User;
  activeTab: LedgerTab;
  onTabChange: (tab: LedgerTab) => void;
  onSelectGroup: (groupId: string) => void;
  onOpenCreateGroup: () => void;
  onOpenUserModal: () => void;
  onOpenIncomeModal: () => void;
  onOpenExpenseModal: () => void;
  onOpenMobileConnect: () => void;
  onOpenQuickNotes: () => void;
  onOpenDriveModal?: () => void;
  onLockDevice?: () => void;
  notesCount?: number;
  isOnline: boolean;
  syncTimestamp: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentGroup,
  groups,
  currentUser,
  activeTab,
  onTabChange,
  onSelectGroup,
  onOpenCreateGroup,
  onOpenUserModal,
  onOpenIncomeModal,
  onOpenExpenseModal,
  onOpenMobileConnect,
  onOpenQuickNotes,
  onOpenDriveModal,
  onLockDevice,
  notesCount = 0,
  isOnline,
  syncTimestamp,
}) => {
  const [groupDropdownOpen, setGroupDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-sky-100 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Brand Wordmark & Active Group Switcher */}
          <div className="flex items-center gap-4 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-600 to-blue-600 flex items-center justify-center text-white shadow-md shadow-sky-500/20 font-black text-xl tracking-wider border border-white/20 select-none">
                M
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xl font-black tracking-tight text-slate-900 whitespace-nowrap">
                    SUM
                  </span>
                  <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200 font-mono">
                    2026.v1
                  </span>
                </div>
                <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-slate-600">
                  <span>Cash Management</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-semibold text-slate-500">© MG</span>
                </div>
              </div>
            </div>

            {/* Group Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => setGroupDropdownOpen(!groupDropdownOpen)}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-sky-50/80 hover:bg-sky-100/80 border border-sky-200/80 rounded-lg transition-colors whitespace-nowrap"
                title="Switch business/purpose group"
              >
                <Building className="w-3.5 h-3.5 text-sky-600" />
                <span className="max-w-[140px] truncate">{currentGroup?.name || 'Select Group'}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {groupDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-20"
                    onClick={() => setGroupDropdownOpen(false)}
                  />
                  <div className="absolute left-0 mt-1.5 w-64 bg-white rounded-xl shadow-xl border border-sky-100 py-1.5 z-30 divide-y divide-slate-100">
                    <div className="px-3 py-2 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                      Business & Cash Groups ({groups.length})
                    </div>
                    <div className="max-h-60 overflow-y-auto py-1">
                      {groups.map((grp) => (
                        <button
                          key={grp.id}
                          onClick={() => {
                            onSelectGroup(grp.id);
                            setGroupDropdownOpen(false);
                          }}
                          className={`w-full text-left px-3 py-2 text-xs flex items-start gap-2.5 hover:bg-sky-50/70 transition-colors ${
                            grp.id === currentGroup?.id ? 'bg-sky-50 text-sky-900 font-semibold' : 'text-slate-700'
                          }`}
                        >
                          <span className="mt-0.5 w-2 h-2 rounded-full bg-sky-500 shrink-0" />
                          <div className="truncate">
                            <div className="truncate">{grp.name}</div>
                            <div className="text-[11px] text-slate-600 truncate">{grp.purpose}</div>
                          </div>
                        </button>
                      ))}
                    </div>
                    <div className="p-1.5">
                      <button
                        onClick={() => {
                          setGroupDropdownOpen(false);
                          onOpenCreateGroup();
                        }}
                        className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-sky-700 hover:bg-sky-50 rounded-lg transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Create New Group</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Navigation Tabs (Clean typography with icons) */}
          <nav className="hidden lg:flex items-center gap-1 text-sm font-medium text-slate-600">
            <button
              onClick={() => onTabChange('dashboard')}
              className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'dashboard'
                  ? 'text-sky-700 font-semibold bg-sky-50'
                  : 'hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => onTabChange('transactions')}
              className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'transactions'
                  ? 'text-sky-700 font-semibold bg-sky-50'
                  : 'hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Transactions
            </button>
            <button
              onClick={() => onTabChange('parties')}
              className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'parties'
                  ? 'text-sky-700 font-semibold bg-sky-50'
                  : 'hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Parties
            </button>
            <button
              onClick={() => onTabChange('tally')}
              className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                activeTab === 'tally'
                  ? 'text-emerald-700 font-semibold bg-emerald-50'
                  : 'hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Calculator className="w-3.5 h-3.5 text-emerald-600" />
              <span>Cash Tally</span>
            </button>
            <button
              onClick={() => onTabChange('notes')}
              className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                activeTab === 'notes'
                  ? 'text-amber-800 font-semibold bg-amber-50'
                  : 'hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-amber-600" />
              <span>Reference Notes</span>
              {notesCount > 0 && (
                <span className="ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] bg-amber-200 text-amber-900 font-bold font-mono">
                  {notesCount}
                </span>
              )}
            </button>
            <button
              onClick={() => onTabChange('audit')}
              className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'audit'
                  ? 'text-sky-700 font-semibold bg-sky-50'
                  : 'hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Audit Trail
            </button>
            <button
              onClick={() => onTabChange('reports')}
              className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'reports'
                  ? 'text-sky-700 font-semibold bg-sky-50'
                  : 'hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Reports
            </button>
          </nav>

          {/* Right Action Zone: Quick Income & Expense Buttons + User profile + Mobile QR */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Real-time Sync Indicator */}
            <div
              className="hidden 2xl:flex items-center gap-1.5 text-[11px] text-slate-600 px-2 py-1 bg-slate-50 rounded-md border border-slate-200"
              title={`Live real-time sync active across sessions. Last synced: ${syncTimestamp}`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-emerald-500' : 'bg-amber-500'}`} />
              <span className="font-mono text-[10px]">Sync</span>
            </div>

            {/* Google Drive Multi-User Cloud Sync */}
            {onOpenDriveModal && (
              <button
                onClick={onOpenDriveModal}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-blue-800 bg-blue-50 hover:bg-blue-100 border border-blue-200/80 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                title="Google Drive Multi-User Cloud Sync (ai.caguptamahesh@gmail.com)"
              >
                <Cloud className="w-3.5 h-3.5 text-blue-600" />
                <span>Drive Sync</span>
              </button>
            )}

            {/* Mobile Connect Button */}
            <button
              onClick={onOpenMobileConnect}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-sky-800 bg-sky-50 hover:bg-sky-100 border border-sky-200/80 rounded-lg transition-colors whitespace-nowrap"
              title="Connect mobile phone over local Wi-Fi with QR code"
            >
              <Smartphone className="w-3.5 h-3.5 text-sky-600" />
              <span className="hidden sm:inline">Mobile QR</span>
            </button>

            {/* Quick Scratchpad / Memo Drawer Toggle */}
            <button
              onClick={onOpenQuickNotes}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200/80 rounded-lg transition-colors whitespace-nowrap"
              title="Open quick counter scratchpad memo"
            >
              <FileText className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Notepad</span>
            </button>

            {/* Income & Expense Buttons */}
            <div className="flex items-center gap-1">
              <button
                onClick={onOpenIncomeModal}
                className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Income</span>
              </button>
              <button
                onClick={onOpenExpenseModal}
                className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-xs transition-colors whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Expense</span>
              </button>
            </div>

            {/* User Profile & Role Switcher */}
            <button
              onClick={onOpenUserModal}
              className="flex items-center gap-1.5 p-1 hover:bg-sky-50 rounded-lg transition-colors border border-transparent hover:border-sky-100"
              title="Manage user credentials, roles, and download codes"
            >
              <div className={`w-7 h-7 rounded-full ${currentUser.avatarBg} text-white text-xs font-bold flex items-center justify-center shrink-0`}>
                {currentUser.name.charAt(0)}
              </div>
              <div className="hidden xl:block text-left">
                <div className="text-xs font-semibold text-slate-800 leading-tight truncate max-w-[90px]">
                  {currentUser.name}
                </div>
                <div className="text-[9px] text-sky-600 font-medium uppercase tracking-wider">
                  {currentUser.role}
                </div>
              </div>
            </button>

            {/* Lock Device to 6-Digit Gate */}
            {onLockDevice && (
              <button
                onClick={onLockDevice}
                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors border border-transparent hover:border-rose-100 cursor-pointer"
                title="Lock Device / Test 6-Digit Download Gate"
              >
                <LockKeyhole className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Mobile Sub-Navigation Bar */}
        <div className="flex lg:hidden overflow-x-auto py-2 gap-1 border-t border-sky-50 text-xs font-medium no-scrollbar">
          <button
            onClick={() => onTabChange('dashboard')}
            className={`px-3 py-1 rounded-md shrink-0 whitespace-nowrap ${
              activeTab === 'dashboard' ? 'bg-sky-100 text-sky-800 font-semibold' : 'text-slate-600'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => onTabChange('transactions')}
            className={`px-3 py-1 rounded-md shrink-0 whitespace-nowrap ${
              activeTab === 'transactions' ? 'bg-sky-100 text-sky-800 font-semibold' : 'text-slate-600'
            }`}
          >
            Transactions
          </button>
          <button
            onClick={() => onTabChange('parties')}
            className={`px-3 py-1 rounded-md shrink-0 whitespace-nowrap ${
              activeTab === 'parties' ? 'bg-sky-100 text-sky-800 font-semibold' : 'text-slate-600'
            }`}
          >
            Parties
          </button>
          <button
            onClick={() => onTabChange('tally')}
            className={`px-3 py-1 rounded-md shrink-0 whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'tally' ? 'bg-emerald-100 text-emerald-800 font-semibold' : 'text-slate-600'
            }`}
          >
            <Calculator className="w-3 h-3 text-emerald-600" />
            <span>Cash Tally</span>
          </button>
          <button
            onClick={() => onTabChange('notes')}
            className={`px-3 py-1 rounded-md shrink-0 whitespace-nowrap flex items-center gap-1 ${
              activeTab === 'notes' ? 'bg-amber-100 text-amber-800 font-semibold' : 'text-slate-600'
            }`}
          >
            <BookOpen className="w-3 h-3 text-amber-600" />
            <span>Notes Panel</span>
            {notesCount > 0 && (
              <span className="px-1 py-0.1 text-[9px] rounded-full bg-amber-200 text-amber-900 font-mono">
                {notesCount}
              </span>
            )}
          </button>
          <button
            onClick={() => onTabChange('audit')}
            className={`px-3 py-1 rounded-md shrink-0 whitespace-nowrap ${
              activeTab === 'audit' ? 'bg-sky-100 text-sky-800 font-semibold' : 'text-slate-600'
            }`}
          >
            Audit
          </button>
          <button
            onClick={() => onTabChange('reports')}
            className={`px-3 py-1 rounded-md shrink-0 whitespace-nowrap ${
              activeTab === 'reports' ? 'bg-sky-100 text-sky-800 font-semibold' : 'text-slate-600'
            }`}
          >
            Reports
          </button>
        </div>
      </div>
    </header>
  );
};
