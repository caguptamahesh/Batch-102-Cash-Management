import React from 'react';
import { X, Printer, Download } from 'lucide-react';
import { Group, PartySummary, Transaction, User } from '../types/ledger';
import { storageService } from '../services/storageService';

interface PrintReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  group: Group;
  transactions: Transaction[];
  partySummaries: PartySummary[];
  currentUser?: User;
}

export const PrintReportModal: React.FC<PrintReportModalProps> = ({
  isOpen,
  onClose,
  group,
  transactions,
  partySummaries,
  currentUser,
}) => {
  if (!isOpen) return null;

  const isAdmin = currentUser ? currentUser.role === 'admin' : true;

  const currency = group?.currency || '₹';

  const handlePrint = () => {
    window.print();
  };

  // Calculations
  let totalInflow = 0;
  let totalOutflow = 0;
  let totalReceivable = 0;
  let totalPayable = 0;

  transactions.forEach((tx) => {
    if (tx.type === 'RECEIVED_FROM') totalInflow += tx.amount;
    if (tx.type === 'RECEIVABLE_FROM') totalReceivable += tx.amount;
    if (tx.type === 'PAID_TO') totalOutflow += tx.amount;
    if (tx.type === 'PAYABLE_TO') totalPayable += tx.amount;
  });

  const netCash = totalInflow - totalOutflow;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden">
        
        {/* Modal Toolbar (hidden when printing) */}
        <div className="print:hidden flex items-center justify-between px-6 py-3.5 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <span className="font-bold text-sm text-slate-800">Print / PDF Statement Preview</span>
            <span className="text-xs text-slate-500 font-mono">({transactions.length} entries)</span>
          </div>
          <div className="flex items-center gap-2">
            {!isAdmin ? (
              <span className="text-[11px] font-bold px-3 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-lg">
                🔒 Currency Reports Restricted to Admin (Mr. MG)
              </span>
            ) : (
              <button
                onClick={handlePrint}
                className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-xs transition-colors cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print / Save as PDF</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-8 overflow-y-auto print:p-0 print:overflow-visible text-slate-900 space-y-6">
          
          {/* Official Document Header */}
          <div className="border-b-2 border-slate-900 pb-4 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <div className="text-xs uppercase font-mono tracking-widest text-slate-500 font-bold">
                SUM FINANCIAL STATEMENT (Version 2026.v1)
              </div>
              <h1 className="text-2xl font-bold text-slate-900 mt-0.5">
                {group.name}
              </h1>
              <p className="text-xs text-slate-600 mt-0.5">
                {group.purpose}
              </p>
            </div>
            <div className="text-right text-xs font-mono text-slate-600">
              <div>Date Generated: {new Date().toLocaleDateString()}</div>
              <div>Report ID: SUM-{Date.now().toString().slice(-6)}</div>
            </div>
          </div>

          {/* KPI Summary Grid */}
          <div className="grid grid-cols-4 gap-3 text-center border border-slate-200 rounded-xl p-3 bg-slate-50 print:bg-transparent">
            <div>
              <div className="text-[10px] uppercase font-bold text-emerald-800">Total Cash Received</div>
              <div className="text-base font-bold font-mono text-emerald-700 tabular-nums">
                {totalInflow.toLocaleString('en-IN', { maximumFractionDigits: 5 })}
              </div>
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-rose-800">Total Cash Paid</div>
              <div className="text-base font-bold font-mono text-rose-700 tabular-nums">
                {totalOutflow.toLocaleString('en-IN', { maximumFractionDigits: 5 })}
              </div>
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-700">Net Cash Balance</div>
              <div className="text-base font-bold font-mono text-slate-900 tabular-nums">
                {netCash.toLocaleString('en-IN', { maximumFractionDigits: 5 })}
              </div>
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-sky-800">Pending Receivables</div>
              <div className="text-base font-bold font-mono text-sky-700 tabular-nums">
                {totalReceivable.toLocaleString('en-IN', { maximumFractionDigits: 5 })}
              </div>
            </div>
          </div>

          {/* Transactions Statement Table */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              1. Cash Journal Transactions
            </h2>
            <table className="w-full text-left text-xs border border-slate-200 border-collapse">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-300 font-bold text-slate-800">
                  <th className="py-2 px-2 border-r border-slate-200">Receipt #</th>
                  <th className="py-2 px-2 border-r border-slate-200">Date</th>
                  <th className="py-2 px-2 border-r border-slate-200">Direction</th>
                  <th className="py-2 px-2 border-r border-slate-200">Party Name</th>
                  <th className="py-2 px-2 border-r border-slate-200 text-right">Amount</th>
                  <th className="py-2 px-2 border-r border-slate-200">Narration</th>
                  <th className="py-2 px-2">Recorded By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {transactions.map((tx) => (
                  <tr key={tx.id} className="text-slate-800">
                    <td className="py-1.5 px-2 font-mono font-medium border-r border-slate-200">{tx.receiptNumber}</td>
                    <td className="py-1.5 px-2 font-mono border-r border-slate-200">{tx.date}</td>
                    <td className="py-1.5 px-2 font-semibold border-r border-slate-200">
                      {storageService.formatTypeLabel(tx.type)}
                    </td>
                    <td className="py-1.5 px-2 font-medium border-r border-slate-200">{tx.partyName}</td>
                    <td className="py-1.5 px-2 text-right font-mono font-bold border-r border-slate-200 tabular-nums">
                      {tx.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 5 })}
                    </td>
                    <td className="py-1.5 px-2 border-r border-slate-200 text-slate-600">{tx.narration || '-'}</td>
                    <td className="py-1.5 px-2 text-slate-600">{tx.createdBy.name}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Party-wise Balances Summary */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              2. Party-wise Ledger Position
            </h2>
            <table className="w-full text-left text-xs border border-slate-200 border-collapse">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-300 font-bold text-slate-800">
                  <th className="py-2 px-2 border-r border-slate-200">Party Name</th>
                  <th className="py-2 px-2 border-r border-slate-200 text-right">Received from</th>
                  <th className="py-2 px-2 border-r border-slate-200 text-right">Receivable from</th>
                  <th className="py-2 px-2 border-r border-slate-200 text-right">Paid to</th>
                  <th className="py-2 px-2 border-r border-slate-200 text-right">Payable to</th>
                  <th className="py-2 px-2 text-right">Net Position</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {partySummaries.map((p) => {
                  const pos = p.netBalance > 0 ? `Receivable: ${p.netBalance.toLocaleString()}` :
                              p.netBalance < 0 ? `Payable: ${Math.abs(p.netBalance).toLocaleString()}` :
                              'Settled';
                  return (
                    <tr key={p.partyName} className="text-slate-800">
                      <td className="py-1.5 px-2 font-bold border-r border-slate-200">{p.partyName}</td>
                      <td className="py-1.5 px-2 text-right font-mono border-r border-slate-200">{p.totalReceived.toLocaleString()}</td>
                      <td className="py-1.5 px-2 text-right font-mono border-r border-slate-200">{p.totalReceivable.toLocaleString()}</td>
                      <td className="py-1.5 px-2 text-right font-mono border-r border-slate-200">{p.totalPaid.toLocaleString()}</td>
                      <td className="py-1.5 px-2 text-right font-mono border-r border-slate-200">{p.totalPayable.toLocaleString()}</td>
                      <td className="py-1.5 px-2 text-right font-mono font-bold">{pos}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Audit Verification Footer */}
          <div className="border-t border-slate-200 pt-4 flex items-center justify-between text-[11px] text-slate-500 font-mono">
            <div>SUM • Version 2026.v1 • © MG</div>
            <div>Sign / Stamp: ____________________________</div>
          </div>

        </div>

      </div>
    </div>
  );
};
