import { useState, useEffect, useRef, useCallback } from 'react';
import { VoiceService } from '../services/voiceService';
import { isIosSafari, openInGoogleChrome } from '../utils/iosChromeHelper';

export type SpeechLanguage = 'en-IN' | 'hi-IN';

interface UseSpeechRecognitionOptions {
  onFinalResult?: (transcript: string) => void;
  language?: SpeechLanguage;
}

export function useSpeechRecognition({
  onFinalResult,
  language = 'en-IN',
}: UseSpeechRecognitionOptions = {}) {
  const [isListening, setIsListening] = useState<boolean>(false);
  const [transcript, setTranscript] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [lang, setLang] = useState<SpeechLanguage>(language);

  const recognitionRef = useRef<any>(null);
  const isSupported = VoiceService.isSupported();

  // Persistent reference to whether user desires active listening
  const shouldBeListeningRef = useRef<boolean>(false);
  const accumulatedFinalRef = useRef<string>('');

  // Keep callback ref updated
  const onFinalResultRef = useRef(onFinalResult);
  useEffect(() => {
    onFinalResultRef.current = onFinalResult;
  }, [onFinalResult]);

  useEffect(() => {
    if (!isSupported || typeof window === 'undefined') return;

    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    const recognition = new SpeechRecognition();
    recognition.continuous = true; // Continuous listening per user requirement 6
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.lang = lang;

    recognition.onstart = () => {
      setIsListening(true);
      setError(null);
    };

    recognition.onresult = (event: any) => {
      let sessionFinal = '';
      let currentInterim = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          sessionFinal += ' ' + event.results[i][0].transcript;
        } else {
          currentInterim += event.results[i][0].transcript;
        }
      }

      if (sessionFinal.trim()) {
        accumulatedFinalRef.current = (accumulatedFinalRef.current + ' ' + sessionFinal).trim();
      }

      const activeText = (accumulatedFinalRef.current + ' ' + currentInterim).trim();
      setTranscript(activeText);

      // Check if user spoke a stop/end command ("Stop", "End", "Over", "स्टॉप", "बंद करो", "खत्म", etc.)
      if (VoiceService.hasStopCommand(activeText)) {
        const cleaned = VoiceService.stripStopCommand(activeText);
        shouldBeListeningRef.current = false;
        try {
          recognition.stop();
        } catch {}
        setIsListening(false);
        setTranscript(cleaned);
        if (onFinalResultRef.current && cleaned) {
          onFinalResultRef.current(cleaned);
        }
        return;
      }

      if (sessionFinal && onFinalResultRef.current) {
        onFinalResultRef.current(activeText);
      }
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition event note:', event.error);
      if (event.error === 'not-allowed') {
        setError('Microphone permission blocked. Please allow mic access in your browser.');
        shouldBeListeningRef.current = false;
        setIsListening(false);
      } else if (event.error === 'no-speech') {
        // Keep listening unless user stopped
      } else {
        // Ignored or handled gracefully
      }
    };

    recognition.onend = () => {
      // If user still wants listening (i.e. did not say "stop" or click stop), auto-restart
      if (shouldBeListeningRef.current) {
        try {
          recognition.start();
        } catch {
          setTimeout(() => {
            if (shouldBeListeningRef.current) {
              try { recognition.start(); } catch {}
            }
          }, 200);
        }
      } else {
        setIsListening(false);
      }
    };

    recognitionRef.current = recognition;

    return () => {
      shouldBeListeningRef.current = false;
      try {
        recognition.abort();
      } catch {}
    };
  }, [isSupported, lang]);

  const startListening = useCallback(
    (targetLang?: SpeechLanguage) => {
      // Requirement 1: Voice recognition is not available in Safari(iOS), so in case of iOS, open in Google Chrome if installed
      if (isIosSafari()) {
        openInGoogleChrome();
        setError('Voice recognition is not supported in iOS Safari. Opening in Google Chrome if installed on your iPhone/iPad. Otherwise, please enter transactions manually in Safari.');
        return;
      }

      if (!isSupported) {
        setError('Speech recognition is not supported in this browser. Please use Google Chrome or Edge.');
        return;
      }

      const languageToUse = targetLang || lang;
      if (targetLang && targetLang !== lang) {
        setLang(targetLang);
      }

      shouldBeListeningRef.current = true;
      accumulatedFinalRef.current = '';
      setError(null);
      setTranscript('');

      try {
        if (recognitionRef.current) {
          recognitionRef.current.lang = languageToUse;
          recognitionRef.current.start();
        }
      } catch (err: any) {
        try {
          recognitionRef.current.abort();
          setTimeout(() => {
            if (shouldBeListeningRef.current) {
              recognitionRef.current.start();
            }
          }, 150);
        } catch {}
      }
    },
    [isSupported, lang]
  );

  const stopListening = useCallback(() => {
    shouldBeListeningRef.current = false;
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
    }
    setIsListening(false);

    // Final clean up and notify
    if (accumulatedFinalRef.current && onFinalResultRef.current) {
      const cleaned = VoiceService.stripStopCommand(accumulatedFinalRef.current);
      if (cleaned) {
        onFinalResultRef.current(cleaned);
      }
    }
  }, []);

  const toggleLanguage = useCallback(() => {
    setLang((prev) => (prev === 'en-IN' ? 'hi-IN' : 'en-IN'));
  }, []);

  return {
    isListening,
    transcript,
    error,
    isSupported,
    isIosSafari: isIosSafari(),
    openInGoogleChrome,
    language: lang,
    setLanguage: setLang,
    toggleLanguage,
    startListening,
    stopListening,
  };
}
