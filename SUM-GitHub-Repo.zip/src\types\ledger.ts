export type TransactionType =
  | 'RECEIVED_FROM'   // Cash Inflow / Income
  | 'RECEIVABLE_FROM' // Asset / Money party owes us
  | 'PAID_TO'          // Cash Outflow / Expenditure
  | 'PAYABLE_TO';      // Liability / Money we owe party

export type FlowCategory = 'INCOME' | 'EXPENDITURE';

export interface User {
  id: string;
  name: string;
  email: string;
  mobile: string;
  role: 'admin' | 'user';
  avatarBg: string;
  isVerified?: boolean;
  activationCode?: string; // 6-digit download / activation code
  status?: 'active' | 'pending_otp' | 'rejected' | 'deleted';
  allowedGroupIds?: string[]; // Groups this user is permitted to access (admins have access to all)
  createdAt?: string;
}

export interface DeviceActivationState {
  isActivated: boolean;
  activatedUserId?: string;
  activatedUserName?: string;
  activatedAt?: string;
}

export interface UserSignupRequest {
  id: string;
  name: string;
  email: string;
  mobile: string; // Indian Standard +91 XXXXXXXXXX
  otp: string; // 6-digit PIN
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
  expiresAt: string;
  targetAdminMobile: string; // '+91 9414067123'
  targetAdminName: string;   // 'Mr. MG'
}

export interface Party {
  id: string;
  groupId: string;
  name: string;
  mobile?: string;
  email?: string;
  contactPerson?: string;
  address?: string;
  gstin?: string;
  openingBalance: number;
  openingBalanceType: 'RECEIVABLE' | 'PAYABLE' | 'NONE';
  notes?: string;
  status: 'active' | 'archived';
  createdAt: string;
  createdBy: {
    id: string;
    name: string;
    role: 'admin' | 'user';
  };
}

export interface DefunctionState {
  isDefunctioned: boolean;
  defunctionedAt?: string;
  defunctionedBy?: string;
  reason?: string;
}

export interface GroupMember {
  userId: string;
  name: string;
  email: string;
  mobile?: string;
  role: 'admin' | 'user';
  joinedAt: string;
}

export interface Group {
  id: string;
  name: string;
  purpose: string;
  currency: string;
  createdAt: string;
  createdBy: {
    id: string;
    name: string;
    role: 'admin' | 'user';
  };
  members: GroupMember[];
}

export interface Transaction {
  id: string;
  groupId: string;
  type: TransactionType;
  amount: number;
  partyName: string;
  date: string; // YYYY-MM-DD
  narration: string;
  receiptNumber: string;
  category?: string;
  paymentMethod?: 'CASH' | 'CHEQUE' | 'UPI' | 'BANK_TRANSFER';
  status: 'active' | 'deleted';
  createdAt: string;
  createdBy: {
    id: string;
    name: string;
    role: 'admin' | 'user';
  };
  updatedAt?: string;
  updatedBy?: {
    id: string;
    name: string;
    role: 'admin' | 'user';
  };
}

export type AuditAction =
  | 'CREATE'
  | 'UPDATE'
  | 'DELETE'
  | 'RESTORE'
  | 'GROUP_CREATE'
  | 'NOTE_CREATE'
  | 'NOTE_UPDATE'
  | 'NOTE_DELETE'
  | 'TALLY_RECORD'
  | 'PARTY_CREATE'
  | 'PARTY_UPDATE'
  | 'PARTY_DELETE'
  | 'DEFUNCTION_TRIGGERED'
  | 'OTP_DISPATCHED'
  | 'USER_VERIFIED'
  | 'USER_CREATE'
  | 'USER_UPDATE'
  | 'USER_DELETE'
  | 'ALL_DATA_CLEARED';

export interface AuditLogEntry {
  id: string;
  groupId: string;
  transactionId?: string;
  receiptNumber?: string;
  action: AuditAction;
  performedBy: {
    id: string;
    name: string;
    role: 'admin' | 'user';
  };
  timestamp: string;
  summary: string;
  details?: {
    field?: string;
    oldValue?: any;
    newValue?: any;
  }[];
}

export interface PartySummary {
  partyName: string;
  mobile?: string;
  contactPerson?: string;
  totalReceived: number;
  totalReceivable: number;
  totalPaid: number;
  totalPayable: number;
  netBalance: number; // positive = Receivable from party, negative = Payable to party, 0 = Settled
  lastTransactionDate: string;
  transactionCount: number;
}

export interface LedgerDashboardMetrics {
  totalCashReceived: number;
  totalReceivable: number;
  totalCashPaid: number;
  totalPayable: number;
  netCashBalance: number;
  netOverallPosition: number;
  activePartiesCount: number;
  totalTransactionsCount: number;
}

// ==========================================
// Text Panel & Reference Notes Types
// ==========================================
export type NoteTag =
  | 'GENERAL'
  | 'REMINDER'
  | 'CASH_HANDOVER'
  | 'AUDIT'
  | 'BANK_DETAILS'
  | 'TAX_GST'
  | 'TERMS'
  | 'DISCREPANCY';

export type NotePriority = 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';

export type NoteColor = 'amber' | 'blue' | 'emerald' | 'rose' | 'purple' | 'slate';

export interface ReferenceNote {
  id: string;
  groupId: string;
  title: string;
  content: string;
  tag: NoteTag;
  priority: NotePriority;
  isPinned: boolean;
  color: NoteColor;
  relatedParty?: string;
  createdAt: string;
  updatedAt: string;
  createdBy: {
    id: string;
    name: string;
    role: 'admin' | 'user';
  };
}

// ==========================================
// Cash Management & Denominations Counter Types
// ==========================================
export interface CashDenominationCount {
  d2000?: number;
  d500?: number;
  d200?: number;
  d100?: number;
  d50?: number;
  d20?: number;
  d10?: number;
  d5?: number;
  d2?: number;
  d1?: number;
  coins?: number;
}

export interface CashTallySession {
  id: string;
  groupId: string;
  date: string; // YYYY-MM-DD
  timestamp: string; // ISO
  denominations: CashDenominationCount;
  totalPhysicalCash: number;
  systemCashBalance: number;
  variance: number; // totalPhysicalCash - systemCashBalance
  verifiedBy: {
    id: string;
    name: string;
    role: 'admin' | 'user';
  };
  notes?: string;
}

