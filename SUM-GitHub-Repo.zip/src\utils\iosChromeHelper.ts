/**
 * iOS Chrome & Safari Utility
 * Requirement: "voice recognition is not available in Safari(iOS), so in case of iOS,
 * please open the app in google chrome if installed in the phone, else in iOS only."
 */

export const isIosDevice = (): boolean => {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent || '';
  // Check iPhone, iPad, iPod, or iPadOS masquerading as MacIntel with touch points
  return /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
};

export const isIosChrome = (): boolean => {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent || '';
  // Google Chrome on iOS has "CriOS" in its User-Agent
  return /CriOS/i.test(ua);
};

export const isIosSafari = (): boolean => {
  return isIosDevice() && !isIosChrome();
};

/**
 * Converts current web URL to iOS Google Chrome custom URL scheme:
 * http://...  -> googlechrome://...
 * https://... -> googlechromes://...
 */
export const getChromeUrl = (url?: string): string => {
  if (typeof window === 'undefined') return '';
  const target = url || window.location.href;
  if (target.startsWith('https://')) {
    return target.replace(/^https:\/\//i, 'googlechromes://');
  }
  return target.replace(/^http:\/\//i, 'googlechrome://');
};

/**
 * Attempts to launch Google Chrome on iOS.
 * If installed, iOS opens Google Chrome. If not installed, Safari stays on current page.
 */
export const openInGoogleChrome = (url?: string): void => {
  const chromeUrl = getChromeUrl(url);
  if (chromeUrl && typeof window !== 'undefined') {
    window.location.href = chromeUrl;
  }
};
